﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProtocolDemo
{
    public partial class Form_SetUseLocal : Form
    {
        private Form_ProtocolDemo parentForm;
        private List<USELOCAL> _LocalList = new List<USELOCAL>();

        public Form_SetUseLocal(Form_ProtocolDemo parent)
        {
            InitializeComponent();

            this.parentForm = parent;
        }



        // DATABIND
        private void DataBindAllLocal()
        {
            for (int i = 0; i < _LocalList.Count; i++)
            {
                ListViewItem lvi = new ListViewItem((i).ToString());

                //lvi.SubItems.Add(_LocalList[i].LOCAL_INDEX.ToString());
                lvi.SubItems.Add(_LocalList[i].LOCAL_CODE.ToString());
                lvi.SubItems.Add(Encoding.ASCII.GetString(_LocalList[i].LOCAL_NAME, 0, 3));
                lv_local.Items.Add(lvi);
            }
        }

        private void DataBindCurrUseLocal(int localIndex, int localCode, string localName)
        {
            edit_currIdx.Text = localIndex.ToString();
            edit_currCode.Text = localCode.ToString();
            edit_currName.Text = localName;
        }



        // USER EVENT
        private void lv_local_DBClick(object sender, EventArgs e)
        {
            edit_setIndex.Text = lv_local.SelectedItems[0].SubItems[0].Text;
            edit_setCode.Text = lv_local.SelectedItems[0].SubItems[1].Text;
            edit_setName.Text = lv_local.SelectedItems[0].SubItems[2].Text;
        }

        private void btn_getAllLocal_Click(object sender, EventArgs e)
        {
            // [12-70] Get All Local
            parentForm.m_ProtocolDll.PrtcGetAllLocal();
        }

        private void btn_getUseLocal_Click(object sender, EventArgs e)
        {
            // [12-71] Get Use Local
            parentForm.m_ProtocolDll.PrtcGetUseLocal();
        }

        private void btn_setUseLocal_Click(object sender, EventArgs e)
        {
            // [12-72] Get Use Local
            string localIndex = edit_setIndex.Text;
            string localCode = edit_setCode.Text;
            string localName = edit_setName.Text;

            if (string.IsNullOrEmpty(localIndex) || string.IsNullOrEmpty(localCode) || string.IsNullOrEmpty(localName))
            {
                MessageBox.Show("Set Local Info empty!");
                return;
            }

            int nIndex = Convert.ToInt32(localIndex);
            int nCode = Convert.ToInt32(localCode);

            parentForm.m_ProtocolDll.PrtcSetUseLocal(nIndex, nCode, Encoding.ASCII.GetBytes(localName));
        }



        // RECV PROTOCOL
        public void RecvGetAllLocal(byte[] localData)
        {
            if (_LocalList.Count > 0)
                _LocalList.Clear();

            if (lv_local.Items.Count > 0)
                lv_local.Items.Clear();

            int pos = 0;
            int localCount = localData[pos++];

            for (int i = 0; i < localCount; i++)
            {
                USELOCAL local = new USELOCAL();
                local.LOCAL_INDEX = localData[pos++];

                local.LOCAL_CODE = localData[pos++] << 8;
                local.LOCAL_CODE |= localData[pos++];

                Array.Copy(localData, pos, local.LOCAL_NAME, 0, 3);
                pos += 3;

                _LocalList.Add(local);
            }

            DataBindAllLocal();
        }

        public void RecvGetUseLocal(byte[] localData)
        {
            int localIndex = 0;
            int localCode = 0;
            string localName;
            byte[] localNameTemp = new byte[3];

            localIndex = localData[0];
            localCode = localData[1] << 8;
            localCode |= localData[2];
            Array.Copy(localData, 3, localNameTemp, 0, 3);
            localName = Encoding.ASCII.GetString(localNameTemp, 0, 3);

            DataBindCurrUseLocal(localIndex, localCode, localName);
        }

        public void RecvSetUseLocal(byte result)
        {
            if (Convert.ToBoolean(result) == true)
            {
                edit_currIdx.Text = edit_setIndex.Text;
                edit_currCode.Text = edit_setCode.Text;
                edit_currName.Text = edit_setName.Text;
            }

            edit_setIndex.Text = string.Empty;
            edit_setCode.Text = string.Empty;
            edit_setName.Text = string.Empty;
        }
    }

    public class USELOCAL
    {
        public int LOCAL_INDEX;
        public int LOCAL_CODE;
        public byte[] LOCAL_NAME = new byte[3];
    }
}

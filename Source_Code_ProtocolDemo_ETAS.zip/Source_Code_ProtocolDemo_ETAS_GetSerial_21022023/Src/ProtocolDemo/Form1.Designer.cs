﻿namespace ProtocolDemo
{
    partial class Form_ProtocolDemo
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_ProtocolDemo));
            this.btn_connect = new System.Windows.Forms.Button();
            this.lblComPortState = new System.Windows.Forms.Label();
            this.cbb_baudRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbb_portName = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_recvData_ascii = new System.Windows.Forms.TextBox();
            this.btn_clear = new System.Windows.Forms.Button();
            this.tabConnect = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btn_disconnect = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cbb_type = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblServerState = new System.Windows.Forms.Label();
            this.btnServerStop = new System.Windows.Forms.Button();
            this.btnServerStart = new System.Windows.Forms.Button();
            this.txtServerPort = new System.Windows.Forms.TextBox();
            this.lblServerPort = new System.Windows.Forms.Label();
            this.btn_upgrade = new System.Windows.Forms.Button();
            this.btn_sni = new System.Windows.Forms.Button();
            this.btn_setLocalDenom = new System.Windows.Forms.Button();
            this.tabProtocol = new System.Windows.Forms.TabControl();
            this.tabPageIH110 = new System.Windows.Forms.TabPage();
            this.btnGetSNIData = new System.Windows.Forms.Button();
            this.btnGetMachineInfo = new System.Windows.Forms.Button();
            this.btnSetBatchFunction = new System.Windows.Forms.Button();
            this.btnSetAddMode = new System.Windows.Forms.Button();
            this.btnSetUserSettingReset = new System.Windows.Forms.Button();
            this.btnGetAllUser = new System.Windows.Forms.Button();
            this.btnGetAllLocal = new System.Windows.Forms.Button();
            this.btnSetBatch = new System.Windows.Forms.Button();
            this.btnGetBatch = new System.Windows.Forms.Button();
            this.btnInformStartStop = new System.Windows.Forms.Button();
            this.btnGetMachineState = new System.Windows.Forms.Button();
            this.btnSetMode = new System.Windows.Forms.Button();
            this.btnGetSeries = new System.Windows.Forms.Button();
            this.btnGetProduct = new System.Windows.Forms.Button();
            this.btnGetMachineSN = new System.Windows.Forms.Button();
            this.btnGetCountInfo = new System.Windows.Forms.Button();
            this.btnGetDenomInfo = new System.Windows.Forms.Button();
            this.btnGetLocal = new System.Windows.Forms.Button();
            this.btnGetCountedResult = new System.Windows.Forms.Button();
            this.btnGetPocketState = new System.Windows.Forms.Button();
            this.btnGetMACWorkingState = new System.Windows.Forms.Button();
            this.btnGetUserName = new System.Windows.Forms.Button();
            this.txtParam = new System.Windows.Forms.TextBox();
            this.lblParam = new System.Windows.Forms.Label();
            this.btnReadyToWork = new System.Windows.Forms.Button();
            this.tabPageST150N = new System.Windows.Forms.TabPage();
            this.btnGetAppVersionST150N = new System.Windows.Forms.Button();
            this.btnSetBatchModeST150N = new System.Windows.Forms.Button();
            this.btnSetAddModeST150N = new System.Windows.Forms.Button();
            this.btnSetCountingModeST150N = new System.Windows.Forms.Button();
            this.btnSetBatchPresetModeST150N = new System.Windows.Forms.Button();
            this.btnSetBatchST150N = new System.Windows.Forms.Button();
            this.btnGetBatchST150N = new System.Windows.Forms.Button();
            this.btnGetPocketResultST150N = new System.Windows.Forms.Button();
            this.btnInformStartStopST150N = new System.Windows.Forms.Button();
            this.btnGetResultCodeST150N = new System.Windows.Forms.Button();
            this.btnGetMachineStateST150N = new System.Windows.Forms.Button();
            this.btnGetSeriesST150N = new System.Windows.Forms.Button();
            this.btnGetProductST150N = new System.Windows.Forms.Button();
            this.btnGetMachineSNST150N = new System.Windows.Forms.Button();
            this.btnGetCountInfoST150N = new System.Windows.Forms.Button();
            this.btnGetDenomInfoST150N = new System.Windows.Forms.Button();
            this.btnGetLocalST150N = new System.Windows.Forms.Button();
            this.btnGetCountedResultST150N = new System.Windows.Forms.Button();
            this.btnGetPocketStateST150N = new System.Windows.Forms.Button();
            this.btnGetMACWorkingStateST150N = new System.Windows.Forms.Button();
            this.btnGetUserNameST150N = new System.Windows.Forms.Button();
            this.btnReadyToWorkST150N = new System.Windows.Forms.Button();
            this.txtParamST150N = new System.Windows.Forms.TextBox();
            this.lblParamST150N = new System.Windows.Forms.Label();
            this.tabPageST350 = new System.Windows.Forms.TabPage();
            this.btnGetAppVersionST350 = new System.Windows.Forms.Button();
            this.btnSetBatchPresetModeST350 = new System.Windows.Forms.Button();
            this.btnSetBatchST350 = new System.Windows.Forms.Button();
            this.btnGetBatchST350 = new System.Windows.Forms.Button();
            this.btnGetPocketResultST350 = new System.Windows.Forms.Button();
            this.btnInformStartStopST350 = new System.Windows.Forms.Button();
            this.btnGetResultCodeST350 = new System.Windows.Forms.Button();
            this.btnGetMachineStateST350 = new System.Windows.Forms.Button();
            this.btnGetSeriesST350 = new System.Windows.Forms.Button();
            this.btnGetProductST350 = new System.Windows.Forms.Button();
            this.btnGetMachineSNST350 = new System.Windows.Forms.Button();
            this.btnGetCountInfoST350 = new System.Windows.Forms.Button();
            this.btnGetDnomInfoST350 = new System.Windows.Forms.Button();
            this.btnGetLocalST350 = new System.Windows.Forms.Button();
            this.btnGetCountedResultST350 = new System.Windows.Forms.Button();
            this.btnGetPocketStateST350 = new System.Windows.Forms.Button();
            this.btnGetMACWorkingStateST350 = new System.Windows.Forms.Button();
            this.btnGetUserNameST350 = new System.Windows.Forms.Button();
            this.btnReadyToWorkST350 = new System.Windows.Forms.Button();
            this.txtParamST350 = new System.Windows.Forms.TextBox();
            this.lblParamST350 = new System.Windows.Forms.Label();
            this.tabConnect.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabProtocol.SuspendLayout();
            this.tabPageIH110.SuspendLayout();
            this.tabPageST150N.SuspendLayout();
            this.tabPageST350.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(11, 139);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(84, 32);
            this.btn_connect.TabIndex = 6;
            this.btn_connect.Text = "Connect";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // lblComPortState
            // 
            this.lblComPortState.AutoSize = true;
            this.lblComPortState.Location = new System.Drawing.Point(8, 121);
            this.lblComPortState.Name = "lblComPortState";
            this.lblComPortState.Size = new System.Drawing.Size(32, 13);
            this.lblComPortState.TabIndex = 4;
            this.lblComPortState.Text = "State";
            // 
            // cbb_baudRate
            // 
            this.cbb_baudRate.FormattingEnabled = true;
            this.cbb_baudRate.Location = new System.Drawing.Point(77, 42);
            this.cbb_baudRate.Name = "cbb_baudRate";
            this.cbb_baudRate.Size = new System.Drawing.Size(104, 21);
            this.cbb_baudRate.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Baud Rate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Port Name";
            // 
            // cbb_portName
            // 
            this.cbb_portName.FormattingEnabled = true;
            this.cbb_portName.Location = new System.Drawing.Point(77, 10);
            this.cbb_portName.Name = "cbb_portName";
            this.cbb_portName.Size = new System.Drawing.Size(104, 21);
            this.cbb_portName.TabIndex = 0;
            this.cbb_portName.DropDown += new System.EventHandler(this.cbb_portName_DropDown);
            this.cbb_portName.SelectedIndexChanged += new System.EventHandler(this.cbb_portName_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 427);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "[Received Data]";
            // 
            // txt_recvData_ascii
            // 
            this.txt_recvData_ascii.Location = new System.Drawing.Point(12, 443);
            this.txt_recvData_ascii.Multiline = true;
            this.txt_recvData_ascii.Name = "txt_recvData_ascii";
            this.txt_recvData_ascii.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txt_recvData_ascii.Size = new System.Drawing.Size(754, 383);
            this.txt_recvData_ascii.TabIndex = 7;
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(9, 367);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(195, 36);
            this.btn_clear.TabIndex = 5;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // tabConnect
            // 
            this.tabConnect.Controls.Add(this.tabPage1);
            this.tabConnect.Controls.Add(this.tabPage2);
            this.tabConnect.Location = new System.Drawing.Point(9, 10);
            this.tabConnect.Name = "tabConnect";
            this.tabConnect.SelectedIndex = 0;
            this.tabConnect.Size = new System.Drawing.Size(195, 213);
            this.tabConnect.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btn_disconnect);
            this.tabPage1.Controls.Add(this.btn_connect);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.cbb_portName);
            this.tabPage1.Controls.Add(this.lblComPortState);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.cbb_type);
            this.tabPage1.Controls.Add(this.cbb_baudRate);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(187, 187);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Com Port";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btn_disconnect
            // 
            this.btn_disconnect.Location = new System.Drawing.Point(97, 139);
            this.btn_disconnect.Name = "btn_disconnect";
            this.btn_disconnect.Size = new System.Drawing.Size(84, 32);
            this.btn_disconnect.TabIndex = 6;
            this.btn_disconnect.Text = "Disconnect";
            this.btn_disconnect.UseVisualStyleBackColor = true;
            this.btn_disconnect.Click += new System.EventHandler(this.btn_disconnect_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Type";
            // 
            // cbb_type
            // 
            this.cbb_type.FormattingEnabled = true;
            this.cbb_type.Location = new System.Drawing.Point(77, 76);
            this.cbb_type.Name = "cbb_type";
            this.cbb_type.Size = new System.Drawing.Size(104, 21);
            this.cbb_type.TabIndex = 3;
            this.cbb_type.SelectedIndexChanged += new System.EventHandler(this.cbb_type_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblServerState);
            this.tabPage2.Controls.Add(this.btnServerStop);
            this.tabPage2.Controls.Add(this.btnServerStart);
            this.tabPage2.Controls.Add(this.txtServerPort);
            this.tabPage2.Controls.Add(this.lblServerPort);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(187, 187);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Lan";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblServerState
            // 
            this.lblServerState.AutoSize = true;
            this.lblServerState.Location = new System.Drawing.Point(5, 47);
            this.lblServerState.Name = "lblServerState";
            this.lblServerState.Size = new System.Drawing.Size(32, 13);
            this.lblServerState.TabIndex = 3;
            this.lblServerState.Text = "State";
            // 
            // btnServerStop
            // 
            this.btnServerStop.Location = new System.Drawing.Point(7, 113);
            this.btnServerStop.Name = "btnServerStop";
            this.btnServerStop.Size = new System.Drawing.Size(171, 32);
            this.btnServerStop.TabIndex = 3;
            this.btnServerStop.Text = "Server Stop";
            this.btnServerStop.UseVisualStyleBackColor = true;
            this.btnServerStop.Click += new System.EventHandler(this.btnServerStop_Click);
            // 
            // btnServerStart
            // 
            this.btnServerStart.Location = new System.Drawing.Point(7, 74);
            this.btnServerStart.Name = "btnServerStart";
            this.btnServerStart.Size = new System.Drawing.Size(171, 32);
            this.btnServerStart.TabIndex = 2;
            this.btnServerStart.Text = "Server Start";
            this.btnServerStart.UseVisualStyleBackColor = true;
            this.btnServerStart.Click += new System.EventHandler(this.btnServerStart_Click);
            // 
            // txtServerPort
            // 
            this.txtServerPort.Location = new System.Drawing.Point(80, 13);
            this.txtServerPort.Name = "txtServerPort";
            this.txtServerPort.Size = new System.Drawing.Size(99, 20);
            this.txtServerPort.TabIndex = 1;
            // 
            // lblServerPort
            // 
            this.lblServerPort.AutoSize = true;
            this.lblServerPort.Location = new System.Drawing.Point(5, 17);
            this.lblServerPort.Name = "lblServerPort";
            this.lblServerPort.Size = new System.Drawing.Size(60, 13);
            this.lblServerPort.TabIndex = 0;
            this.lblServerPort.Text = "Server Port";
            // 
            // btn_upgrade
            // 
            this.btn_upgrade.Location = new System.Drawing.Point(9, 230);
            this.btn_upgrade.Name = "btn_upgrade";
            this.btn_upgrade.Size = new System.Drawing.Size(195, 36);
            this.btn_upgrade.TabIndex = 2;
            this.btn_upgrade.Text = "Upgrade";
            this.btn_upgrade.UseVisualStyleBackColor = true;
            this.btn_upgrade.Click += new System.EventHandler(this.btn_upgrade_Click);
            // 
            // btn_sni
            // 
            this.btn_sni.Location = new System.Drawing.Point(9, 274);
            this.btn_sni.Name = "btn_sni";
            this.btn_sni.Size = new System.Drawing.Size(195, 36);
            this.btn_sni.TabIndex = 3;
            this.btn_sni.Text = "SNI";
            this.btn_sni.UseVisualStyleBackColor = true;
            this.btn_sni.Click += new System.EventHandler(this.btn_sni_Click);
            // 
            // btn_setLocalDenom
            // 
            this.btn_setLocalDenom.Location = new System.Drawing.Point(9, 321);
            this.btn_setLocalDenom.Name = "btn_setLocalDenom";
            this.btn_setLocalDenom.Size = new System.Drawing.Size(195, 36);
            this.btn_setLocalDenom.TabIndex = 4;
            this.btn_setLocalDenom.Text = "Set Local / Denom";
            this.btn_setLocalDenom.UseVisualStyleBackColor = true;
            this.btn_setLocalDenom.Click += new System.EventHandler(this.btn_setLocalDenom_Click);
            // 
            // tabProtocol
            // 
            this.tabProtocol.Controls.Add(this.tabPageIH110);
            this.tabProtocol.Controls.Add(this.tabPageST150N);
            this.tabProtocol.Controls.Add(this.tabPageST350);
            this.tabProtocol.Location = new System.Drawing.Point(216, 10);
            this.tabProtocol.Name = "tabProtocol";
            this.tabProtocol.SelectedIndex = 0;
            this.tabProtocol.Size = new System.Drawing.Size(546, 393);
            this.tabProtocol.TabIndex = 1;
            this.tabProtocol.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabProtocol_Selected);
            // 
            // tabPageIH110
            // 
            this.tabPageIH110.Controls.Add(this.btnGetSNIData);
            this.tabPageIH110.Controls.Add(this.btnGetMachineInfo);
            this.tabPageIH110.Controls.Add(this.btnSetBatchFunction);
            this.tabPageIH110.Controls.Add(this.btnSetAddMode);
            this.tabPageIH110.Controls.Add(this.btnSetUserSettingReset);
            this.tabPageIH110.Controls.Add(this.btnGetAllUser);
            this.tabPageIH110.Controls.Add(this.btnGetAllLocal);
            this.tabPageIH110.Controls.Add(this.btnSetBatch);
            this.tabPageIH110.Controls.Add(this.btnGetBatch);
            this.tabPageIH110.Controls.Add(this.btnInformStartStop);
            this.tabPageIH110.Controls.Add(this.btnGetMachineState);
            this.tabPageIH110.Controls.Add(this.btnSetMode);
            this.tabPageIH110.Controls.Add(this.btnGetSeries);
            this.tabPageIH110.Controls.Add(this.btnGetProduct);
            this.tabPageIH110.Controls.Add(this.btnGetMachineSN);
            this.tabPageIH110.Controls.Add(this.btnGetCountInfo);
            this.tabPageIH110.Controls.Add(this.btnGetDenomInfo);
            this.tabPageIH110.Controls.Add(this.btnGetLocal);
            this.tabPageIH110.Controls.Add(this.btnGetCountedResult);
            this.tabPageIH110.Controls.Add(this.btnGetPocketState);
            this.tabPageIH110.Controls.Add(this.btnGetMACWorkingState);
            this.tabPageIH110.Controls.Add(this.btnGetUserName);
            this.tabPageIH110.Controls.Add(this.txtParam);
            this.tabPageIH110.Controls.Add(this.lblParam);
            this.tabPageIH110.Controls.Add(this.btnReadyToWork);
            this.tabPageIH110.Location = new System.Drawing.Point(4, 22);
            this.tabPageIH110.Name = "tabPageIH110";
            this.tabPageIH110.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageIH110.Size = new System.Drawing.Size(538, 367);
            this.tabPageIH110.TabIndex = 0;
            this.tabPageIH110.Text = "[IH-110]";
            this.tabPageIH110.UseVisualStyleBackColor = true;
            // 
            // btnGetSNIData
            // 
            this.btnGetSNIData.Location = new System.Drawing.Point(363, 284);
            this.btnGetSNIData.Name = "btnGetSNIData";
            this.btnGetSNIData.Size = new System.Drawing.Size(163, 32);
            this.btnGetSNIData.TabIndex = 19;
            this.btnGetSNIData.Text = "[12-92] Get SNI Data";
            this.btnGetSNIData.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetSNIData.UseVisualStyleBackColor = true;
            this.btnGetSNIData.Click += new System.EventHandler(this.btnGetSNIData_Click);
            // 
            // btnGetMachineInfo
            // 
            this.btnGetMachineInfo.Location = new System.Drawing.Point(363, 245);
            this.btnGetMachineInfo.Name = "btnGetMachineInfo";
            this.btnGetMachineInfo.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineInfo.TabIndex = 18;
            this.btnGetMachineInfo.Text = "[50-01] Get Machine Info";
            this.btnGetMachineInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineInfo.UseVisualStyleBackColor = true;
            this.btnGetMachineInfo.Click += new System.EventHandler(this.btnGetMachineInfo_Click);
            // 
            // btnSetBatchFunction
            // 
            this.btnSetBatchFunction.Location = new System.Drawing.Point(363, 89);
            this.btnSetBatchFunction.Name = "btnSetBatchFunction";
            this.btnSetBatchFunction.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatchFunction.TabIndex = 17;
            this.btnSetBatchFunction.Text = "[12-66] Set Batch Function";
            this.btnSetBatchFunction.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatchFunction.UseVisualStyleBackColor = true;
            this.btnSetBatchFunction.Click += new System.EventHandler(this.btnSetBatchFunction_Click);
            // 
            // btnSetAddMode
            // 
            this.btnSetAddMode.Location = new System.Drawing.Point(363, 50);
            this.btnSetAddMode.Name = "btnSetAddMode";
            this.btnSetAddMode.Size = new System.Drawing.Size(163, 32);
            this.btnSetAddMode.TabIndex = 16;
            this.btnSetAddMode.Text = "[12-65] Set Add Mode";
            this.btnSetAddMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetAddMode.UseVisualStyleBackColor = true;
            this.btnSetAddMode.Click += new System.EventHandler(this.btnSetAddMode_Click);
            // 
            // btnSetUserSettingReset
            // 
            this.btnSetUserSettingReset.Location = new System.Drawing.Point(363, 206);
            this.btnSetUserSettingReset.Name = "btnSetUserSettingReset";
            this.btnSetUserSettingReset.Size = new System.Drawing.Size(163, 32);
            this.btnSetUserSettingReset.TabIndex = 15;
            this.btnSetUserSettingReset.Text = "[12-90] Set User Setting Reset";
            this.btnSetUserSettingReset.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetUserSettingReset.UseVisualStyleBackColor = true;
            this.btnSetUserSettingReset.Click += new System.EventHandler(this.btnSetUserSetting_Click);
            // 
            // btnGetAllUser
            // 
            this.btnGetAllUser.Location = new System.Drawing.Point(363, 167);
            this.btnGetAllUser.Name = "btnGetAllUser";
            this.btnGetAllUser.Size = new System.Drawing.Size(163, 32);
            this.btnGetAllUser.TabIndex = 15;
            this.btnGetAllUser.Text = "[12-80] Get All User";
            this.btnGetAllUser.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetAllUser.UseVisualStyleBackColor = true;
            this.btnGetAllUser.Click += new System.EventHandler(this.btnGetAllUser_Click);
            // 
            // btnGetAllLocal
            // 
            this.btnGetAllLocal.Location = new System.Drawing.Point(363, 128);
            this.btnGetAllLocal.Name = "btnGetAllLocal";
            this.btnGetAllLocal.Size = new System.Drawing.Size(163, 32);
            this.btnGetAllLocal.TabIndex = 15;
            this.btnGetAllLocal.Text = "[12-70] Get All Local";
            this.btnGetAllLocal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetAllLocal.UseVisualStyleBackColor = true;
            this.btnGetAllLocal.Click += new System.EventHandler(this.btnGetAllLocal_Click);
            // 
            // btnSetBatch
            // 
            this.btnSetBatch.Location = new System.Drawing.Point(188, 323);
            this.btnSetBatch.Name = "btnSetBatch";
            this.btnSetBatch.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatch.TabIndex = 15;
            this.btnSetBatch.Text = "[12-62] Set Batch";
            this.btnSetBatch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatch.UseVisualStyleBackColor = true;
            this.btnSetBatch.Click += new System.EventHandler(this.btnSetBatch_Click);
            // 
            // btnGetBatch
            // 
            this.btnGetBatch.Location = new System.Drawing.Point(188, 284);
            this.btnGetBatch.Name = "btnGetBatch";
            this.btnGetBatch.Size = new System.Drawing.Size(163, 32);
            this.btnGetBatch.TabIndex = 14;
            this.btnGetBatch.Text = "[12-61] Get Batch";
            this.btnGetBatch.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetBatch.UseVisualStyleBackColor = true;
            this.btnGetBatch.Click += new System.EventHandler(this.btnGetBatch_Click);
            // 
            // btnInformStartStop
            // 
            this.btnInformStartStop.Location = new System.Drawing.Point(188, 245);
            this.btnInformStartStop.Name = "btnInformStartStop";
            this.btnInformStartStop.Size = new System.Drawing.Size(163, 32);
            this.btnInformStartStop.TabIndex = 13;
            this.btnInformStartStop.Text = "[12-50] Inform Start / Stop";
            this.btnInformStartStop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInformStartStop.UseVisualStyleBackColor = true;
            this.btnInformStartStop.Click += new System.EventHandler(this.btnInformStartStop_Click);
            // 
            // btnGetMachineState
            // 
            this.btnGetMachineState.Location = new System.Drawing.Point(188, 206);
            this.btnGetMachineState.Name = "btnGetMachineState";
            this.btnGetMachineState.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineState.TabIndex = 12;
            this.btnGetMachineState.Text = "[12-40] Get Machine State";
            this.btnGetMachineState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineState.UseVisualStyleBackColor = true;
            this.btnGetMachineState.Click += new System.EventHandler(this.btnGetMachineState_Click);
            // 
            // btnSetMode
            // 
            this.btnSetMode.Location = new System.Drawing.Point(188, 167);
            this.btnSetMode.Name = "btnSetMode";
            this.btnSetMode.Size = new System.Drawing.Size(163, 32);
            this.btnSetMode.TabIndex = 12;
            this.btnSetMode.Text = "[12-33] Set Mode";
            this.btnSetMode.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetMode.UseVisualStyleBackColor = true;
            this.btnSetMode.Click += new System.EventHandler(this.btnSetMode_Click);
            // 
            // btnGetSeries
            // 
            this.btnGetSeries.Location = new System.Drawing.Point(188, 128);
            this.btnGetSeries.Name = "btnGetSeries";
            this.btnGetSeries.Size = new System.Drawing.Size(163, 32);
            this.btnGetSeries.TabIndex = 12;
            this.btnGetSeries.Text = "[12-21] Get Series";
            this.btnGetSeries.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetSeries.UseVisualStyleBackColor = true;
            this.btnGetSeries.Click += new System.EventHandler(this.btnGetSeries_Click);
            // 
            // btnGetProduct
            // 
            this.btnGetProduct.Location = new System.Drawing.Point(188, 89);
            this.btnGetProduct.Name = "btnGetProduct";
            this.btnGetProduct.Size = new System.Drawing.Size(163, 32);
            this.btnGetProduct.TabIndex = 11;
            this.btnGetProduct.Text = "[12-20] Get Product";
            this.btnGetProduct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetProduct.UseVisualStyleBackColor = true;
            this.btnGetProduct.Click += new System.EventHandler(this.btnGetProduct_Click);
            // 
            // btnGetMachineSN
            // 
            this.btnGetMachineSN.Location = new System.Drawing.Point(188, 50);
            this.btnGetMachineSN.Name = "btnGetMachineSN";
            this.btnGetMachineSN.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineSN.TabIndex = 10;
            this.btnGetMachineSN.Text = "[12-19] Get Machine SN";
            this.btnGetMachineSN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineSN.UseVisualStyleBackColor = true;
            this.btnGetMachineSN.Click += new System.EventHandler(this.btnGetMachineSN_Click);
            // 
            // btnGetCountInfo
            // 
            this.btnGetCountInfo.Location = new System.Drawing.Point(10, 323);
            this.btnGetCountInfo.Name = "btnGetCountInfo";
            this.btnGetCountInfo.Size = new System.Drawing.Size(163, 32);
            this.btnGetCountInfo.TabIndex = 9;
            this.btnGetCountInfo.Text = "[12-18] Get Count Info";
            this.btnGetCountInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetCountInfo.UseVisualStyleBackColor = true;
            this.btnGetCountInfo.Click += new System.EventHandler(this.btnGetCountInfo_Click);
            // 
            // btnGetDenomInfo
            // 
            this.btnGetDenomInfo.Location = new System.Drawing.Point(10, 284);
            this.btnGetDenomInfo.Name = "btnGetDenomInfo";
            this.btnGetDenomInfo.Size = new System.Drawing.Size(163, 32);
            this.btnGetDenomInfo.TabIndex = 8;
            this.btnGetDenomInfo.Text = "[12-17] Get Denom Info";
            this.btnGetDenomInfo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetDenomInfo.UseVisualStyleBackColor = true;
            this.btnGetDenomInfo.Click += new System.EventHandler(this.btnGetDenomInfo_Click);
            // 
            // btnGetLocal
            // 
            this.btnGetLocal.Location = new System.Drawing.Point(10, 245);
            this.btnGetLocal.Name = "btnGetLocal";
            this.btnGetLocal.Size = new System.Drawing.Size(163, 32);
            this.btnGetLocal.TabIndex = 7;
            this.btnGetLocal.Text = "[12-16] Get Local";
            this.btnGetLocal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetLocal.UseVisualStyleBackColor = true;
            this.btnGetLocal.Click += new System.EventHandler(this.btnGetLocal_Click);
            // 
            // btnGetCountedResult
            // 
            this.btnGetCountedResult.Location = new System.Drawing.Point(10, 206);
            this.btnGetCountedResult.Name = "btnGetCountedResult";
            this.btnGetCountedResult.Size = new System.Drawing.Size(163, 32);
            this.btnGetCountedResult.TabIndex = 6;
            this.btnGetCountedResult.Text = "[12-13] Get Counted Result";
            this.btnGetCountedResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetCountedResult.UseVisualStyleBackColor = true;
            this.btnGetCountedResult.Click += new System.EventHandler(this.btnGetCountedResult_Click);
            // 
            // btnGetPocketState
            // 
            this.btnGetPocketState.Location = new System.Drawing.Point(10, 167);
            this.btnGetPocketState.Name = "btnGetPocketState";
            this.btnGetPocketState.Size = new System.Drawing.Size(163, 32);
            this.btnGetPocketState.TabIndex = 5;
            this.btnGetPocketState.Text = "[12-12] Get Pocket State";
            this.btnGetPocketState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetPocketState.UseVisualStyleBackColor = true;
            this.btnGetPocketState.Click += new System.EventHandler(this.btnGetPocketState_Click);
            // 
            // btnGetMACWorkingState
            // 
            this.btnGetMACWorkingState.Location = new System.Drawing.Point(10, 128);
            this.btnGetMACWorkingState.Name = "btnGetMACWorkingState";
            this.btnGetMACWorkingState.Size = new System.Drawing.Size(163, 32);
            this.btnGetMACWorkingState.TabIndex = 4;
            this.btnGetMACWorkingState.Text = "[12-11] Get MAC Working State";
            this.btnGetMACWorkingState.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMACWorkingState.UseVisualStyleBackColor = true;
            this.btnGetMACWorkingState.Click += new System.EventHandler(this.btnGetMACWorkingState_Click);
            // 
            // btnGetUserName
            // 
            this.btnGetUserName.Location = new System.Drawing.Point(10, 89);
            this.btnGetUserName.Name = "btnGetUserName";
            this.btnGetUserName.Size = new System.Drawing.Size(163, 32);
            this.btnGetUserName.TabIndex = 3;
            this.btnGetUserName.Text = "[12-10] Get User Name";
            this.btnGetUserName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetUserName.UseVisualStyleBackColor = true;
            this.btnGetUserName.Click += new System.EventHandler(this.btnGetUserName_Click);
            // 
            // txtParam
            // 
            this.txtParam.Location = new System.Drawing.Point(64, 16);
            this.txtParam.Name = "txtParam";
            this.txtParam.Size = new System.Drawing.Size(86, 20);
            this.txtParam.TabIndex = 2;
            // 
            // lblParam
            // 
            this.lblParam.AutoSize = true;
            this.lblParam.Location = new System.Drawing.Point(9, 21);
            this.lblParam.Name = "lblParam";
            this.lblParam.Size = new System.Drawing.Size(51, 13);
            this.lblParam.TabIndex = 1;
            this.lblParam.Text = "PARAM :";
            // 
            // btnReadyToWork
            // 
            this.btnReadyToWork.Location = new System.Drawing.Point(10, 50);
            this.btnReadyToWork.Name = "btnReadyToWork";
            this.btnReadyToWork.Size = new System.Drawing.Size(163, 32);
            this.btnReadyToWork.TabIndex = 0;
            this.btnReadyToWork.Text = "[12-02] Ready To Work";
            this.btnReadyToWork.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadyToWork.UseVisualStyleBackColor = true;
            this.btnReadyToWork.Click += new System.EventHandler(this.btnReadyToWork_Click);
            // 
            // tabPageST150N
            // 
            this.tabPageST150N.Controls.Add(this.btnGetAppVersionST150N);
            this.tabPageST150N.Controls.Add(this.btnSetBatchModeST150N);
            this.tabPageST150N.Controls.Add(this.btnSetAddModeST150N);
            this.tabPageST150N.Controls.Add(this.btnSetCountingModeST150N);
            this.tabPageST150N.Controls.Add(this.btnSetBatchPresetModeST150N);
            this.tabPageST150N.Controls.Add(this.btnSetBatchST150N);
            this.tabPageST150N.Controls.Add(this.btnGetBatchST150N);
            this.tabPageST150N.Controls.Add(this.btnGetPocketResultST150N);
            this.tabPageST150N.Controls.Add(this.btnInformStartStopST150N);
            this.tabPageST150N.Controls.Add(this.btnGetResultCodeST150N);
            this.tabPageST150N.Controls.Add(this.btnGetMachineStateST150N);
            this.tabPageST150N.Controls.Add(this.btnGetSeriesST150N);
            this.tabPageST150N.Controls.Add(this.btnGetProductST150N);
            this.tabPageST150N.Controls.Add(this.btnGetMachineSNST150N);
            this.tabPageST150N.Controls.Add(this.btnGetCountInfoST150N);
            this.tabPageST150N.Controls.Add(this.btnGetDenomInfoST150N);
            this.tabPageST150N.Controls.Add(this.btnGetLocalST150N);
            this.tabPageST150N.Controls.Add(this.btnGetCountedResultST150N);
            this.tabPageST150N.Controls.Add(this.btnGetPocketStateST150N);
            this.tabPageST150N.Controls.Add(this.btnGetMACWorkingStateST150N);
            this.tabPageST150N.Controls.Add(this.btnGetUserNameST150N);
            this.tabPageST150N.Controls.Add(this.btnReadyToWorkST150N);
            this.tabPageST150N.Controls.Add(this.txtParamST150N);
            this.tabPageST150N.Controls.Add(this.lblParamST150N);
            this.tabPageST150N.Location = new System.Drawing.Point(4, 22);
            this.tabPageST150N.Name = "tabPageST150N";
            this.tabPageST150N.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageST150N.Size = new System.Drawing.Size(538, 367);
            this.tabPageST150N.TabIndex = 1;
            this.tabPageST150N.Text = "[ST-150N]";
            this.tabPageST150N.UseVisualStyleBackColor = true;
            // 
            // btnGetAppVersionST150N
            // 
            this.btnGetAppVersionST150N.Location = new System.Drawing.Point(188, 167);
            this.btnGetAppVersionST150N.Name = "btnGetAppVersionST150N";
            this.btnGetAppVersionST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetAppVersionST150N.TabIndex = 23;
            this.btnGetAppVersionST150N.Text = "[12-22] Get App Version";
            this.btnGetAppVersionST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetAppVersionST150N.UseVisualStyleBackColor = true;
            this.btnGetAppVersionST150N.Click += new System.EventHandler(this.btnGetAppVersionST150N_Click);
            // 
            // btnSetBatchModeST150N
            // 
            this.btnSetBatchModeST150N.Location = new System.Drawing.Point(365, 245);
            this.btnSetBatchModeST150N.Name = "btnSetBatchModeST150N";
            this.btnSetBatchModeST150N.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatchModeST150N.TabIndex = 22;
            this.btnSetBatchModeST150N.Text = "[12-66] Set Batch Function";
            this.btnSetBatchModeST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatchModeST150N.UseVisualStyleBackColor = true;
            this.btnSetBatchModeST150N.Click += new System.EventHandler(this.btnSetBatchModeST150N_Click);
            // 
            // btnSetAddModeST150N
            // 
            this.btnSetAddModeST150N.Location = new System.Drawing.Point(365, 206);
            this.btnSetAddModeST150N.Name = "btnSetAddModeST150N";
            this.btnSetAddModeST150N.Size = new System.Drawing.Size(163, 32);
            this.btnSetAddModeST150N.TabIndex = 21;
            this.btnSetAddModeST150N.Text = "[12-65] Set Add Mode";
            this.btnSetAddModeST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetAddModeST150N.UseVisualStyleBackColor = true;
            this.btnSetAddModeST150N.Click += new System.EventHandler(this.btnSetAddModeST150N_Click);
            // 
            // btnSetCountingModeST150N
            // 
            this.btnSetCountingModeST150N.Location = new System.Drawing.Point(365, 167);
            this.btnSetCountingModeST150N.Name = "btnSetCountingModeST150N";
            this.btnSetCountingModeST150N.Size = new System.Drawing.Size(163, 32);
            this.btnSetCountingModeST150N.TabIndex = 20;
            this.btnSetCountingModeST150N.Text = "[12-64] Set Counting Mode";
            this.btnSetCountingModeST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetCountingModeST150N.UseVisualStyleBackColor = true;
            this.btnSetCountingModeST150N.Click += new System.EventHandler(this.btnSetCountingModeST150N_Click);
            // 
            // btnSetBatchPresetModeST150N
            // 
            this.btnSetBatchPresetModeST150N.Location = new System.Drawing.Point(365, 128);
            this.btnSetBatchPresetModeST150N.Name = "btnSetBatchPresetModeST150N";
            this.btnSetBatchPresetModeST150N.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatchPresetModeST150N.TabIndex = 19;
            this.btnSetBatchPresetModeST150N.Text = "[12-63] Set Batch Preset Mode";
            this.btnSetBatchPresetModeST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatchPresetModeST150N.UseVisualStyleBackColor = true;
            this.btnSetBatchPresetModeST150N.Click += new System.EventHandler(this.btnSetBatchPresetModeST150N_Click);
            // 
            // btnSetBatchST150N
            // 
            this.btnSetBatchST150N.Location = new System.Drawing.Point(365, 89);
            this.btnSetBatchST150N.Name = "btnSetBatchST150N";
            this.btnSetBatchST150N.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatchST150N.TabIndex = 18;
            this.btnSetBatchST150N.Text = "[12-62] Set Batch";
            this.btnSetBatchST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatchST150N.UseVisualStyleBackColor = true;
            this.btnSetBatchST150N.Click += new System.EventHandler(this.btnSetBatchST150N_Click);
            // 
            // btnGetBatchST150N
            // 
            this.btnGetBatchST150N.Location = new System.Drawing.Point(365, 50);
            this.btnGetBatchST150N.Name = "btnGetBatchST150N";
            this.btnGetBatchST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetBatchST150N.TabIndex = 17;
            this.btnGetBatchST150N.Text = "[12-61] Get Batch";
            this.btnGetBatchST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetBatchST150N.UseVisualStyleBackColor = true;
            this.btnGetBatchST150N.Click += new System.EventHandler(this.btnGetBatchST150N_Click);
            // 
            // btnGetPocketResultST150N
            // 
            this.btnGetPocketResultST150N.Location = new System.Drawing.Point(188, 323);
            this.btnGetPocketResultST150N.Name = "btnGetPocketResultST150N";
            this.btnGetPocketResultST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetPocketResultST150N.TabIndex = 16;
            this.btnGetPocketResultST150N.Text = "[12-60] Get Pocket Result";
            this.btnGetPocketResultST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetPocketResultST150N.UseVisualStyleBackColor = true;
            this.btnGetPocketResultST150N.Click += new System.EventHandler(this.btnGetPocketResultST150N_Click);
            // 
            // btnInformStartStopST150N
            // 
            this.btnInformStartStopST150N.Location = new System.Drawing.Point(188, 284);
            this.btnInformStartStopST150N.Name = "btnInformStartStopST150N";
            this.btnInformStartStopST150N.Size = new System.Drawing.Size(163, 32);
            this.btnInformStartStopST150N.TabIndex = 15;
            this.btnInformStartStopST150N.Text = "[12-50] Inform Start / Stop";
            this.btnInformStartStopST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInformStartStopST150N.UseVisualStyleBackColor = true;
            this.btnInformStartStopST150N.Click += new System.EventHandler(this.btnInformStartStopST150N_Click);
            // 
            // btnGetResultCodeST150N
            // 
            this.btnGetResultCodeST150N.Location = new System.Drawing.Point(188, 245);
            this.btnGetResultCodeST150N.Name = "btnGetResultCodeST150N";
            this.btnGetResultCodeST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetResultCodeST150N.TabIndex = 14;
            this.btnGetResultCodeST150N.Text = "[12-41] Get Result Code";
            this.btnGetResultCodeST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetResultCodeST150N.UseVisualStyleBackColor = true;
            this.btnGetResultCodeST150N.Click += new System.EventHandler(this.btnGetResultCodeST150N_Click);
            // 
            // btnGetMachineStateST150N
            // 
            this.btnGetMachineStateST150N.Location = new System.Drawing.Point(188, 206);
            this.btnGetMachineStateST150N.Name = "btnGetMachineStateST150N";
            this.btnGetMachineStateST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineStateST150N.TabIndex = 13;
            this.btnGetMachineStateST150N.Text = "[12-40] Get Machine State";
            this.btnGetMachineStateST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineStateST150N.UseVisualStyleBackColor = true;
            this.btnGetMachineStateST150N.Click += new System.EventHandler(this.btnGetMachineStateST150N_Click);
            // 
            // btnGetSeriesST150N
            // 
            this.btnGetSeriesST150N.Location = new System.Drawing.Point(188, 128);
            this.btnGetSeriesST150N.Name = "btnGetSeriesST150N";
            this.btnGetSeriesST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetSeriesST150N.TabIndex = 12;
            this.btnGetSeriesST150N.Text = "[12-21] Get Series";
            this.btnGetSeriesST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetSeriesST150N.UseVisualStyleBackColor = true;
            this.btnGetSeriesST150N.Click += new System.EventHandler(this.btnGetSeriesST150N_Click);
            // 
            // btnGetProductST150N
            // 
            this.btnGetProductST150N.Location = new System.Drawing.Point(188, 89);
            this.btnGetProductST150N.Name = "btnGetProductST150N";
            this.btnGetProductST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetProductST150N.TabIndex = 11;
            this.btnGetProductST150N.Text = "[12-20] Get Product";
            this.btnGetProductST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetProductST150N.UseVisualStyleBackColor = true;
            this.btnGetProductST150N.Click += new System.EventHandler(this.btnGetProductST150N_Click);
            // 
            // btnGetMachineSNST150N
            // 
            this.btnGetMachineSNST150N.Location = new System.Drawing.Point(188, 50);
            this.btnGetMachineSNST150N.Name = "btnGetMachineSNST150N";
            this.btnGetMachineSNST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineSNST150N.TabIndex = 10;
            this.btnGetMachineSNST150N.Text = "[12-19] Get Machine SN";
            this.btnGetMachineSNST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineSNST150N.UseVisualStyleBackColor = true;
            this.btnGetMachineSNST150N.Click += new System.EventHandler(this.btnGetMachineSNST150N_Click);
            // 
            // btnGetCountInfoST150N
            // 
            this.btnGetCountInfoST150N.Location = new System.Drawing.Point(10, 323);
            this.btnGetCountInfoST150N.Name = "btnGetCountInfoST150N";
            this.btnGetCountInfoST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetCountInfoST150N.TabIndex = 9;
            this.btnGetCountInfoST150N.Text = "[12-18] Get Count Info";
            this.btnGetCountInfoST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetCountInfoST150N.UseVisualStyleBackColor = true;
            this.btnGetCountInfoST150N.Click += new System.EventHandler(this.btnGetCountInfoST150N_Click);
            // 
            // btnGetDenomInfoST150N
            // 
            this.btnGetDenomInfoST150N.Location = new System.Drawing.Point(10, 284);
            this.btnGetDenomInfoST150N.Name = "btnGetDenomInfoST150N";
            this.btnGetDenomInfoST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetDenomInfoST150N.TabIndex = 8;
            this.btnGetDenomInfoST150N.Text = "[12-17] Get Denom Info";
            this.btnGetDenomInfoST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetDenomInfoST150N.UseVisualStyleBackColor = true;
            this.btnGetDenomInfoST150N.Click += new System.EventHandler(this.btnGetDenomInfoST150N_Click);
            // 
            // btnGetLocalST150N
            // 
            this.btnGetLocalST150N.Location = new System.Drawing.Point(10, 245);
            this.btnGetLocalST150N.Name = "btnGetLocalST150N";
            this.btnGetLocalST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetLocalST150N.TabIndex = 7;
            this.btnGetLocalST150N.Text = "[12-16] Get Local";
            this.btnGetLocalST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetLocalST150N.UseVisualStyleBackColor = true;
            this.btnGetLocalST150N.Click += new System.EventHandler(this.btnGetLocalST150N_Click);
            // 
            // btnGetCountedResultST150N
            // 
            this.btnGetCountedResultST150N.Location = new System.Drawing.Point(10, 206);
            this.btnGetCountedResultST150N.Name = "btnGetCountedResultST150N";
            this.btnGetCountedResultST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetCountedResultST150N.TabIndex = 6;
            this.btnGetCountedResultST150N.Text = "[12-13] Get Counted Result";
            this.btnGetCountedResultST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetCountedResultST150N.UseVisualStyleBackColor = true;
            this.btnGetCountedResultST150N.Click += new System.EventHandler(this.btnGetCountedResultST150N_Click);
            // 
            // btnGetPocketStateST150N
            // 
            this.btnGetPocketStateST150N.Location = new System.Drawing.Point(10, 167);
            this.btnGetPocketStateST150N.Name = "btnGetPocketStateST150N";
            this.btnGetPocketStateST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetPocketStateST150N.TabIndex = 5;
            this.btnGetPocketStateST150N.Text = "[12-12] Get Pocket State";
            this.btnGetPocketStateST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetPocketStateST150N.UseVisualStyleBackColor = true;
            this.btnGetPocketStateST150N.Click += new System.EventHandler(this.btnGetPocketStateST150N_Click);
            // 
            // btnGetMACWorkingStateST150N
            // 
            this.btnGetMACWorkingStateST150N.Location = new System.Drawing.Point(10, 128);
            this.btnGetMACWorkingStateST150N.Name = "btnGetMACWorkingStateST150N";
            this.btnGetMACWorkingStateST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetMACWorkingStateST150N.TabIndex = 4;
            this.btnGetMACWorkingStateST150N.Text = "[12-11] Get MAC Working State";
            this.btnGetMACWorkingStateST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMACWorkingStateST150N.UseVisualStyleBackColor = true;
            this.btnGetMACWorkingStateST150N.Click += new System.EventHandler(this.btnGetMACWorkingStateST150N_Click);
            // 
            // btnGetUserNameST150N
            // 
            this.btnGetUserNameST150N.Location = new System.Drawing.Point(10, 89);
            this.btnGetUserNameST150N.Name = "btnGetUserNameST150N";
            this.btnGetUserNameST150N.Size = new System.Drawing.Size(163, 32);
            this.btnGetUserNameST150N.TabIndex = 3;
            this.btnGetUserNameST150N.Text = "[12-10] Get User Name";
            this.btnGetUserNameST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetUserNameST150N.UseVisualStyleBackColor = true;
            this.btnGetUserNameST150N.Click += new System.EventHandler(this.btnGetUserNameST150N_Click);
            // 
            // btnReadyToWorkST150N
            // 
            this.btnReadyToWorkST150N.Location = new System.Drawing.Point(10, 50);
            this.btnReadyToWorkST150N.Name = "btnReadyToWorkST150N";
            this.btnReadyToWorkST150N.Size = new System.Drawing.Size(163, 32);
            this.btnReadyToWorkST150N.TabIndex = 2;
            this.btnReadyToWorkST150N.Text = "[12-02] Ready To Work";
            this.btnReadyToWorkST150N.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadyToWorkST150N.UseVisualStyleBackColor = true;
            this.btnReadyToWorkST150N.Click += new System.EventHandler(this.btnReadyToWorkST150N_Click);
            // 
            // txtParamST150N
            // 
            this.txtParamST150N.Location = new System.Drawing.Point(64, 16);
            this.txtParamST150N.Name = "txtParamST150N";
            this.txtParamST150N.Size = new System.Drawing.Size(86, 20);
            this.txtParamST150N.TabIndex = 1;
            // 
            // lblParamST150N
            // 
            this.lblParamST150N.AutoSize = true;
            this.lblParamST150N.Location = new System.Drawing.Point(9, 21);
            this.lblParamST150N.Name = "lblParamST150N";
            this.lblParamST150N.Size = new System.Drawing.Size(51, 13);
            this.lblParamST150N.TabIndex = 0;
            this.lblParamST150N.Text = "PARAM :";
            // 
            // tabPageST350
            // 
            this.tabPageST350.Controls.Add(this.btnGetAppVersionST350);
            this.tabPageST350.Controls.Add(this.btnSetBatchPresetModeST350);
            this.tabPageST350.Controls.Add(this.btnSetBatchST350);
            this.tabPageST350.Controls.Add(this.btnGetBatchST350);
            this.tabPageST350.Controls.Add(this.btnGetPocketResultST350);
            this.tabPageST350.Controls.Add(this.btnInformStartStopST350);
            this.tabPageST350.Controls.Add(this.btnGetResultCodeST350);
            this.tabPageST350.Controls.Add(this.btnGetMachineStateST350);
            this.tabPageST350.Controls.Add(this.btnGetSeriesST350);
            this.tabPageST350.Controls.Add(this.btnGetProductST350);
            this.tabPageST350.Controls.Add(this.btnGetMachineSNST350);
            this.tabPageST350.Controls.Add(this.btnGetCountInfoST350);
            this.tabPageST350.Controls.Add(this.btnGetDnomInfoST350);
            this.tabPageST350.Controls.Add(this.btnGetLocalST350);
            this.tabPageST350.Controls.Add(this.btnGetCountedResultST350);
            this.tabPageST350.Controls.Add(this.btnGetPocketStateST350);
            this.tabPageST350.Controls.Add(this.btnGetMACWorkingStateST350);
            this.tabPageST350.Controls.Add(this.btnGetUserNameST350);
            this.tabPageST350.Controls.Add(this.btnReadyToWorkST350);
            this.tabPageST350.Controls.Add(this.txtParamST350);
            this.tabPageST350.Controls.Add(this.lblParamST350);
            this.tabPageST350.Location = new System.Drawing.Point(4, 22);
            this.tabPageST350.Name = "tabPageST350";
            this.tabPageST350.Size = new System.Drawing.Size(538, 367);
            this.tabPageST350.TabIndex = 2;
            this.tabPageST350.Text = "[ST-350]";
            this.tabPageST350.UseVisualStyleBackColor = true;
            // 
            // btnGetAppVersionST350
            // 
            this.btnGetAppVersionST350.Location = new System.Drawing.Point(188, 167);
            this.btnGetAppVersionST350.Name = "btnGetAppVersionST350";
            this.btnGetAppVersionST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetAppVersionST350.TabIndex = 20;
            this.btnGetAppVersionST350.Text = "[12-22] Get App Version";
            this.btnGetAppVersionST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetAppVersionST350.UseVisualStyleBackColor = true;
            this.btnGetAppVersionST350.Click += new System.EventHandler(this.btnGetAppVersionST350_Click);
            // 
            // btnSetBatchPresetModeST350
            // 
            this.btnSetBatchPresetModeST350.Location = new System.Drawing.Point(365, 128);
            this.btnSetBatchPresetModeST350.Name = "btnSetBatchPresetModeST350";
            this.btnSetBatchPresetModeST350.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatchPresetModeST350.TabIndex = 19;
            this.btnSetBatchPresetModeST350.Text = "[12-63] Set Batch Preset Mode";
            this.btnSetBatchPresetModeST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatchPresetModeST350.UseVisualStyleBackColor = true;
            this.btnSetBatchPresetModeST350.Click += new System.EventHandler(this.btnSetBatchPresetModeST350_Click);
            // 
            // btnSetBatchST350
            // 
            this.btnSetBatchST350.Location = new System.Drawing.Point(365, 89);
            this.btnSetBatchST350.Name = "btnSetBatchST350";
            this.btnSetBatchST350.Size = new System.Drawing.Size(163, 32);
            this.btnSetBatchST350.TabIndex = 18;
            this.btnSetBatchST350.Text = "[12-62] Set Batch";
            this.btnSetBatchST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSetBatchST350.UseVisualStyleBackColor = true;
            this.btnSetBatchST350.Click += new System.EventHandler(this.btnSetBatchST350_Click);
            // 
            // btnGetBatchST350
            // 
            this.btnGetBatchST350.Location = new System.Drawing.Point(365, 50);
            this.btnGetBatchST350.Name = "btnGetBatchST350";
            this.btnGetBatchST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetBatchST350.TabIndex = 17;
            this.btnGetBatchST350.Text = "[12-61] Get Batch";
            this.btnGetBatchST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetBatchST350.UseVisualStyleBackColor = true;
            this.btnGetBatchST350.Click += new System.EventHandler(this.btnGetBatchST350_Click);
            // 
            // btnGetPocketResultST350
            // 
            this.btnGetPocketResultST350.Location = new System.Drawing.Point(188, 323);
            this.btnGetPocketResultST350.Name = "btnGetPocketResultST350";
            this.btnGetPocketResultST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetPocketResultST350.TabIndex = 16;
            this.btnGetPocketResultST350.Text = "[12-60] Get Pocket Result";
            this.btnGetPocketResultST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetPocketResultST350.UseVisualStyleBackColor = true;
            this.btnGetPocketResultST350.Click += new System.EventHandler(this.btnGetPocketResultST350_Click);
            // 
            // btnInformStartStopST350
            // 
            this.btnInformStartStopST350.Location = new System.Drawing.Point(188, 284);
            this.btnInformStartStopST350.Name = "btnInformStartStopST350";
            this.btnInformStartStopST350.Size = new System.Drawing.Size(163, 32);
            this.btnInformStartStopST350.TabIndex = 15;
            this.btnInformStartStopST350.Text = "[12-50] Inform Start / Stop";
            this.btnInformStartStopST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInformStartStopST350.UseVisualStyleBackColor = true;
            this.btnInformStartStopST350.Click += new System.EventHandler(this.btnInformStartStopST350_Click);
            // 
            // btnGetResultCodeST350
            // 
            this.btnGetResultCodeST350.Location = new System.Drawing.Point(188, 245);
            this.btnGetResultCodeST350.Name = "btnGetResultCodeST350";
            this.btnGetResultCodeST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetResultCodeST350.TabIndex = 14;
            this.btnGetResultCodeST350.Text = "[12-41] Get Result Code";
            this.btnGetResultCodeST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetResultCodeST350.UseVisualStyleBackColor = true;
            this.btnGetResultCodeST350.Click += new System.EventHandler(this.btnGetResultCodeST350_Click);
            // 
            // btnGetMachineStateST350
            // 
            this.btnGetMachineStateST350.Location = new System.Drawing.Point(188, 206);
            this.btnGetMachineStateST350.Name = "btnGetMachineStateST350";
            this.btnGetMachineStateST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineStateST350.TabIndex = 13;
            this.btnGetMachineStateST350.Text = "[12-40] Get Machine State";
            this.btnGetMachineStateST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineStateST350.UseVisualStyleBackColor = true;
            this.btnGetMachineStateST350.Click += new System.EventHandler(this.btnGetMachineStateST350_Click);
            // 
            // btnGetSeriesST350
            // 
            this.btnGetSeriesST350.Location = new System.Drawing.Point(188, 128);
            this.btnGetSeriesST350.Name = "btnGetSeriesST350";
            this.btnGetSeriesST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetSeriesST350.TabIndex = 12;
            this.btnGetSeriesST350.Text = "[12-21] Get Series";
            this.btnGetSeriesST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetSeriesST350.UseVisualStyleBackColor = true;
            this.btnGetSeriesST350.Click += new System.EventHandler(this.btnGetSeriesST350_Click);
            // 
            // btnGetProductST350
            // 
            this.btnGetProductST350.Location = new System.Drawing.Point(188, 89);
            this.btnGetProductST350.Name = "btnGetProductST350";
            this.btnGetProductST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetProductST350.TabIndex = 11;
            this.btnGetProductST350.Text = "[12-20] Get Product";
            this.btnGetProductST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetProductST350.UseVisualStyleBackColor = true;
            this.btnGetProductST350.Click += new System.EventHandler(this.btnGetProductST350_Click);
            // 
            // btnGetMachineSNST350
            // 
            this.btnGetMachineSNST350.Location = new System.Drawing.Point(188, 50);
            this.btnGetMachineSNST350.Name = "btnGetMachineSNST350";
            this.btnGetMachineSNST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetMachineSNST350.TabIndex = 10;
            this.btnGetMachineSNST350.Text = "[12-19] Get Machine SN";
            this.btnGetMachineSNST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMachineSNST350.UseVisualStyleBackColor = true;
            this.btnGetMachineSNST350.Click += new System.EventHandler(this.btnGetMachineSNST350_Click);
            // 
            // btnGetCountInfoST350
            // 
            this.btnGetCountInfoST350.Location = new System.Drawing.Point(10, 323);
            this.btnGetCountInfoST350.Name = "btnGetCountInfoST350";
            this.btnGetCountInfoST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetCountInfoST350.TabIndex = 9;
            this.btnGetCountInfoST350.Text = "[12-18] Get Count Info";
            this.btnGetCountInfoST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetCountInfoST350.UseVisualStyleBackColor = true;
            this.btnGetCountInfoST350.Click += new System.EventHandler(this.btnGetCountInfoST350_Click);
            // 
            // btnGetDnomInfoST350
            // 
            this.btnGetDnomInfoST350.Location = new System.Drawing.Point(10, 284);
            this.btnGetDnomInfoST350.Name = "btnGetDnomInfoST350";
            this.btnGetDnomInfoST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetDnomInfoST350.TabIndex = 8;
            this.btnGetDnomInfoST350.Text = "[12-17] Get Denom Info";
            this.btnGetDnomInfoST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetDnomInfoST350.UseVisualStyleBackColor = true;
            this.btnGetDnomInfoST350.Click += new System.EventHandler(this.btnGetDnomInfoST350_Click);
            // 
            // btnGetLocalST350
            // 
            this.btnGetLocalST350.Location = new System.Drawing.Point(10, 245);
            this.btnGetLocalST350.Name = "btnGetLocalST350";
            this.btnGetLocalST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetLocalST350.TabIndex = 7;
            this.btnGetLocalST350.Text = "[12-16] Get Local";
            this.btnGetLocalST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetLocalST350.UseVisualStyleBackColor = true;
            this.btnGetLocalST350.Click += new System.EventHandler(this.btnGetLocalST350_Click);
            // 
            // btnGetCountedResultST350
            // 
            this.btnGetCountedResultST350.Location = new System.Drawing.Point(10, 206);
            this.btnGetCountedResultST350.Name = "btnGetCountedResultST350";
            this.btnGetCountedResultST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetCountedResultST350.TabIndex = 6;
            this.btnGetCountedResultST350.Text = "[12-13] Get Counted Result";
            this.btnGetCountedResultST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetCountedResultST350.UseVisualStyleBackColor = true;
            this.btnGetCountedResultST350.Click += new System.EventHandler(this.btnGetCountedResultST350_Click);
            // 
            // btnGetPocketStateST350
            // 
            this.btnGetPocketStateST350.Location = new System.Drawing.Point(10, 167);
            this.btnGetPocketStateST350.Name = "btnGetPocketStateST350";
            this.btnGetPocketStateST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetPocketStateST350.TabIndex = 5;
            this.btnGetPocketStateST350.Text = "[12-12] Get Pocket State";
            this.btnGetPocketStateST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetPocketStateST350.UseVisualStyleBackColor = true;
            this.btnGetPocketStateST350.Click += new System.EventHandler(this.btnGetPocketStateST350_Click);
            // 
            // btnGetMACWorkingStateST350
            // 
            this.btnGetMACWorkingStateST350.Location = new System.Drawing.Point(10, 128);
            this.btnGetMACWorkingStateST350.Name = "btnGetMACWorkingStateST350";
            this.btnGetMACWorkingStateST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetMACWorkingStateST350.TabIndex = 4;
            this.btnGetMACWorkingStateST350.Text = "[12-11] Get MAC Working State";
            this.btnGetMACWorkingStateST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetMACWorkingStateST350.UseVisualStyleBackColor = true;
            this.btnGetMACWorkingStateST350.Click += new System.EventHandler(this.btnGetMACWorkingStateST350_Click);
            // 
            // btnGetUserNameST350
            // 
            this.btnGetUserNameST350.Location = new System.Drawing.Point(10, 89);
            this.btnGetUserNameST350.Name = "btnGetUserNameST350";
            this.btnGetUserNameST350.Size = new System.Drawing.Size(163, 32);
            this.btnGetUserNameST350.TabIndex = 3;
            this.btnGetUserNameST350.Text = "[12-10] Get User Name";
            this.btnGetUserNameST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetUserNameST350.UseVisualStyleBackColor = true;
            this.btnGetUserNameST350.Click += new System.EventHandler(this.btnGetUserNameST350_Click);
            // 
            // btnReadyToWorkST350
            // 
            this.btnReadyToWorkST350.Location = new System.Drawing.Point(10, 50);
            this.btnReadyToWorkST350.Name = "btnReadyToWorkST350";
            this.btnReadyToWorkST350.Size = new System.Drawing.Size(163, 32);
            this.btnReadyToWorkST350.TabIndex = 2;
            this.btnReadyToWorkST350.Text = "[12-02] Ready To Work";
            this.btnReadyToWorkST350.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReadyToWorkST350.UseVisualStyleBackColor = true;
            this.btnReadyToWorkST350.Click += new System.EventHandler(this.btnReadyToWorkST350_Click);
            // 
            // txtParamST350
            // 
            this.txtParamST350.Location = new System.Drawing.Point(64, 16);
            this.txtParamST350.Name = "txtParamST350";
            this.txtParamST350.Size = new System.Drawing.Size(86, 20);
            this.txtParamST350.TabIndex = 1;
            // 
            // lblParamST350
            // 
            this.lblParamST350.AutoSize = true;
            this.lblParamST350.Location = new System.Drawing.Point(9, 21);
            this.lblParamST350.Name = "lblParamST350";
            this.lblParamST350.Size = new System.Drawing.Size(51, 13);
            this.lblParamST350.TabIndex = 0;
            this.lblParamST350.Text = "PARAM :";
            // 
            // Form_ProtocolDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(773, 840);
            this.Controls.Add(this.tabProtocol);
            this.Controls.Add(this.btn_setLocalDenom);
            this.Controls.Add(this.btn_sni);
            this.Controls.Add(this.btn_upgrade);
            this.Controls.Add(this.tabConnect);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.txt_recvData_ascii);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form_ProtocolDemo";
            this.Text = "Protocol Demo [2023.02.15] - V 1.1.2_ETAS";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form_ProtocolDemo_Load);
            this.tabConnect.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabProtocol.ResumeLayout(false);
            this.tabPageIH110.ResumeLayout(false);
            this.tabPageIH110.PerformLayout();
            this.tabPageST150N.ResumeLayout(false);
            this.tabPageST150N.PerformLayout();
            this.tabPageST350.ResumeLayout(false);
            this.tabPageST350.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbb_portName;
        private System.Windows.Forms.ComboBox cbb_baudRate;
        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.Label lblComPortState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_recvData_ascii;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.TabControl tabConnect;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblServerPort;
        private System.Windows.Forms.TextBox txtServerPort;
        private System.Windows.Forms.Button btnServerStart;
        private System.Windows.Forms.Label lblServerState;
        private System.Windows.Forms.Button btn_upgrade;
        private System.Windows.Forms.Button btn_sni;
        private System.Windows.Forms.Button btn_setLocalDenom;
        private System.Windows.Forms.TabControl tabProtocol;
        private System.Windows.Forms.TabPage tabPageIH110;
        private System.Windows.Forms.TabPage tabPageST150N;
        private System.Windows.Forms.TabPage tabPageST350;
        private System.Windows.Forms.Button btnGetMACWorkingState;
        private System.Windows.Forms.Button btnGetUserName;
        private System.Windows.Forms.TextBox txtParam;
        private System.Windows.Forms.Label lblParam;
        private System.Windows.Forms.Button btnReadyToWork;
        private System.Windows.Forms.Button btnGetPocketState;
        private System.Windows.Forms.Button btnGetCountedResult;
        private System.Windows.Forms.Button btnGetLocal;
        private System.Windows.Forms.Button btnGetCountInfo;
        private System.Windows.Forms.Button btnGetDenomInfo;
        private System.Windows.Forms.Button btnSetBatch;
        private System.Windows.Forms.Button btnGetBatch;
        private System.Windows.Forms.Button btnInformStartStop;
        private System.Windows.Forms.Button btnGetSeries;
        private System.Windows.Forms.Button btnGetProduct;
        private System.Windows.Forms.Button btnGetMachineSN;
        private System.Windows.Forms.TextBox txtParamST150N;
        private System.Windows.Forms.Label lblParamST150N;
        private System.Windows.Forms.Button btnReadyToWorkST150N;
        private System.Windows.Forms.Button btnGetDenomInfoST150N;
        private System.Windows.Forms.Button btnGetLocalST150N;
        private System.Windows.Forms.Button btnGetCountedResultST150N;
        private System.Windows.Forms.Button btnGetPocketStateST150N;
        private System.Windows.Forms.Button btnGetMACWorkingStateST150N;
        private System.Windows.Forms.Button btnGetUserNameST150N;
        private System.Windows.Forms.Button btnGetMachineSNST150N;
        private System.Windows.Forms.Button btnGetCountInfoST150N;
        private System.Windows.Forms.Button btnInformStartStopST150N;
        private System.Windows.Forms.Button btnGetResultCodeST150N;
        private System.Windows.Forms.Button btnGetMachineStateST150N;
        private System.Windows.Forms.Button btnGetSeriesST150N;
        private System.Windows.Forms.Button btnGetProductST150N;
        private System.Windows.Forms.Button btnSetBatchModeST150N;
        private System.Windows.Forms.Button btnSetAddModeST150N;
        private System.Windows.Forms.Button btnSetCountingModeST150N;
        private System.Windows.Forms.Button btnSetBatchPresetModeST150N;
        private System.Windows.Forms.Button btnSetBatchST150N;
        private System.Windows.Forms.Button btnGetBatchST150N;
        private System.Windows.Forms.Button btnGetPocketResultST150N;
        private System.Windows.Forms.TextBox txtParamST350;
        private System.Windows.Forms.Label lblParamST350;
        private System.Windows.Forms.Button btnGetResultCodeST350;
        private System.Windows.Forms.Button btnGetMachineStateST350;
        private System.Windows.Forms.Button btnGetSeriesST350;
        private System.Windows.Forms.Button btnGetProductST350;
        private System.Windows.Forms.Button btnGetMachineSNST350;
        private System.Windows.Forms.Button btnGetCountInfoST350;
        private System.Windows.Forms.Button btnGetDnomInfoST350;
        private System.Windows.Forms.Button btnGetLocalST350;
        private System.Windows.Forms.Button btnGetCountedResultST350;
        private System.Windows.Forms.Button btnGetPocketStateST350;
        private System.Windows.Forms.Button btnGetMACWorkingStateST350;
        private System.Windows.Forms.Button btnGetUserNameST350;
        private System.Windows.Forms.Button btnReadyToWorkST350;
        private System.Windows.Forms.Button btnSetBatchPresetModeST350;
        private System.Windows.Forms.Button btnSetBatchST350;
        private System.Windows.Forms.Button btnGetBatchST350;
        private System.Windows.Forms.Button btnGetPocketResultST350;
        private System.Windows.Forms.Button btnInformStartStopST350;
        private System.Windows.Forms.Button btnGetAllLocal;
        private System.Windows.Forms.Button btnSetMode;
        private System.Windows.Forms.Button btnGetMachineState;
        private System.Windows.Forms.Button btnGetAllUser;
        private System.Windows.Forms.Button btnSetBatchFunction;
        private System.Windows.Forms.Button btnSetAddMode;
        private System.Windows.Forms.Button btnSetUserSettingReset;
        private System.Windows.Forms.Button btn_disconnect;
        private System.Windows.Forms.Button btnServerStop;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbb_type;
        private System.Windows.Forms.Button btnGetMachineInfo;
        private System.Windows.Forms.Button btnGetAppVersionST150N;
        private System.Windows.Forms.Button btnGetAppVersionST350;
        private System.Windows.Forms.Button btnGetSNIData;
    }
}


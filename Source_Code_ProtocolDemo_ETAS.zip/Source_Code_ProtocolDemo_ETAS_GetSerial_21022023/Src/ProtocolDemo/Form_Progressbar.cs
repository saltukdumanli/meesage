﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ProtocolDemo
{
    public partial class Form_Progressbar : Form
    {
        public Form_Progressbar()
        {
            InitializeComponent();
        }

        private void Form_Progressbar_Load(object sender, EventArgs e)
        {
            progressBar1.Style = ProgressBarStyle.Marquee;
            progressBar1.MarqueeAnimationSpeed = 50;
        }
    }
}

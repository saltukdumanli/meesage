﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace ProtocolDemo
{
    public partial class Form_Upgrade : Form
    {
        Form_ProtocolDemo parentForm;

        private String _strFileDes;
        private String _strUpgradeFolder = String.Empty;
        private List<String> _listFileSrc = new List<string>();
        private List<String> _listFileDes = new List<string>();
        private byte[] _upgradePart = new byte[5]; // [0] = DM, [1] = MAIN, [2] = APP, [3] = OS Boot, [4] = OS Body

        private FileStream _sendFile;
        private int _numByteRead = 0;
        private int _numByteTotal = 0;

        private const int _SEND_DATA_SIZE = 6144;
        private const int _SEND_DATA_SIZE_IH110 = 1024;
        
        public enum UpgradeStep {Ready, Start, CMD_TRANS_FILE, CMD_TRANS_FILE_PATH, DAT_TRANS_FILE, EOD_TRANS_FILE, End};
        public static EventWaitHandle _waitHandle;

        public bool _bGetSN = false;
        public static EventWaitHandle _getSNHandle;

        public Form_Upgrade(Form_ProtocolDemo parent)
        {
            InitializeComponent();

            this.parentForm = parent;

            _waitHandle = new AutoResetEvent(false);
            _getSNHandle = new AutoResetEvent(false);

            CheckBoxEnable(false);

            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
        }

        private void CheckBoxEnable(bool value)
        {
            chk_dm.Enabled = value;
            chk_main.Enabled = value;
            chk_app.Enabled = value;
            chk_osbody.Enabled = value;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                _strUpgradeFolder = folderBrowserDialog.SelectedPath;
                txt_folder.Text = _strUpgradeFolder;

                if (lb_file.Items.Count > 0)
                    lb_file.Items.Clear();

                if (_listFileSrc.Count > 0)
                    _listFileSrc.Clear();

                if (_listFileDes.Count > 0)
                    _listFileDes.Clear();

                Array.Clear(_upgradePart, 0, _upgradePart.Length);


                DirectoryInfo directoryInfo = new DirectoryInfo(_strUpgradeFolder);
                SearchFile(directoryInfo);
                CheckUpgradePart();
            }
        }

        private void SearchFile(DirectoryInfo source)
        {
            foreach (FileInfo fi in source.GetFiles())
            {
                lb_file.Items.Add(fi.FullName);
            }

            foreach (DirectoryInfo subDir in source.GetDirectories())
            {
                SearchFile(subDir);
            }
        }

        private void CheckUpgradePart()
        {
            string strFile;
            for (int i = 0; i < lb_file.Items.Count; i++)
            {
                strFile = lb_file.Items[i].ToString();

                if (strFile.Contains(".NMH") || strFile.Contains(".NMB")) // ST150N : MAIN
                {
                    chk_main.Checked = true;
                    chk_main.Enabled = true;

                    _upgradePart[1] = 1;
                }
                else if (strFile.Contains(".NDH") || strFile.Contains(".NDB")) // ST150N : DM
                {
                    chk_dm.Checked = true;
                    chk_dm.Enabled = true;

                    _upgradePart[0] = 1;
                }
                else if (strFile.Contains(".NOH") || strFile.Contains(".NOB")) // ST150N : OS
                {
                    chk_osbody.Checked = true;
                    chk_osbody.Enabled = true;

                    _upgradePart[4] = 1;
                }
                else if (strFile.Contains(".SMH") || strFile.Contains(".SMB")) // ST350 : MAIN
                {
                    chk_main.Checked = true;
                    chk_main.Enabled = true;

                    _upgradePart[1] = 1;
                }
                else if (strFile.Contains(".SDH") || strFile.Contains(".SDB")) // ST350 : DM
                {
                    chk_dm.Checked = true;
                    chk_dm.Enabled = true;

                    _upgradePart[0] = 1;
                }
                else if (strFile.Contains(".SOH") || strFile.Contains(".SOB")) // ST350 : OS
                {
                    chk_osbody.Checked = true;
                    chk_osbody.Enabled = true;

                    _upgradePart[4] = 1;
                }
                else
                {
                    chk_app.Checked = true;
                    chk_app.Enabled = true;

                    _upgradePart[2] = 1;
                }
            }
        }

        private void chk_dm_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_dm.Checked)
            {
                _upgradePart[0] = 1;
            }
            else
            {
                _upgradePart[0] = 0;
            }
        }

        private void chk_main_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_main.Checked)
            {
                _upgradePart[1] = 1;
            }
            else
            {
                _upgradePart[1] = 0;
            }
        }

        private void chk_app_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_app.Checked)
            {
                _upgradePart[2] = 1;
            }
            else
            {
                _upgradePart[2] = 0;
            }
        }

        private void chk_osbody_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_osbody.Checked)
            {
                _upgradePart[4] = 1;
            }
            else
            {
                _upgradePart[4] = 0;
            }
        }

        private bool IHBootChecker()
        {
            string strSNStarter = this.parentForm._strMachineSN.Substring(0, 2);
            if (strSNStarter == "IH" || strSNStarter == "IV" || strSNStarter == "IF")
            {
                string strFileSrc;
                for (int i = 0; i < lb_file.Items.Count; i++)
                {
                    strFileSrc = lb_file.Items[i].ToString();
                    if (strFileSrc.Contains("FBOOT.bin"))
                    {
                        if (this.parentForm._strMachineSN.Substring(0, 2) == "IH")
                        {
                            return false;
                        }
                    }
                    else if (strFileSrc.Contains("BOOT.bin"))
                    {
                        if (this.parentForm._strMachineSN.Substring(0, 2) == "IV" || this.parentForm._strMachineSN.Substring(0, 2) == "IF")
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        private void GetUpgradeFile()
        {
            bool bFile = false;
            string strFileSrc;
            string strFileDes;

            for (int i = 0; i < lb_file.Items.Count; i++)
            {
                bFile = false;
                strFileSrc = lb_file.Items[i].ToString();

                if (strFileSrc.Contains(".NDH") || strFileSrc.Contains(".NDB") || strFileSrc.Contains(".SDH") || strFileSrc.Contains(".SDB")) // DM
                {
                    if (_upgradePart[0] == 1) // DM
                    {
                        bFile = true;
                    }
                }
                else if (strFileSrc.Contains(".NMH") || strFileSrc.Contains(".NMB") || strFileSrc.Contains(".SMH") || strFileSrc.Contains(".SMB")) // MAIN
                {
                    if (_upgradePart[1] == 1)
                    {
                        bFile = true;
                    }
                }
                else if (strFileSrc.Contains(".NOH") || strFileSrc.Contains(".NOB") || strFileSrc.Contains(".SOH") || strFileSrc.Contains(".SOB")) // OS
                {
                    if (_upgradePart[4] == 1)
                    {
                        bFile = true;
                    }
                }
                else // APP
                {
                    if (_upgradePart[2] == 1)
                    {
                        bFile = true;
                    }
                }


                if (bFile)
                {
                    _listFileSrc.Add(strFileSrc);

                    strFileDes = strFileSrc;
                    strFileDes = strFileDes.Replace(_strUpgradeFolder, "");
                    strFileDes = strFileDes.TrimStart('\\');


                    if (this.parentForm._model == ProtocolDemo.Form_ProtocolDemo.Models.IH110)
                    {
                        _listFileDes.Add(strFileDes);
                    }
                    else
                    {
                        _listFileDes.Add("UpTemp\\" + strFileDes);
                    }
                }
            }
        }

        public void SetSNHandle()
        {
            if (_bGetSN == true)
            {
                _getSNHandle.Set();
                _bGetSN = false;
            }
        }

        private void btn_upgrade_Click(object sender, EventArgs e)
        {
            if (this.parentForm._connected == false)
            {
                MessageBox.Show("Please connect the machine before upgrade.");
                return;
            }

            if (_upgradePart[0] == 0 && _upgradePart[1] == 0 && _upgradePart[2] == 0 && _upgradePart[3] == 0 && _upgradePart[4] == 0)
            {
                MessageBox.Show("Please select a part for upgrade");
                return;
            }

            // BOOT 파일 예외처리를 위해 Machine SN을 받아온다.
            _bGetSN = true;
            this.parentForm.m_ProtocolDll.PrtcGetMachineSN();
            if (_getSNHandle.WaitOne(3000) == false)
            {
                MessageBox.Show("[Protocol:12-19] - No response to Get Machine Serial Number protocol.");
                _bGetSN = false;
                return;
            }

            // BOOT 파일 예외처리 시작
            if (IHBootChecker() == false)
            {
                MessageBox.Show("Machine series and upgrade version do not match!");
                return;
            }

            if (_listFileSrc.Count > 0)
                _listFileSrc.Clear();

            if (_listFileDes.Count > 0)
                _listFileDes.Clear();

            if (lb_upgradeState.Items.Count > 0)
                lb_upgradeState.Items.Clear();

            GetUpgradeFile();

            if (_listFileSrc.Count > 0)
            {
                this.parentForm.m_ProtocolDll.PrtcLicenseCertification();
            }
            else
            {
                MessageBox.Show("Please select upgrade folder!");
            }
        }

        public void StartUpgradeThread()
        {
            Thread upgradeThread = new Thread(ThreadUpgrade);
            upgradeThread.Start();
        }

        public void SetWaitEventHandle(UpgradeStep upgradeStep)
        {
            _waitHandle.Set();

            String strUpgradeState = String.Empty;
            switch (upgradeStep)
            {
                case UpgradeStep.Ready:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-30] : Upgrade Ready \r\n";
                    break;
                case UpgradeStep.Start:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-31] : Upgrade Start \r\n";
                    break;
                case UpgradeStep.CMD_TRANS_FILE:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-01] : CMD_TRANS_FILE \r\n";
                    break;
                case UpgradeStep.CMD_TRANS_FILE_PATH:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-02] : CMD_TRANS_FILE_PATH : " + _strFileDes + "\r\n";
                    break;
                case UpgradeStep.DAT_TRANS_FILE:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-03] : DAT_TRANS_FILE : [" + _numByteRead.ToString() + " / " + _numByteTotal.ToString() + "]\r\n";
                    break;
                case UpgradeStep.EOD_TRANS_FILE:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-04] : EOD_TRANS_FILE \r\n";
                    break;
                case UpgradeStep.End:
                    strUpgradeState = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    strUpgradeState += "[Protocol:10-32] : Upgrade End \r\n";
                    break;
            }

            if (!String.IsNullOrEmpty(strUpgradeState))
            {
                this.Invoke(new MethodInvoker(delegate()
                    {
                        lb_upgradeState.Items.Add(strUpgradeState);
                        lb_upgradeState.SelectedIndex = lb_upgradeState.Items.Count - 1;
                    }));
            }
        }

        public void ThreadUpgrade()
        {
            // [10-30] Upgrade Ready
            this.parentForm.m_ProtocolDll.PrtcUpgradeReady();
            if (_waitHandle.WaitOne(3000) == false)
            {
                MessageBox.Show("[Protocol:10-30] - No response to upgrade ready protocol.");
                return;
            }


            // [10-31] Upgrade Start
            if (this.parentForm._model == ProtocolDemo.Form_ProtocolDemo.Models.IH110)
                this.parentForm.m_ProtocolDll.PrtcUpgradeStartIH110(_listFileSrc.Count);
            else
                this.parentForm.m_ProtocolDll.PrtcUpgradeStart();
            if (_waitHandle.WaitOne(3000) == false)
            {
                MessageBox.Show("[Protocol:10-31] - No response to upgrade start protocol.");
                return;
            }


            for (int i = 0; i < _listFileSrc.Count; i++)
            {
                // [10-01] CMD Trans File
                this.parentForm.m_ProtocolDll.PrtcUpgradeCmdTransFile();
                if (_waitHandle.WaitOne(3000) == false)
                {
                    MessageBox.Show("[Protocol:10-01] - No response to upgrade CMD_TRANS_FILE protocol.");
                    return;
                }

                // [10-02] CMD Trans File Path
                _strFileDes = _listFileDes[i];
                this.parentForm.m_ProtocolDll.PrtcUpgradeCmdTransFilePath(Encoding.UTF8.GetByteCount(_strFileDes), Encoding.UTF8.GetBytes(_strFileDes));
                if (_waitHandle.WaitOne(3000) == false)
                {
                    MessageBox.Show("[Protocol:10-02] - No response to upgrade CMD_TRANS_FILE_PATH protocol.");
                    return;
                }

                if (_sendFile != null)
                {
                    _sendFile.Close();
                    _sendFile = null;
                }

                _sendFile = new FileStream(_listFileSrc[i], FileMode.Open, FileAccess.Read);
                _numByteTotal = (int)_sendFile.Length;
                _numByteRead = 0;

                while (true)
                {
                    if (SendFile() == false)
                        break;

                    _waitHandle.WaitOne();
                }

                // [10-04] EOD Trans File
                this.parentForm.m_ProtocolDll.PrtcUpgradeEodTransFile();
                if (_waitHandle.WaitOne(30000) == false)
                {
                    MessageBox.Show("No response to upgrade EOD_TRANS_FILE protocol.");
                    return;
                }
            }

            // [10-32] Upgrade End
            this.parentForm.m_ProtocolDll.PrtcUpgradeEnd(_upgradePart);
            if (_waitHandle.WaitOne(30000) == false)
            {
                MessageBox.Show("No response to upgrade end protocol.");
                return;
            }

            // 연결 정리
            this.parentForm.ClearConnection();
        }

        private bool SendFile()
        {
            bool bResult = true;

            if (_sendFile.CanRead)
            {
                if (_numByteRead < _numByteTotal)
                {
                    int nResult = 0;
                    int nReadCount = _numByteTotal - _numByteRead;
                    byte[] buffer;

                    if (this.parentForm._model == ProtocolDemo.Form_ProtocolDemo.Models.IH110)
                    {
                        buffer = new byte[_SEND_DATA_SIZE_IH110];

                        if (nReadCount > _SEND_DATA_SIZE_IH110)
                            nReadCount = _SEND_DATA_SIZE_IH110;

                        nResult = _sendFile.Read(buffer, 0, nReadCount);
                        _numByteRead += nResult;

                        // [10-03] Data Trans File
                        this.parentForm.m_ProtocolDll.PrtcUpgradeDatTransFileIH110(nResult, buffer);
                    }
                    else
                    {
                        buffer = new byte[_SEND_DATA_SIZE];

                        if (nReadCount > _SEND_DATA_SIZE)
                            nReadCount = _SEND_DATA_SIZE;

                        nResult = _sendFile.Read(buffer, 0, nReadCount);
                        _numByteRead += nResult;

                        // [10-03] Data Trans File
                        this.parentForm.m_ProtocolDll.PrtcUpgradeDatTransFile(nResult, buffer);
                    }
                }
                else
                {
                    bResult = false;

                    _sendFile.Close();
                    _sendFile = null;

                    _numByteTotal = 0;
                    _numByteRead = 0;
                }
            }
            else
                bResult = false;
            
            return bResult;
        }

        public void RefreshCtrl()
        {
            txt_folder.Text = "";

            Array.Clear(_upgradePart, 0, _upgradePart.Length);

            chk_main.Checked = chk_main.Enabled = false;
            chk_dm.Checked = chk_dm.Enabled = false;
            chk_osbody.Checked = chk_osbody.Enabled = false;
            chk_main.Checked = chk_main.Enabled = false;
            chk_dm.Checked = chk_dm.Enabled = false;
            chk_osbody.Checked = chk_osbody.Enabled = false;
            chk_app.Checked = chk_app.Enabled = false;

            if (lb_file.Items.Count > 0)
                lb_file.Items.Clear();

            if (lb_upgradeState.Items.Count > 0)
                lb_upgradeState.Items.Clear();

            if (_listFileSrc.Count > 0)
                _listFileSrc.Clear();

            if (_listFileDes.Count > 0)
                _listFileDes.Clear();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            RefreshCtrl();
        }
    }
}

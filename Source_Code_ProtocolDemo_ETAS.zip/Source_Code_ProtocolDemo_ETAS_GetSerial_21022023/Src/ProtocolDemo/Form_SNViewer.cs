﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace ProtocolDemo
{
    public partial class Form_SNViewer : Form
    {
        private String _strSniFile;

        private int _imageIndex = 0;
        private ImageList _imageList;

        private _SNI_HEADER_ _sniHeader;

        public Form_SNViewer()
        {
            InitializeComponent();

            _imageList = new ImageList();
            _imageList.ColorDepth = ColorDepth.Depth24Bit;
            _imageList.ImageSize = new Size(255, 20);

            lv_sni.SmallImageList = _imageList;

            lv_sni.DoubleBuffered(true);
        }

        private void lc_sni_dbclick(object sender, EventArgs e)
        {
            if (_strSniFile == null)
                return;

            // 확장자 대소문자 구분없이 삭제하여 저장
            string strFImgDir = string.Empty;
            string strFImgPath = string.Empty;
            strFImgDir = Regex.Replace(_strSniFile, ".sni", "", RegexOptions.IgnoreCase);
            strFImgPath = strFImgDir + "\\" + lv_sni.SelectedIndices[0] + ".bmp";

            // Full Image 유무 확인
            FileInfo fi = new FileInfo(strFImgPath);
            if (fi.Exists == false)
                return;
        }

        private void btn_open_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "SNI Files|*.SNI|All Files|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;

            try
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    _strSniFile = openFileDialog.FileName;
                    LoadSNIData(_strSniFile);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("File Open Error: " + ex.Message);
            }
        }

        private void LoadSNIData(String strFilePath)
        {
            _imageIndex = 0;
            _imageList.Images.Clear();
            lv_sni.Items.Clear();


            FileStream fileStream = new FileStream(strFilePath, FileMode.Open);
            try
            {
                // SNI Header
                int nSize = Marshal.SizeOf(typeof(_SNI_HEADER_));
                byte[] buff = new byte[nSize];

                fileStream.Read(buff, 0, nSize);
                _sniHeader = (_SNI_HEADER_)ByteToStructure(buff, nSize, typeof(_SNI_HEADER_));

                lv_sni.BeginUpdate();

                for (int i = 0; i < _sniHeader.DataCount; i++)
                {
                    nSize = Marshal.SizeOf(typeof(_SNI_BODY_));
                    byte[] sniBuff = new byte[nSize];

                    fileStream.Read(sniBuff, 0, nSize);
                    _SNI_BODY_ sniBody = (_SNI_BODY_)ByteToStructure(sniBuff, nSize, typeof(_SNI_BODY_));

                    ProcessSNIBody(ref sniBody);
                }

                lv_sni.EndUpdate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("SNI File open failed! : {0}", ex.Message);
            }
            finally
            {
                fileStream.Close();
            }
        }

        public void ChangeColumn(bool bSNI)
        {
            // 리스트뷰 컬럼
            this.Invoke(new Action(delegate ()
            {
                lv_sni.Columns.Clear();
            }));


            if (bSNI == true)
            {
                this.Invoke(new Action(delegate ()
                {
                    lv_sni.Columns.Add("Recognition Image", 200, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Index", 60, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Date", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Time", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Recognition Text", 200, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Local", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Version", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Denom", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Output", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("State", 80, HorizontalAlignment.Left);

                    lv_sni.Columns[0].DisplayIndex = 4;
                    lv_sni.Columns[1].DisplayIndex = 0;
                    lv_sni.Columns[2].DisplayIndex = 1;
                    lv_sni.Columns[3].DisplayIndex = 2;
                    lv_sni.Columns[4].DisplayIndex = 3;
                    lv_sni.Columns[5].DisplayIndex = 5;
                    lv_sni.Columns[6].DisplayIndex = 6;
                    lv_sni.Columns[7].DisplayIndex = 7;
                    lv_sni.Columns[8].DisplayIndex = 8;
                    lv_sni.Columns[9].DisplayIndex = 9;
                }));
            }
            else // CHEQUE
            {
                this.Invoke(new Action(delegate ()
                {
                    lv_sni.Columns.Add("Recognition Image", 200, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Index", 60, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Date", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Time", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Recognition Text", 200, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("QR Code", 200, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Local", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Version", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Denom", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Output", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("State", 80, HorizontalAlignment.Left);
                    lv_sni.Columns.Add("Result", 150, HorizontalAlignment.Left);

                    lv_sni.Columns[0].DisplayIndex = 4;
                    lv_sni.Columns[1].DisplayIndex = 0;
                    lv_sni.Columns[2].DisplayIndex = 1;
                    lv_sni.Columns[3].DisplayIndex = 2;
                    lv_sni.Columns[4].DisplayIndex = 3;
                    lv_sni.Columns[5].DisplayIndex = 5;
                    lv_sni.Columns[6].DisplayIndex = 6;
                    lv_sni.Columns[7].DisplayIndex = 7;
                    lv_sni.Columns[8].DisplayIndex = 8;
                    lv_sni.Columns[9].DisplayIndex = 9;
                    lv_sni.Columns[10].DisplayIndex = 10;
                    lv_sni.Columns[11].DisplayIndex = 11;
                }));
            }
        }

        public void ProcessSNIBody(ref _SNI_BODY_ sniBody)
        {
            MakeBitmap(ref sniBody);

            String strData;

            ListViewItem LVItem = new ListViewItem();

            // SERIAL IMAGE
            LVItem.ImageIndex = _imageIndex;

            // INDEX
            strData = (_imageIndex + 1).ToString();
            LVItem.SubItems.Add(strData);

            // DATE
            strData = String.Format("{0:0000}/{1:00}/{2:00}", 1980 + ((sniBody.CountDate >> 9) & 0x7F), (sniBody.CountDate >> 5) & 0x0F, sniBody.CountDate & 0x1F);
            LVItem.SubItems.Add(strData);

            // TIME
            strData = String.Format("{0:00}:{1:00}:{2:00}", (sniBody.CountTime >> 11) & 0xFF, (sniBody.CountTime >> 5) & 0x3F, ((sniBody.CountTime >> 0) & 0x1F) * 2);
            LVItem.SubItems.Add(strData);

            // SERIAL NUMBER
            LVItem.SubItems.Add(sniBody.SerialNumber);

            // LOCAL
            LVItem.SubItems.Add(sniBody.Local);

            // NOTE VERSION
            if (sniBody.NoteVersion == 0) // Old
                strData = "Old";
            else if (sniBody.NoteVersion == 1) // New
                strData = "New";
            else if (sniBody.NoteVersion == 2) // Very New
                strData = "Very New";
            else
                strData = "Unknown";
            LVItem.SubItems.Add(strData);

            // DENOMINATION
            LVItem.SubItems.Add(sniBody.Denomination);

            // OUTPUT
            if (sniBody.OutputPocket == 1) // Pocket1
                strData = "Pocket1";
            else if (sniBody.OutputPocket == 2) // Pocket2
                strData = "Pocket2";
            else if (sniBody.OutputPocket == 3) // Pocket3
                strData = "Pocket3";
            else if (sniBody.OutputPocket == 4) // Reject
                strData = "Reject";
            else if (sniBody.OutputPocket == 5) // Manual
                strData = "Manual";
            else
                strData = "Unknown";
            LVItem.SubItems.Add(strData);

            // NOTE STATE
            if (sniBody.NoteState == 0) // Common
                strData = "Common";
            else if (sniBody.NoteState == 1) // ATM
                strData = "ATM";
            else if (sniBody.NoteState == 2) // FIT
                strData = "FIT";
            else if (sniBody.NoteState == 3) // UNFIT
                strData = "UNFIT";
            else if (sniBody.NoteState == 4) // REJECT
                strData = "REJECT";
            else if (sniBody.NoteState == 5) // MANUAL
                strData = "MANUAL";
            else // Unknown
                strData = "Unknown";
            LVItem.SubItems.Add(strData);

            this.Invoke(new Action(delegate()
                {
                    lv_sni.Items.Add(LVItem);
                }));

            _imageIndex++;
        }

        private void MakeBitmap(ref _SNI_BODY_ sniBody)
        {
            int nXSize = 0;
            int nYSize = 0;

            nXSize = (sniBody.SizeX1 << 8) & 0xFF00;
            nXSize |= sniBody.SizeX2 & 0x00FF;
            nXSize = nXSize * sniBody.Count;

            nYSize = sniBody.SizeY;

            Bitmap bitmap = new Bitmap(400, 20);

            for (int y = 0; y < nYSize; y++)
            {
                for (int x = 0; x < nXSize; x++)
                {
                    bitmap.SetPixel(x, y, Color.FromArgb(sniBody.Data[x + (y * nXSize)], sniBody.Data[x + (y * nXSize)], sniBody.Data[x + (y * nXSize)]));
                }
            }

            _imageList.Images.Add(bitmap);
            bitmap.Dispose();
        }

        public void ProcessChequeMICR(ref _CHEQUE_MICR_ chequeMICR)
        {
            MakeBitmapMICR(ref chequeMICR);

            String strData;

            ListViewItem LVItem = new ListViewItem();

            // SERIAL IMAGE
            LVItem.ImageIndex = _imageIndex;

            // INDEX
            strData = (_imageIndex + 1).ToString();
            LVItem.SubItems.Add(strData);

            // DATE
            strData = String.Format("{0:0000}/{1:00}/{2:00}", 1980 + ((chequeMICR.CountDate >> 9) & 0x7F), (chequeMICR.CountDate >> 5) & 0x0F, chequeMICR.CountDate & 0x1F);
            LVItem.SubItems.Add(strData);

            // TIME
            strData = String.Format("{0:00}:{1:00}:{2:00}", (chequeMICR.CountTime >> 11) & 0xFF, (chequeMICR.CountTime >> 5) & 0x3F, ((chequeMICR.CountTime >> 0) & 0x1F) * 2);
            LVItem.SubItems.Add(strData);

            // SERIAL NUMBER
            strData = Encoding.Default.GetString(chequeMICR.MICRText);
            LVItem.SubItems.Add(strData);

            // LOCAL
            strData = String.Join("", chequeMICR.NoteLocal);
            LVItem.SubItems.Add(strData);

            // NOTE VERSION
            if (chequeMICR.NoteVer == 0) // Old
                strData = "Old";
            else if (chequeMICR.NoteVer == 1) // New
                strData = "New";
            else if (chequeMICR.NoteVer == 2) // Very New
                strData = "Very New";
            else
                strData = "Unknown";
            LVItem.SubItems.Add(strData);

            // DENOMINATION
            strData = String.Join("", chequeMICR.NoteValue);
            LVItem.SubItems.Add(strData);

            // OUTPUT
            if (chequeMICR.NoteState == 1) // Pocket1
                strData = "Pocket1";
            else
                strData = "Reject";
            LVItem.SubItems.Add(strData);

            // NOTE STATE
            if (chequeMICR.NoteState == 1)
                strData = "Common";
            else
                strData = "Reject";
            LVItem.SubItems.Add(strData);

            this.Invoke(new Action(delegate()
            {
                lv_sni.Items.Add(LVItem);
            }));

            _imageIndex++;
        }

        private void MakeBitmapMICR(ref _CHEQUE_MICR_ checkMICR)
        {
            int nXSize = checkMICR.MICR_X;
            int nYSize = checkMICR.MICR_Y;
            int nSNCnt = checkMICR.MICRCount;

            Bitmap bitmap = new Bitmap(nXSize * nSNCnt, nYSize);

            for (int sn = 0; sn < nSNCnt; sn++)
            {
                for (int y = 0; y < nYSize; y++)
                {
                    for (int x = 0; x < nXSize; x++)
                    {
                        bitmap.SetPixel((nXSize * sn) + x, y, Color.FromArgb(checkMICR.MICR_GRY[(sn * 20 * 20) + (y * nXSize) + x],
                                                                             checkMICR.MICR_GRY[(sn * 20 * 20) + (y * nXSize) + x],
                                                                             checkMICR.MICR_GRY[(sn * 20 * 20) + (y * nXSize) + x]));
                    }
                }
            }

            _imageList.Images.Add(bitmap);
            bitmap.Dispose();
        }

        public void ProcessChequeQR(ref _CHEQUE_QR_ chequeQR)
        {
            MakeBitmapQR(ref chequeQR);

            String strData;

            ListViewItem LVItem = new ListViewItem();

            // Recognition IMAGE
            LVItem.ImageIndex = _imageIndex;

            // INDEX
            strData = (_imageIndex + 1).ToString();
            LVItem.SubItems.Add(strData);

            // DATE
            strData = String.Format("{0:0000}/{1:00}/{2:00}", 1980 + ((chequeQR.CountDate >> 9) & 0x7F), (chequeQR.CountDate >> 5) & 0x0F, chequeQR.CountDate & 0x1F);
            LVItem.SubItems.Add(strData);

            // TIME
            strData = String.Format("{0:00}:{1:00}:{2:00}", (chequeQR.CountTime >> 11) & 0xFF, (chequeQR.CountTime >> 5) & 0x3F, ((chequeQR.CountTime >> 0) & 0x1F) * 2);
            LVItem.SubItems.Add(strData);

            // Recognition Text
            strData = Encoding.Default.GetString(chequeQR.MICRCode);
            LVItem.SubItems.Add(strData);

            // QR Code
            strData = Encoding.Default.GetString(chequeQR.QRCode);
            LVItem.SubItems.Add(strData);

            // Local
            LVItem.SubItems.Add("CHEQUE");

            // Version
            LVItem.SubItems.Add("");

            // Denom
            LVItem.SubItems.Add("");

            // Output
            LVItem.SubItems.Add("");

            // State
            if (chequeQR.NoteState == 1)
                strData = "Common";
            else
                strData = "Reject";
            LVItem.SubItems.Add(strData);

            // Result : Fake + match
            strData = String.Empty;

            String strError = ErrorCodeToReason(chequeQR.NoteErrorCodeHi, chequeQR.NoteErrorCodeLow);
            String strMatch = CheckMatchResult(Encoding.Default.GetString(chequeQR.MICRCode), Encoding.Default.GetString(chequeQR.QRCode));

            if (String.IsNullOrEmpty(strError) == false)
                strData = strError;

            if (String.IsNullOrEmpty(strMatch) == false)
            {
                if (strData.Length > 0)
                    strData += " + ";
                strData += strMatch;
            }

            LVItem.SubItems.Add(strData);


            this.Invoke(new Action(delegate ()
            {
                lv_sni.Items.Add(LVItem);
            }));

            _imageIndex++;
        }

        private void MakeBitmapQR(ref _CHEQUE_QR_ checkQR)
        {
            if (checkQR.MICRXSize <= 0 || checkQR.MICRYSize <= 0 || checkQR.MICRCodeCount <= 0)
            {
                System.Diagnostics.Debug.WriteLine("MakeBitmapQR() Error Size!");
                return;
            }

            int nXSize = checkQR.MICRXSize;
            int nYSize = checkQR.MICRYSize;
            int nSNCnt = checkQR.MICRCodeCount;

            Bitmap bitmap = new Bitmap(nXSize * nSNCnt, nYSize);

            for (int sn = 0; sn < nSNCnt; sn++)
            {
                for (int y = 0; y < nYSize; y++)
                {
                    for (int x = 0; x < nXSize; x++)
                    {
                        bitmap.SetPixel((nXSize * sn) + x, y, Color.FromArgb(checkQR.MICRImage[(sn * 20 * 20) + (y * nXSize) + x],
                                                                             checkQR.MICRImage[(sn * 20 * 20) + (y * nXSize) + x],
                                                                             checkQR.MICRImage[(sn * 20 * 20) + (y * nXSize) + x]));
                    }
                }
            }

            _imageList.Images.Add(bitmap);
            bitmap.Dispose();
        }

        private String ErrorCodeToReason(byte errorCodeHi, byte errorCodeLow)
        {
            String strError = String.Empty;

            if (errorCodeHi == 0 && errorCodeLow == 0)
                return strError;

            if (errorCodeHi == 0)
            {
                switch (errorCodeLow)
                {
                    case 1:   strError = "Chain Error";                break;
                    case 2:   strError = "Skew L Error";               break;
                    case 3:   strError = "Skew R Error";               break;
                    case 4:   strError = "Double Error";               break;
                    case 5:   strError = "No result Error";            break;
                    case 6:   strError = "Stacker full Error";         break;
                    case 7:   strError = "Batch full Error";           break;
                    case 8:   strError = "Reject full Error";          break;
                    case 9:   strError = "Skew diff Error";            break;
                    case 10:  strError = "Note tracking Error";        break;
                    case 11:  strError = "Outline LR Error";           break;
                    case 12:  strError = "Outline line Error";         break;
                    case 13:  strError = "Outline pixel X Error";      break;
                    case 14:  strError = "Outline pixel Y Error";      break;

                    case 21:  strError = "X Size Error";               break;
                    case 22:  strError = "Y Size Error";               break;
                    case 23:  strError = "XY Size Error";              break;
                    case 24:  strError = "Fan X Error";                break;
                    case 25:  strError = "Fan Y Error";                break;
                    case 26:  strError = "Fan XY Error";               break;
                    case 27:  strError = "Slope Error";                break;

                    case 31:  strError = "REC X Size Error";           break;
                    case 32:  strError = "REC Y Size Error";           break;
                    case 33:  strError = "REC XY Size Error";          break;
                    case 34:  strError = "REC uncert Error";           break;
                    case 35:  strError = "REC denom Error";            break;
                    case 36:  strError = "REC not verify Error";       break;
                    case 37:  strError = "REC false image Error";      break;
                    case 38:  strError = "REC old version Error";      break;
                    case 39:  strError = "REC new version Error";      break;
                    case 40:  strError = "REC very new version Error"; break;

                    case 41:  strError = "SN diff Error";              break;
                    case 42:  strError = "SN change Error";            break;
                    case 43:  strError = "SN miss Error";              break;
                    case 44:  strError = "SN uncert Error";            break;
                    case 46:  strError = "SN BL Error";                break;
                    case 47:  strError = "SN CNT diff Error";          break;

                    case 51:  strError = "Bar WS Error";               break;
                    case 52:  strError = "Bar search Error";           break;
                    case 53:  strError = "Bar WT Error";               break;
                    case 54:  strError = "Bar NP Error";               break;

                    case 61:  strError = "Diff denom Error";           break;
                    case 62:  strError = "Diff face Error";            break;
                    case 63:  strError = "Diff org Error";             break;
                    case 64:  strError = "Diff ver Error";             break;
                    case 65:  strError = "User operation Error";       break;
                    case 66:  strError = "Diff currency Error";        break;
                    case 67:  strError = "Diff currency1 Error";       break;
                    case 68:  strError = "Max currency Error";         break;
                    case 69:  strError = "Max denom Error";            break;

                    case 71:  strError = "Ver old Error";              break;
                    case 72:  strError = "Ver new Error";              break;
                    case 73:  strError = "Ver very new Error";         break;
                    case 74:  strError = "User denom Error";           break;

                    case 81:  strError = "Dogear Error";               break;
                    case 82:  strError = "Hole Error";                 break;
                    case 83:  strError = "Tear Error";                 break;
                    case 84:  strError = "No result CIS Error";        break;
                    case 85:  strError = "No result CF Error";         break;
                    case 86:  strError = "DISP reject Error";          break;

                    case 91:  strError = "Rejected denom Error";       break;
                    case 92:  strError = "Rejected currency Error";    break;

                    default:  strError = "Unknown Error";              break;
                }
            }
            else if (errorCodeHi == 1)
            {
                switch (errorCodeLow)
                {
                    case 1:   strError = "IR MG UV Error";             break;
                    case 2:   strError = "IR MG Error";                break;
                    case 3:   strError = "IR UV Error";                break;
                    case 4:   strError = "MG UV Error";                break;
                    case 5:   strError = "IR Error";                   break;
                    case 6:   strError = "MG Error";                   break;
                    case 7:   strError = "UV Error";                   break;
                    case 8:   strError = "TDS Error";                  break;
                    default:  strError = "Unknown Error";              break;
                }
            }

            return strError;
        }

        private String CheckMatchResult(String strMicr, String strQR)
        {
            if (String.IsNullOrEmpty(strMicr) || String.IsNullOrEmpty(strQR))
                return "Not Read";

            // MICR
            String strMicrPart = String.Empty;
            List<String> listMicr = new List<string>();

            for (int i = 0; i < strMicr.Length; i++)
            {
                if (48 <= strMicr[i] && strMicr[i] <= 57)
                {
                    strMicrPart += strMicr[i];
                }
                else
                {
                    if (strMicrPart.Length > 0)
                        listMicr.Add(strMicrPart);

                    strMicrPart = String.Empty;
                }
            }

            // 마지막 문자가 없어서 분리가 안된 문자열이 있다면 추가
            if (String.IsNullOrEmpty(strMicrPart) == false && listMicr.Count < 4)
                listMicr.Add(strMicrPart);


            // QR Code
            //System.Diagnostics.Debug.WriteLine("MICR = " + strMicr);
            //System.Diagnostics.Debug.WriteLine("QR = " + strQR);
            //System.Diagnostics.Debug.WriteLine("MICR = " + listMicr.Count.ToString() + ", QR = " + strQRArr.Length.ToString());

            String[] strQRArr = strQR.Split(new char[] { ' ' });
            if (strQRArr.Length < 4)
            {
                return "Not Read";
            }

            
            
            // Check
            if (listMicr.Count == 4)
            {
                //System.Diagnostics.Debug.WriteLine(listMicr[0] + " " + strQRArr[2]);
                if (Convert.ToInt64(listMicr[0]) != Convert.ToInt64(strQRArr[2]))
                    return "Not Match";

                //System.Diagnostics.Debug.WriteLine(listMicr[1] + " " + strQRArr[3]);
                if (Convert.ToInt64(listMicr[1]) != Convert.ToInt64(strQRArr[3]))
                    return "Not Match";

                //System.Diagnostics.Debug.WriteLine(listMicr[2] + " " + strQRArr[4]);
                if (Convert.ToInt64(listMicr[2]) != Convert.ToInt64(strQRArr[4]))
                    return "Not Match";

                //System.Diagnostics.Debug.WriteLine(listMicr[3] + " " + strQRArr[5]);
                if (Convert.ToInt64(listMicr[3]) != Convert.ToInt64(strQRArr[5]))
                    return "Not Match";
            }
            else
            {
                return "Not Match";
            }

            return "Match";
        }

        private static object ByteToStructure(byte[] data, int dataSize, Type type)
        {
            IntPtr buff = Marshal.AllocHGlobal(dataSize);
            Marshal.Copy(data, 0, buff, dataSize);
            object obj = Marshal.PtrToStructure(buff, type);
            Marshal.FreeHGlobal(buff);

            return obj;
        }

        public void ClearList()
        {
            _imageIndex = 0;
            _imageList.Images.Clear();

            if (lv_sni.Items.Count > 0)
            {
            this.Invoke(new Action(delegate()
                {
                    lv_sni.Items.Clear();
                }));
            }
        }

        private void SNViewer_FormClosing(object sender, FormClosingEventArgs e)
        {
            ClearList();
        }        
    }

    public static class Extensions
    {
        public static void DoubleBuffered(this Control control, bool enabled)
        {
            var prop = control.GetType().GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            prop.SetValue(control, enabled, null);
        }
    }
}

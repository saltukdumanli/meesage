﻿namespace ProtocolDemo
{
    partial class Form_SNViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_open = new System.Windows.Forms.Button();
            this.lv_sni = new System.Windows.Forms.ListView();
            this.col_recognition_image = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_index = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_date = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_recognition_text = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_local = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_version = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_output = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_state = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_open);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1060, 60);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu";
            // 
            // btn_open
            // 
            this.btn_open.Location = new System.Drawing.Point(7, 20);
            this.btn_open.Name = "btn_open";
            this.btn_open.Size = new System.Drawing.Size(90, 30);
            this.btn_open.TabIndex = 0;
            this.btn_open.Text = "Open";
            this.btn_open.UseVisualStyleBackColor = true;
            this.btn_open.Click += new System.EventHandler(this.btn_open_Click);
            // 
            // lv_sni
            // 
            this.lv_sni.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_recognition_image,
            this.col_index,
            this.col_date,
            this.col_time,
            this.col_recognition_text,
            this.col_local,
            this.col_version,
            this.col_denom,
            this.col_output,
            this.col_state});
            this.lv_sni.FullRowSelect = true;
            this.lv_sni.Location = new System.Drawing.Point(12, 80);
            this.lv_sni.Name = "lv_sni";
            this.lv_sni.Size = new System.Drawing.Size(1060, 470);
            this.lv_sni.TabIndex = 1;
            this.lv_sni.UseCompatibleStateImageBehavior = false;
            this.lv_sni.View = System.Windows.Forms.View.Details;
            this.lv_sni.DoubleClick += new System.EventHandler(this.lc_sni_dbclick);
            // 
            // col_recognition_image
            // 
            this.col_recognition_image.DisplayIndex = 4;
            this.col_recognition_image.Text = "Recognition Image";
            this.col_recognition_image.Width = 200;
            // 
            // col_index
            // 
            this.col_index.DisplayIndex = 0;
            this.col_index.Text = "Index";
            // 
            // col_date
            // 
            this.col_date.DisplayIndex = 1;
            this.col_date.Text = "Date";
            this.col_date.Width = 80;
            // 
            // col_time
            // 
            this.col_time.DisplayIndex = 2;
            this.col_time.Text = "Time";
            this.col_time.Width = 80;
            // 
            // col_recognition_text
            // 
            this.col_recognition_text.DisplayIndex = 3;
            this.col_recognition_text.Text = "Recognition Text";
            this.col_recognition_text.Width = 200;
            // 
            // col_local
            // 
            this.col_local.Text = "Local";
            this.col_local.Width = 80;
            // 
            // col_version
            // 
            this.col_version.Text = "Version";
            this.col_version.Width = 80;
            // 
            // col_denom
            // 
            this.col_denom.Text = "Denom";
            this.col_denom.Width = 80;
            // 
            // col_output
            // 
            this.col_output.Text = "Output";
            this.col_output.Width = 80;
            // 
            // col_state
            // 
            this.col_state.Text = "State";
            this.col_state.Width = 80;
            // 
            // Form_SNViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 562);
            this.Controls.Add(this.lv_sni);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_SNViewer";
            this.Text = "SNViewer";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SNViewer_FormClosing);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_open;
        private System.Windows.Forms.ListView lv_sni;
        private System.Windows.Forms.ColumnHeader col_recognition_image;
        private System.Windows.Forms.ColumnHeader col_date;
        private System.Windows.Forms.ColumnHeader col_time;
        private System.Windows.Forms.ColumnHeader col_local;
        private System.Windows.Forms.ColumnHeader col_version;
        private System.Windows.Forms.ColumnHeader col_denom;
        private System.Windows.Forms.ColumnHeader col_output;
        private System.Windows.Forms.ColumnHeader col_state;
        private System.Windows.Forms.ColumnHeader col_recognition_text;
        private System.Windows.Forms.ColumnHeader col_index;
    }
}
﻿namespace ProtocolDemo
{
    partial class Form_Upgrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_folder = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chk_dm = new System.Windows.Forms.CheckBox();
            this.chk_main = new System.Windows.Forms.CheckBox();
            this.chk_app = new System.Windows.Forms.CheckBox();
            this.chk_osbody = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.lb_file = new System.Windows.Forms.ListBox();
            this.btn_upgrade = new System.Windows.Forms.Button();
            this.lb_upgradeState = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Upgrade Folder :";
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(115, 9);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(90, 23);
            this.btn_search.TabIndex = 1;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_folder
            // 
            this.txt_folder.Location = new System.Drawing.Point(10, 38);
            this.txt_folder.Name = "txt_folder";
            this.txt_folder.Size = new System.Drawing.Size(762, 21);
            this.txt_folder.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "Upgrade Part :";
            // 
            // chk_dm
            // 
            this.chk_dm.AutoSize = true;
            this.chk_dm.Location = new System.Drawing.Point(115, 70);
            this.chk_dm.Name = "chk_dm";
            this.chk_dm.Size = new System.Drawing.Size(43, 16);
            this.chk_dm.TabIndex = 4;
            this.chk_dm.Text = "DM";
            this.chk_dm.UseVisualStyleBackColor = true;
            this.chk_dm.CheckedChanged += new System.EventHandler(this.chk_dm_CheckedChanged);
            // 
            // chk_main
            // 
            this.chk_main.AutoSize = true;
            this.chk_main.Location = new System.Drawing.Point(224, 70);
            this.chk_main.Name = "chk_main";
            this.chk_main.Size = new System.Drawing.Size(55, 16);
            this.chk_main.TabIndex = 5;
            this.chk_main.Text = "MAIN";
            this.chk_main.UseVisualStyleBackColor = true;
            this.chk_main.CheckedChanged += new System.EventHandler(this.chk_main_CheckedChanged);
            // 
            // chk_app
            // 
            this.chk_app.AutoSize = true;
            this.chk_app.Location = new System.Drawing.Point(345, 70);
            this.chk_app.Name = "chk_app";
            this.chk_app.Size = new System.Drawing.Size(48, 16);
            this.chk_app.TabIndex = 6;
            this.chk_app.Text = "APP";
            this.chk_app.UseVisualStyleBackColor = true;
            this.chk_app.CheckedChanged += new System.EventHandler(this.chk_app_CheckedChanged);
            // 
            // chk_osbody
            // 
            this.chk_osbody.AutoSize = true;
            this.chk_osbody.Location = new System.Drawing.Point(459, 70);
            this.chk_osbody.Name = "chk_osbody";
            this.chk_osbody.Size = new System.Drawing.Size(41, 16);
            this.chk_osbody.TabIndex = 8;
            this.chk_osbody.Text = "OS";
            this.chk_osbody.UseVisualStyleBackColor = true;
            this.chk_osbody.CheckedChanged += new System.EventHandler(this.chk_osbody_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "Upgrade Files :";
            // 
            // btn_refresh
            // 
            this.btn_refresh.Location = new System.Drawing.Point(115, 97);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(90, 23);
            this.btn_refresh.TabIndex = 10;
            this.btn_refresh.Text = "Refresh";
            this.btn_refresh.UseVisualStyleBackColor = true;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // lb_file
            // 
            this.lb_file.FormattingEnabled = true;
            this.lb_file.ItemHeight = 12;
            this.lb_file.Location = new System.Drawing.Point(10, 126);
            this.lb_file.Name = "lb_file";
            this.lb_file.Size = new System.Drawing.Size(762, 124);
            this.lb_file.TabIndex = 11;
            // 
            // btn_upgrade
            // 
            this.btn_upgrade.Location = new System.Drawing.Point(115, 267);
            this.btn_upgrade.Name = "btn_upgrade";
            this.btn_upgrade.Size = new System.Drawing.Size(90, 23);
            this.btn_upgrade.TabIndex = 12;
            this.btn_upgrade.Text = "Upgrade";
            this.btn_upgrade.UseVisualStyleBackColor = true;
            this.btn_upgrade.Click += new System.EventHandler(this.btn_upgrade_Click);
            // 
            // lb_upgradeState
            // 
            this.lb_upgradeState.FormattingEnabled = true;
            this.lb_upgradeState.ItemHeight = 12;
            this.lb_upgradeState.Location = new System.Drawing.Point(10, 297);
            this.lb_upgradeState.Name = "lb_upgradeState";
            this.lb_upgradeState.Size = new System.Drawing.Size(762, 184);
            this.lb_upgradeState.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 273);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 12);
            this.label4.TabIndex = 14;
            this.label4.Text = "Upgrade State :";
            // 
            // Form_Upgrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 489);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lb_upgradeState);
            this.Controls.Add(this.btn_upgrade);
            this.Controls.Add(this.lb_file);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chk_osbody);
            this.Controls.Add(this.chk_app);
            this.Controls.Add(this.chk_main);
            this.Controls.Add(this.chk_dm);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_folder);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.label1);
            this.Name = "Form_Upgrade";
            this.Text = "Upgrade";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_folder;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chk_dm;
        private System.Windows.Forms.CheckBox chk_main;
        private System.Windows.Forms.CheckBox chk_app;
        private System.Windows.Forms.CheckBox chk_osbody;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.ListBox lb_file;
        private System.Windows.Forms.Button btn_upgrade;
        private System.Windows.Forms.ListBox lb_upgradeState;
        private System.Windows.Forms.Label label4;
    }
}
﻿namespace ProtocolDemo
{
    partial class Form_SetUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_UserIndex = new System.Windows.Forms.TextBox();
            this.txt_UserName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_SerUser = new System.Windows.Forms.Button();
            this.lv_User = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_GetAllUser = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbError = new System.Windows.Forms.Label();
            this.txt_NewUserName = new System.Windows.Forms.TextBox();
            this.txt_SelectedUser = new System.Windows.Forms.TextBox();
            this.btn_UpdateUserName = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(97, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Index";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Location = new System.Drawing.Point(189, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // txt_UserIndex
            // 
            this.txt_UserIndex.Location = new System.Drawing.Point(72, 33);
            this.txt_UserIndex.Name = "txt_UserIndex";
            this.txt_UserIndex.Size = new System.Drawing.Size(85, 21);
            this.txt_UserIndex.TabIndex = 2;
            // 
            // txt_UserName
            // 
            this.txt_UserName.Location = new System.Drawing.Point(167, 33);
            this.txt_UserName.Name = "txt_UserName";
            this.txt_UserName.Size = new System.Drawing.Size(85, 21);
            this.txt_UserName.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "Set User :";
            // 
            // btn_SerUser
            // 
            this.btn_SerUser.Location = new System.Drawing.Point(72, 78);
            this.btn_SerUser.Name = "btn_SerUser";
            this.btn_SerUser.Size = new System.Drawing.Size(180, 30);
            this.btn_SerUser.TabIndex = 5;
            this.btn_SerUser.Text = "[12-81] Set User";
            this.btn_SerUser.UseVisualStyleBackColor = true;
            this.btn_SerUser.Click += new System.EventHandler(this.btn_SerUser_Click);
            // 
            // lv_User
            // 
            this.lv_User.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lv_User.FullRowSelect = true;
            this.lv_User.GridLines = true;
            this.lv_User.HideSelection = false;
            this.lv_User.Location = new System.Drawing.Point(12, 274);
            this.lv_User.Name = "lv_User";
            this.lv_User.Size = new System.Drawing.Size(258, 237);
            this.lv_User.TabIndex = 6;
            this.lv_User.UseCompatibleStateImageBehavior = false;
            this.lv_User.View = System.Windows.Forms.View.Details;
            this.lv_User.DoubleClick += new System.EventHandler(this.lv_User_DoubleClick);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Index";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Name";
            this.columnHeader2.Width = 140;
            // 
            // btn_GetAllUser
            // 
            this.btn_GetAllUser.Location = new System.Drawing.Point(86, 517);
            this.btn_GetAllUser.Name = "btn_GetAllUser";
            this.btn_GetAllUser.Size = new System.Drawing.Size(184, 30);
            this.btn_GetAllUser.TabIndex = 7;
            this.btn_GetAllUser.Text = "[12-80] Get All User";
            this.btn_GetAllUser.UseVisualStyleBackColor = true;
            this.btn_GetAllUser.Click += new System.EventHandler(this.btn_GetAllUser_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "Selected User :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 12);
            this.label6.TabIndex = 10;
            this.label6.Text = "New User Name : ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbError);
            this.groupBox1.Controls.Add(this.txt_NewUserName);
            this.groupBox1.Controls.Add(this.txt_SelectedUser);
            this.groupBox1.Controls.Add(this.btn_UpdateUserName);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(11, 126);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(259, 142);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            // 
            // lbError
            // 
            this.lbError.AutoSize = true;
            this.lbError.ForeColor = System.Drawing.Color.Red;
            this.lbError.Location = new System.Drawing.Point(121, 91);
            this.lbError.Name = "lbError";
            this.lbError.Size = new System.Drawing.Size(76, 12);
            this.lbError.TabIndex = 14;
            this.lbError.Text = " Error Check";
            this.lbError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbError.Visible = false;
            // 
            // txt_NewUserName
            // 
            this.txt_NewUserName.Location = new System.Drawing.Point(123, 61);
            this.txt_NewUserName.Name = "txt_NewUserName";
            this.txt_NewUserName.Size = new System.Drawing.Size(128, 21);
            this.txt_NewUserName.TabIndex = 13;
            this.txt_NewUserName.TextChanged += new System.EventHandler(this.txt_NewUserName_TextChanged);
            // 
            // txt_SelectedUser
            // 
            this.txt_SelectedUser.Location = new System.Drawing.Point(123, 20);
            this.txt_SelectedUser.Name = "txt_SelectedUser";
            this.txt_SelectedUser.ReadOnly = true;
            this.txt_SelectedUser.Size = new System.Drawing.Size(128, 21);
            this.txt_SelectedUser.TabIndex = 12;
            // 
            // btn_UpdateUserName
            // 
            this.btn_UpdateUserName.Location = new System.Drawing.Point(73, 106);
            this.btn_UpdateUserName.Name = "btn_UpdateUserName";
            this.btn_UpdateUserName.Size = new System.Drawing.Size(180, 30);
            this.btn_UpdateUserName.TabIndex = 12;
            this.btn_UpdateUserName.Text = "[12-85] Modify User Name";
            this.btn_UpdateUserName.UseVisualStyleBackColor = true;
            this.btn_UpdateUserName.Click += new System.EventHandler(this.btn_ModifyUserName_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_SerUser);
            this.groupBox2.Controls.Add(this.txt_UserIndex);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txt_UserName);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(258, 114);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // 
            // Form_SetUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 559);
            this.Controls.Add(this.btn_GetAllUser);
            this.Controls.Add(this.lv_User);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Form_SetUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form_SetUser";
            this.Shown += new System.EventHandler(this.Form_SetUser_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_UserIndex;
        private System.Windows.Forms.TextBox txt_UserName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_SerUser;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btn_GetAllUser;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_UpdateUserName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lbError;
        public System.Windows.Forms.TextBox txt_SelectedUser;
        public System.Windows.Forms.TextBox txt_NewUserName;
        public System.Windows.Forms.ListView lv_User;
    }
}
﻿using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace ProtocolDemo
{
    public partial class Form_SetUser : Form
    {
        private Form_ProtocolDemo parentForm;

        private const int USERL_110 = 20;                    // 110   유저 길이(기계에서 직접 수정 시에는 15자로 제한됨)

        Regex userNameregex = new Regex("^[a-zA-Z0-9+]*$");  // NewUserName : 영어 숫자만 입력이 가능하도록 한다.

        public Form_SetUser(Form_ProtocolDemo parent)
        {
            InitializeComponent();

            this.parentForm = parent;
        }


        // USER EVENT
        private void btn_GetAllUser_Click(object sender, EventArgs e)
        {
            // [12-80] Get All User
            parentForm.m_ProtocolDll.PrtcGetAllUser();
        }

        private void btn_SerUser_Click(object sender, EventArgs e)
        {
            // [12-81] Set User
            string userIndex = txt_UserIndex.Text;

            if (string.IsNullOrEmpty(userIndex))
            {
                MessageBox.Show("Set User Data empty!");
                return;
            }


            int nSetUserIndex = Convert.ToInt32(userIndex);
            parentForm.m_ProtocolDll.PrtcSetUser(nSetUserIndex);
        }


        // DATA BIND
        public void DataBindUserInfo(byte[] userData)
        {
            if (lv_User.Items.Count > 0)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    lv_User.Items.Clear();
                }));
            }

            int nPos = 0;
            int nStartIndex = 0;
            int nUserNameCount = 0;
            int nUserDataCount = userData[nPos++];

            int nUserIndex = 0;
            byte[] UserName = new byte[30];

            for (int i = 0; i < nUserDataCount; i++)
            {
                // User Index
                nUserIndex = userData[nPos++];
                nStartIndex = nPos;

                // User Name
                nUserNameCount = 0;
                while (userData[nPos++] != '|')
                {
                    nUserNameCount++;
                }

                Array.Clear(UserName, 0, 30);
                Array.Copy(userData, nStartIndex, UserName, 0, nUserNameCount);


                ListViewItem lvi = new ListViewItem((nUserIndex).ToString());
                lvi.SubItems.Add(Encoding.ASCII.GetString(UserName, 0, UserName.Length));

                this.Invoke(new MethodInvoker(delegate()
                    {
                        lv_User.Items.Add(lvi);
                    }));
            }
        }

        public void InitSetUserData()
        {
            txt_UserIndex.Text = string.Empty;
            txt_UserName.Text = string.Empty;
        }

        private void lv_User_DoubleClick(object sender, EventArgs e)
        {
            txt_UserIndex.Text    = lv_User.SelectedItems[0].SubItems[0].Text;
            txt_UserName.Text     = lv_User.SelectedItems[0].SubItems[1].Text;
            txt_SelectedUser.Text = lv_User.SelectedItems[0].SubItems[1].Text;
        }

        private void Error_string(bool bshow, string _strError = "")
        {
            if (bshow)
            {
                lbError.Text = _strError;
                lbError.Visible = true;
            }
            else
            {
                lbError.Visible = false;                  // 에러 문구 비표시
            }
        }

        private void btn_ModifyUserName_Click(object sender, EventArgs e)
        {
            if (parentForm._connected == false)                                      // 연결확인
            {
                MessageBox.Show("Please Connect!");
                return;
            }

            if(lv_User.Items.Count == 0)
            {
                MessageBox.Show("Please Activating the list");
                return;
            }

            if (lv_User.SelectedIndices.Count == 0)                                  // 리스트 항목 선택 여부 확인
            {
                if(string.IsNullOrEmpty(txt_SelectedUser.Text.Trim()) == false)
                {
                    SelectListItem();                                                // 다른 곳을 클릭하여 리스트 선택이 풀린경우
                }
                else
                {
                    MessageBox.Show("Please select an item");
                    return;
                }
            }

            if(string.IsNullOrEmpty(txt_SelectedUser.Text.Trim()))
            {
                MessageBox.Show("Please double-click on the user");                 // 유저 더블클릭 여부 조사
                return;
            }

            if (string.IsNullOrEmpty(txt_NewUserName.Text.Trim()))                  // txt Box의 공백 제거 후에 입력 값이 있는지 확인
            {
                TextValidation(txt_NewUserName, true);                              // Text box Error : true
                Error_string(true, "No input found");
                return;
            }
            else
            {
                TextValidation(txt_NewUserName, false);                             // Text box Error : false
                Error_string(false);
            }

            int DTL     = Encoding.ASCII.GetBytes(txt_NewUserName.Text).Length;             // 입력받은 문자열의 길이
            byte[] DT   = new byte[DTL + 1];                                                // 1 : index
            DT[0]       = Convert.ToByte(lv_User.SelectedItems[0].SubItems[0].Text);        // index
            Array.Copy(Encoding.ASCII.GetBytes(txt_NewUserName.Text), 0, DT, 1, DTL);       // New User Name

            parentForm.m_ProtocolDll.PrtcModifyUserName(DTL + 1, DT);                       // [12-85] ModifyUserName
        }

        // TextBox 입력 이벤트 발생 시 유효성 검사
        private void txt_NewUserName_TextChanged(object sender, EventArgs e)
        {
            bool _btextcheck = userNameregex.IsMatch(txt_NewUserName.Text);                    // 유효성 검사
            int nstrLength = txt_NewUserName.Text.Length;                                      // 문자열 길이

            if (!_btextcheck && nstrLength != 0)
            {
                txt_NewUserName.Text = txt_NewUserName.Text.Substring(0, nstrLength - 1);      // 위반 시 마지막 글자를 제거한 나머지를 복사
                txt_NewUserName.Select(txt_NewUserName.Text.Length, 0);                        // 커서를 맨 뒤로 맞춤

                TextValidation(txt_NewUserName, true);                                         // Text box Error : true
                Error_string(true, "English and Number");
            }
        }
        
        private void SelectListItem()
        {
            for (int i = 0; i < lv_User.Items.Count; i++)   // 컨트롤에 입력되어있는 유저를 리스트에서 선택한다.
            {
                if (string.Compare(lv_User.Items[i].SubItems[1].Text, txt_SelectedUser.Text) == 0)
                    lv_User.Items[i].Selected = true;
                else
                    lv_User.Items[i].Selected = false;
            }
        }

        private void TextValidation(TextBox txtbox, bool validcheck)     // txt 박스 테두리 유효성 검사
        {
            int nborderSize = 3;
            Rectangle _rect = new Rectangle(txtbox.Location.X - nborderSize, txtbox.Location.Y - nborderSize, txtbox.Width + (nborderSize * 2), txtbox.Height + (nborderSize * 2));

            if (validcheck == true)
            {
                using (Pen p = new Pen(Color.Red))                       // 붉은 색 팬
                using (Graphics g = groupBox1.CreateGraphics())          // this.CreateGraphics())//Graphics.FromHwnd(this.Handle))      // 붉은 사각형을 텍스트 박스 테두리에 그림
                {
                    g.DrawRectangle(p, _rect);
                }
            }
            else
            {
                using (Pen p = new Pen(SystemColors.Control))            // Control 기본 색
                using (Graphics g = groupBox1.CreateGraphics())
                {
                    g.DrawRectangle(p, _rect);
                }
            }
        }

        private void Form_SetUser_Shown(object sender, EventArgs e)
        {
            lbError.Visible = false;                                     // 경고 텍스트 비활성

            if (lv_User.Items.Count > 0)                                 // 리스트 정보 초기화
                lv_User.Items.Clear();

            txt_UserIndex.Text     = string.Empty;
            txt_UserName.Text      = string.Empty;
            txt_SelectedUser.Text  = string.Empty;
            txt_NewUserName.Text   = string.Empty;

            txt_NewUserName.MaxLength = USERL_110 -1;                    // 텍스트 수 제한(기기안에서 표시 가능한 수)
        }
    }
}

﻿namespace ProtocolDemo
{
    partial class Form_SetLocalDenom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_getLocalDenom = new System.Windows.Forms.Button();
            this.lv_local = new System.Windows.Forms.ListView();
            this.col_index = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_local = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_local_onoff = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_setLocalDenom = new System.Windows.Forms.Button();
            this.lv_denom = new System.Windows.Forms.ListView();
            this.col_denom_index = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom_old = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom_old_onoff = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom_new = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom_new_onoff = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom_latest = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_denom_latest_onoff = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_getLocalDenom
            // 
            this.btn_getLocalDenom.Location = new System.Drawing.Point(12, 12);
            this.btn_getLocalDenom.Name = "btn_getLocalDenom";
            this.btn_getLocalDenom.Size = new System.Drawing.Size(152, 30);
            this.btn_getLocalDenom.TabIndex = 1;
            this.btn_getLocalDenom.Text = "Get Local Denom";
            this.btn_getLocalDenom.UseVisualStyleBackColor = true;
            this.btn_getLocalDenom.Click += new System.EventHandler(this.btn_getLocalDenom_Click);
            // 
            // lv_local
            // 
            this.lv_local.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_index,
            this.col_local,
            this.col_local_onoff});
            this.lv_local.FullRowSelect = true;
            this.lv_local.GridLines = true;
            this.lv_local.Location = new System.Drawing.Point(12, 89);
            this.lv_local.Name = "lv_local";
            this.lv_local.Size = new System.Drawing.Size(220, 350);
            this.lv_local.TabIndex = 2;
            this.lv_local.UseCompatibleStateImageBehavior = false;
            this.lv_local.View = System.Windows.Forms.View.Details;
            this.lv_local.Click += new System.EventHandler(this.lv_local_Click);
            // 
            // col_index
            // 
            this.col_index.Text = "Index";
            // 
            // col_local
            // 
            this.col_local.Text = "Local";
            // 
            // col_local_onoff
            // 
            this.col_local_onoff.Text = "On/Off";
            // 
            // btn_setLocalDenom
            // 
            this.btn_setLocalDenom.Location = new System.Drawing.Point(173, 12);
            this.btn_setLocalDenom.Name = "btn_setLocalDenom";
            this.btn_setLocalDenom.Size = new System.Drawing.Size(152, 30);
            this.btn_setLocalDenom.TabIndex = 5;
            this.btn_setLocalDenom.Text = "Set Local Denom";
            this.btn_setLocalDenom.UseVisualStyleBackColor = true;
            this.btn_setLocalDenom.Click += new System.EventHandler(this.btn_setLocalDenom_Click);
            // 
            // lv_denom
            // 
            this.lv_denom.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_denom_index,
            this.col_denom_old,
            this.col_denom_old_onoff,
            this.col_denom_new,
            this.col_denom_new_onoff,
            this.col_denom_latest,
            this.col_denom_latest_onoff});
            this.lv_denom.FullRowSelect = true;
            this.lv_denom.GridLines = true;
            this.lv_denom.Location = new System.Drawing.Point(252, 89);
            this.lv_denom.Name = "lv_denom";
            this.lv_denom.Size = new System.Drawing.Size(582, 350);
            this.lv_denom.TabIndex = 6;
            this.lv_denom.UseCompatibleStateImageBehavior = false;
            this.lv_denom.View = System.Windows.Forms.View.Details;
            this.lv_denom.Click += new System.EventHandler(this.lv_denom_Click);
            // 
            // col_denom_index
            // 
            this.col_denom_index.Text = "Index";
            // 
            // col_denom_old
            // 
            this.col_denom_old.Text = "Denom - Old";
            this.col_denom_old.Width = 100;
            // 
            // col_denom_old_onoff
            // 
            this.col_denom_old_onoff.Text = "On/Off";
            // 
            // col_denom_new
            // 
            this.col_denom_new.Text = "Denom - New";
            this.col_denom_new.Width = 100;
            // 
            // col_denom_new_onoff
            // 
            this.col_denom_new_onoff.Text = "On/Off";
            // 
            // col_denom_latest
            // 
            this.col_denom_latest.Text = "Denom - Latest";
            this.col_denom_latest.Width = 100;
            // 
            // col_denom_latest_onoff
            // 
            this.col_denom_latest_onoff.Text = "On/Off";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Local Info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(250, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "Denom Info";
            // 
            // Form_SetLocalDenom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 449);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lv_denom);
            this.Controls.Add(this.btn_setLocalDenom);
            this.Controls.Add(this.lv_local);
            this.Controls.Add(this.btn_getLocalDenom);
            this.Name = "Form_SetLocalDenom";
            this.Text = "Set Local / Denom";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_SetLocalDenom_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_getLocalDenom;
        private System.Windows.Forms.ListView lv_local;
        private System.Windows.Forms.ColumnHeader col_index;
        private System.Windows.Forms.ColumnHeader col_local;
        private System.Windows.Forms.Button btn_setLocalDenom;
        private System.Windows.Forms.ColumnHeader col_local_onoff;
        private System.Windows.Forms.ListView lv_denom;
        private System.Windows.Forms.ColumnHeader col_denom_index;
        private System.Windows.Forms.ColumnHeader col_denom_old;
        private System.Windows.Forms.ColumnHeader col_denom_old_onoff;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ColumnHeader col_denom_new;
        private System.Windows.Forms.ColumnHeader col_denom_new_onoff;
        private System.Windows.Forms.ColumnHeader col_denom_latest;
        private System.Windows.Forms.ColumnHeader col_denom_latest_onoff;


    }
}
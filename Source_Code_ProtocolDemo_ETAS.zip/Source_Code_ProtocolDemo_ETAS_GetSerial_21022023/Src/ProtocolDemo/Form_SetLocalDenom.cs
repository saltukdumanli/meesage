﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace ProtocolDemo
{
    public partial class Form_SetLocalDenom : Form
    {
        private Form_ProtocolDemo parentForm;
        private Form_Progressbar progressbarForm = null;

        private const int MAX_DENOM_COUNT = 10;

        private bool _bStart = false;
        private bool _bSetLocal = false;
        private bool _bGetInfo = false;
        private bool _bSetInfo = false;
        private bool _bClose = false;

        public int _nGetIndex = 0;
        public int _nSetIndex = 0;
        private int _nSelectedListIndex = -1;

        private String _strCountryCodePath;
        private String _strDenomInfoPath;

        private List<LOCAL> _LocalList = new List<LOCAL>();
        private List<DENOM> _DenomList = new List<DENOM>();
        private List<int> _SetDenomListIndex = new List<int>();


        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(String section, String key, String val, String filePath);

        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(String section, String key, String def, StringBuilder retVal, int size, String filePath);


        public Form_SetLocalDenom(Form_ProtocolDemo parent)
        {
            InitializeComponent();

            this.parentForm = parent;

            _strCountryCodePath = String.Format("{0}\\Config\\CountryCode.ini", System.Environment.CurrentDirectory);
            _strDenomInfoPath = String.Format("{0}\\Config\\DenomInfo.ini", System.Environment.CurrentDirectory);
        }

        // Button Event Handler
        private void btn_getLocalDenom_Click(object sender, EventArgs e)
        {
            if (this.parentForm._connected == false)
            {
                MessageBox.Show("Please connect the machine before setting local / denom.");
                return;
            }

            if (_bGetInfo == true)
            {
                MessageBox.Show("Get Local / Denom is running.");
                return;
            }

            if (_bSetInfo == true)
            {
                MessageBox.Show("Set Local / Denom is running");
                return;
            }

            if (_bStart == true)
            {
                MessageBox.Show("Get Local / Denom is already running.");
                return;
            }

            _nGetIndex = 0;

            if (_LocalList.Count > 0)
                _LocalList.Clear();

            if (_DenomList.Count > 0)
                _DenomList.Clear();

            if (_SetDenomListIndex.Count > 0)
                _SetDenomListIndex.Clear();

            if (lv_local.Items.Count > 0)
                lv_local.Items.Clear();

            if (lv_denom.Items.Count > 0)
                lv_denom.Items.Clear();


            _bGetInfo = true;
            _bStart = true;
            this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomStart();
        }

        private void btn_setLocalDenom_Click(object sender, EventArgs e)
        {
            if (this.parentForm._connected == false)
            {
                MessageBox.Show("Please connect the machine before setting local / denom.");
                return;
            }

            if (_bSetInfo == true)
            {
                MessageBox.Show("Set Local / Denom is running");
                return;
            }

            if (CheckLocal() == false)
            {
                MessageBox.Show("You can not set all local items off. At least one must be set to on.");
                return;
            }

            if (CheckDenom() == false)
            {
                MessageBox.Show("You can not set all Denom items off. At least one must be set to on.");
                return;
            }


            bool bLCSetLocal = false;

            for (int i = 0; i < lv_local.Items.Count; i++)
            {
                if (lv_local.Items[i].SubItems[2].Text == "ON")
                    bLCSetLocal = true;
                else
                    bLCSetLocal = false;

                if (_LocalList[i].LOCAL_ON_OFF != bLCSetLocal)
                {
                    _bSetLocal = true;
                    break;
                }
            }

            if (_bSetLocal == false && _SetDenomListIndex.Count <= 0)
            {
                MessageBox.Show("You have not set local/denom information.");
                return;
            }


            _bSetInfo = true;
            _nSetIndex = 0;

            if (progressbarForm == null)
            {
                progressbarForm = new Form_Progressbar();
                progressbarForm.Show();
            }

            if (_bSetLocal)
                SetLocalInfo();
            else
                SetDenomInfo();
        }

        private String GetLocalName(int nLocalCode)
        {
            StringBuilder retVal = new StringBuilder();
            GetPrivateProfileString("CountryCode", nLocalCode.ToString(), String.Empty, retVal, 10, _strCountryCodePath);

            return retVal.ToString();
        }

        private String GetDenomName(String strLocal, int nDenomIndex)
        {
            StringBuilder retVal = new StringBuilder();
            GetPrivateProfileString(strLocal, "Denom_" + nDenomIndex.ToString(), String.Empty, retVal, 30, _strDenomInfoPath);

            return retVal.ToString();
        }

        private int GetDenomCount(String strLocal)
        {
            StringBuilder retVal = new StringBuilder();
            GetPrivateProfileString(strLocal, "Denom_Count", String.Empty, retVal, 10, _strDenomInfoPath);

            if (retVal.Length <= 0)
                return 0;
            else
                return Convert.ToInt32(retVal.ToString());
        }

        private bool CheckLocal()
        {
            int nOnCount = 0;

            for (int i = 0; i < lv_local.Items.Count; i++)
            {
                if (lv_local.Items[i].SubItems[2].Text == "ON")
                    nOnCount++;
            }

            if (nOnCount <= 0)
                return false;
            else
                return true;
        }

        private bool CheckDenom()
        {
            bool bResult = true;
            bool bDenomOld = false;
            bool bDenomNew = false;
            bool bDenomLatest = false;

            int nListIndex = 0;
            int nDenomOldOnCount = 0;
            int nDenomNewOnCount = 0;
            int nDenomLatestOnCount = 0;

            UInt16 bitMask = 0;

            for (int i = 0; i < _SetDenomListIndex.Count; i++)
            {
                bitMask = 32768; // 1000 0000 0000 0000

                bDenomOld = false;
                bDenomNew = false;
                bDenomLatest = false;

                nDenomOldOnCount = 0;
                nDenomNewOnCount = 0;
                nDenomLatestOnCount = 0;

                nListIndex = _SetDenomListIndex[i];
                for (int j = 0; j < MAX_DENOM_COUNT; j++)
                {
                    // DENOM USED
                    if (bDenomOld == false)
                    {
                        if ((_DenomList[nListIndex].DENOM_USED_OLD & bitMask) != 0)
                            bDenomOld = true;
                    }

                    if (bDenomNew == false)
                    {
                        if ((_DenomList[nListIndex].DENOM_USED_NEW & bitMask) != 0)
                            bDenomNew = true;
                    }

                    if (bDenomLatest == false)
                    {
                        if ((_DenomList[nListIndex].DENOM_USED_LATEST & bitMask) != 0)
                            bDenomLatest = true;
                    }


                    // DENOM ON/OFF
                    if ((_DenomList[nListIndex].DENOM_OLD & bitMask) != 0)
                        nDenomOldOnCount++;

                    if ((_DenomList[nListIndex].DENOM_NEW & bitMask) != 0)
                        nDenomNewOnCount++;

                    if ((_DenomList[nListIndex].DENOM_LATEST & bitMask) != 0)
                        nDenomLatestOnCount++;

                    bitMask = Convert.ToUInt16(bitMask >> 1);
                }

                if (bDenomOld == true && nDenomOldOnCount <= 0)
                {
                    bResult = false;
                    break;
                }

                if (bDenomNew == true && nDenomNewOnCount <= 0)
                {
                    bResult = false;
                    break;
                }

                if (bDenomLatest == true && nDenomLatestOnCount <= 0)
                {
                    bResult = false;
                    break;
                }
            }

            return bResult;
        }

        private void DataBindLocal()
        {
            this.Invoke(new MethodInvoker(delegate()
               {
                   if (lv_local.Items.Count > 0)
                       lv_local.Items.Clear();

                   lv_local.BeginUpdate();
               }));

            String strLocalOnOff;

            for (int i = 0; i < _LocalList.Count; i++)
            {
                ListViewItem lvi = new ListViewItem((i+1).ToString());
                lvi.SubItems.Add(_LocalList[i].LOCAL_NAME);

                if (_LocalList[i].LOCAL_ON_OFF == true)
                    strLocalOnOff = "ON";
                else
                    strLocalOnOff = "OFF";

                lvi.SubItems.Add(strLocalOnOff);

                this.Invoke(new MethodInvoker(delegate()
               {
                   lv_local.Items.Add(lvi);
               }));
            }

            this.Invoke(new MethodInvoker(delegate()
               {
                   lv_local.EndUpdate();
               }));
        }

        private void DataBindDenom(String strLocal)
        {
            if (lv_denom.Items.Count > 0)
            {
                lv_denom.Items.Clear();
            }

            if (_DenomList[_nSelectedListIndex].DENOM_COUNT <= 0)
            {
                MessageBox.Show("There is no denom information in the denominfo.ini file.");
                return;
            }

            lv_denom.BeginUpdate();

            UInt16 bitMask = 32768; // 1000 0000 0000 0000
            bool bDenomUsedOld = false;
            bool bDenomUsedNew = false;
            bool bDenomUsedLatest = false;
            string strValue;
            string strDenomName;

            for (int i = 0; i < MAX_DENOM_COUNT; i++)
            {
                bDenomUsedOld = ((_DenomList[_nSelectedListIndex].DENOM_USED_OLD & bitMask) == 0) ? false : true;
                bDenomUsedNew = ((_DenomList[_nSelectedListIndex].DENOM_USED_NEW & bitMask) == 0) ? false : true;
                bDenomUsedLatest = ((_DenomList[_nSelectedListIndex].DENOM_USED_LATEST & bitMask) == 0) ? false : true;

                // Index
                if (bDenomUsedOld || bDenomUsedNew || bDenomUsedLatest)
                {
                    strValue = Convert.ToString(i + 1);
                }
                else
                {
                    strValue = string.Empty;
                }
                ListViewItem lvi = new ListViewItem(strValue); // Index

                strDenomName = GetDenomName(_LocalList[_nSelectedListIndex].LOCAL_NAME, i + 1);

                // DENOM OLD
                if (bDenomUsedOld)
                {
                    // DENOM OLD NAME
                    lvi.SubItems.Add(strDenomName);

                    // DENOM OLD ON/OFF
                    if ((_DenomList[_nSelectedListIndex].DENOM_OLD & bitMask) == 0)
                        strValue = "OFF";
                    else
                        strValue = "ON";
                    lvi.SubItems.Add(strValue);
                }
                else
                {
                    lvi.SubItems.Add(""); // DENOM OLD NAME
                    lvi.SubItems.Add(""); // DENOM OLD ON/OFF
                }

                // DENOM NEW
                if (bDenomUsedNew)
                {
                    // DENOM NEW NAME
                    lvi.SubItems.Add(strDenomName);

                    // DENOM NEW ON/OFF
                    if ((_DenomList[_nSelectedListIndex].DENOM_NEW & bitMask) == 0)
                        strValue = "OFF";
                    else
                        strValue = "ON";
                    lvi.SubItems.Add(strValue);
                }
                else
                {
                    lvi.SubItems.Add(""); // DENOM NEW NAME
                    lvi.SubItems.Add(""); // DENOM NEW ON/OFF
                }

                // DENOM LATEST
                if (bDenomUsedLatest)
                {
                    // DENOM LATEST NAME
                    lvi.SubItems.Add(strDenomName);

                    // DENOM LATEST ON/OFF
                    if ((_DenomList[_nSelectedListIndex].DENOM_LATEST & bitMask) == 0)
                        strValue = "OFF";
                    else
                        strValue = "ON";
                    lvi.SubItems.Add(strValue);
                }
                else
                {
                    lvi.SubItems.Add(""); // DENOM LATEST NAME
                    lvi.SubItems.Add(""); // DENOM LATEST ON/OFF
                }

                lv_denom.Items.Add(lvi);

                bitMask = Convert.ToUInt16(bitMask >> 1);
            }
         
            lv_denom.EndUpdate();   
        }

        private void SetLocalInfo()
        {
            int nIndex = 1;
            int DTL = (_LocalList.Count * 2) + 1;
            byte[] DT = new byte[DTL];

            // LOCAL COUNT
            DT[0] = Convert.ToByte(_LocalList.Count);

            for (int i = 0; i < _LocalList.Count; i++)
            {
                // LOCAL CODE
                DT[nIndex++] = Convert.ToByte(_LocalList[i].LOCAL_CODE);

                if (lv_local.Items[i].SubItems[2].Text == "ON")
                    DT[nIndex++] = Convert.ToByte(true);
                else
                    DT[nIndex++] = Convert.ToByte(false);
            }

            this.parentForm.m_ProtocolDll.PrtcSetSelectLocal(DTL, DT);
        }

        private void SetDenomInfo()
        {
            if (_nSetIndex < _SetDenomListIndex.Count)
            {
                int nIndex = _SetDenomListIndex[_nSetIndex];

                int DTL = 7;
                byte[] DT = new byte[DTL];

                // LOCAL CODE
                DT[0] = Convert.ToByte(_LocalList[nIndex].LOCAL_CODE);

                // DENOM OLD
                DT[1] = Convert.ToByte(_DenomList[nIndex].DENOM_OLD >> 8);
                DT[2] = Convert.ToByte(_DenomList[nIndex].DENOM_OLD & 0x00FF);

                // DENOM NEW
                DT[3] = Convert.ToByte(_DenomList[nIndex].DENOM_NEW >> 8);
                DT[4] = Convert.ToByte(_DenomList[nIndex].DENOM_NEW & 0x00FF);

                // DENOM LATEST
                DT[5] = Convert.ToByte(_DenomList[nIndex].DENOM_LATEST >> 8);
                DT[6] = Convert.ToByte(_DenomList[nIndex].DENOM_LATEST & 0x00FF);

                this.parentForm.m_ProtocolDll.PrtcSetSelectDenom(DTL, DT);

                _nSetIndex++;
            }
            else
            {
                if (_bSetLocal)
                    this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(true);
                else
                    this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void GetUsedDenomInfo()
        {
            if (_nGetIndex < _LocalList.Count)
            {
                this.parentForm.m_ProtocolDll.PrtcGetusedDenom(_LocalList[_nGetIndex].LOCAL_CODE);
            }
            else
            {
                _nGetIndex = 0;
                GetDenomInfo();
            }
        }

        public void GetDenomInfo()
        {
            if (_nGetIndex < _DenomList.Count)
            {
                this.parentForm.m_ProtocolDll.PrtcGetSelectDenom(_LocalList[_nGetIndex].LOCAL_CODE);
            }
            else
            {
                _nGetIndex = 0;
                _bGetInfo = false;

                DataBindLocal();
            }
        }

        private void AddListIndexDenom(int nIndex)
        {
            bool bCheck = false;
            for (int i = 0; i < _SetDenomListIndex.Count; i++)
            {
                if (_SetDenomListIndex[i] == nIndex)
                {
                    bCheck = true;
                    break;
                }
            }

            if (bCheck == false)
            {
                _SetDenomListIndex.Add(nIndex);
            }
        }

        // ListView Event Handler
        private void lv_local_Click(object sender, EventArgs e)
        {
            Point mousePos = lv_local.PointToClient(Control.MousePosition);
            ListViewHitTestInfo hitTest = lv_local.HitTest(mousePos);
            int nColIndex = hitTest.Item.SubItems.IndexOf(hitTest.SubItem);
            
            // DENOM LISTVIEW Clear
            if (lv_denom.Items.Count > 0)
                lv_denom.Items.Clear();

            _nSelectedListIndex = lv_local.SelectedItems[0].Index;

            if (nColIndex == 2) // Local On/Off Click
            {
                if (lv_local.SelectedItems[0].SubItems[2].Text == "ON")
                {
                    lv_local.SelectedItems[0].SubItems[2].Text = "OFF";
                }
                else
                {
                    lv_local.SelectedItems[0].SubItems[2].Text = "ON";
                }
            }
            else
            {
                DataBindDenom(lv_local.SelectedItems[0].SubItems[1].Text);
            }
        }

        private void lv_denom_Click(object sender, EventArgs e)
        {
            Point mousePos = lv_denom.PointToClient(Control.MousePosition);
            ListViewHitTestInfo hitTest = lv_denom.HitTest(mousePos);
            int nColIndex = hitTest.Item.SubItems.IndexOf(hitTest.SubItem);

            bool bDenomOnOff = false;

            if (nColIndex == 2) // DENOM OLD - ON/OFF
            {
                if (lv_denom.SelectedItems[0].SubItems[2].Text == "ON")
                {
                    bDenomOnOff = false;
                    lv_denom.SelectedItems[0].SubItems[2].Text = "OFF";
                }
                else
                {
                    bDenomOnOff = true;
                    lv_denom.SelectedItems[0].SubItems[2].Text = "ON";
                }

                if (_nSelectedListIndex != -1)
                {
                    if (bDenomOnOff)
                    {
                        _DenomList[_nSelectedListIndex].DENOM_OLD |= Convert.ToUInt16(1 << (15 - lv_denom.SelectedItems[0].Index)); // ON
                    }
                    else
                    {
                        _DenomList[_nSelectedListIndex].DENOM_OLD &= Convert.ToUInt16(( ~(1 << (15 - lv_denom.SelectedItems[0].Index)) ) & 0xFFFF);
                    }

                    AddListIndexDenom(_nSelectedListIndex);
                }
            }
            else if (nColIndex == 4) // DENOM New - ON/OFF
            {
                if (lv_denom.SelectedItems[0].SubItems[4].Text == "ON")
                {
                    bDenomOnOff = false;
                    lv_denom.SelectedItems[0].SubItems[4].Text = "OFF";
                }
                else
                {
                    bDenomOnOff = true;
                    lv_denom.SelectedItems[0].SubItems[4].Text = "ON";
                }

                if (_nSelectedListIndex != -1)
                {
                    if (bDenomOnOff)
                    {
                        _DenomList[_nSelectedListIndex].DENOM_NEW |= Convert.ToUInt16(1 << (15 - lv_denom.SelectedItems[0].Index)); // ON
                    }
                    else
                    {
                        _DenomList[_nSelectedListIndex].DENOM_NEW &= Convert.ToUInt16((~(1 << (15 - lv_denom.SelectedItems[0].Index))) & 0xFFFF);
                    }

                    AddListIndexDenom(_nSelectedListIndex);
                }
            }
            else if (nColIndex == 6) // DENOM LATEST - ON/OFF
            {
                if (lv_denom.SelectedItems[0].SubItems[6].Text == "ON")
                {
                    bDenomOnOff = false;
                    lv_denom.SelectedItems[0].SubItems[6].Text = "OFF";
                }
                else
                {
                    bDenomOnOff = true;
                    lv_denom.SelectedItems[0].SubItems[6].Text = "ON";
                }

                if (_nSelectedListIndex != -1)
                {
                    if (bDenomOnOff)
                    {
                        _DenomList[_nSelectedListIndex].DENOM_LATEST |= Convert.ToUInt16(1 << (15 - lv_denom.SelectedItems[0].Index)); // ON
                    }
                    else
                    {
                        _DenomList[_nSelectedListIndex].DENOM_LATEST &= Convert.ToUInt16((~(1 << (15 - lv_denom.SelectedItems[0].Index))) & 0xFFFF);
                    }

                    AddListIndexDenom(_nSelectedListIndex);
                }
            }
        }

        private void Form_SetLocalDenom_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_LocalList.Count > 0)
                _LocalList.Clear();

            if (_DenomList.Count > 0)
                _DenomList.Clear();

            if (_SetDenomListIndex.Count > 0)
                _SetDenomListIndex.Clear();

            if (lv_local.Items.Count > 0)
                lv_local.Items.Clear();

            if (lv_denom.Items.Count > 0)
                lv_denom.Items.Clear();


            if (_bStart)
            {
                _bClose = true;
                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcSelectLocalDenomStart(byte result)
        {
            if (result == 1)
            {
                this.parentForm.m_ProtocolDll.PrtcGetSelectLocal();
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-30] Select Local/Denom Start Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);

                _bGetInfo = false;
                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcGetSelectLocal(byte[] localInfo)
        {
            if (localInfo.Length > 0)
            {
                int index = 1;
                int localCount = localInfo[0];

                for (int i = 0; i < localCount; i++)
                {
                    LOCAL local = new LOCAL();
                    local.LOCAL_CODE = localInfo[index++];
                    local.LOCAL_ON_OFF = Convert.ToBoolean(localInfo[index++]);
                    local.LOCAL_NAME = GetLocalName(local.LOCAL_CODE);

                    _LocalList.Add(local);
                }


                GetUsedDenomInfo();
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-31] Get Select Local Start Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);

                _bGetInfo = false;
                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcSetSelectLocal(byte result)
        {
            if (result == 1)
            {
                SetDenomInfo();
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-32] Set Select Local Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);


                _bSetInfo = false;

                progressbarForm.Close();
                progressbarForm = null;

                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcGetUsedDenom(byte[] denomInfo)
        {
            if (denomInfo.Length == 6)
            {
                DENOM denom = new DENOM();
                denom.DENOM_USED_OLD = Convert.ToUInt16((denomInfo[0] << 8) | (denomInfo[1]));
                denom.DENOM_USED_NEW = Convert.ToUInt16((denomInfo[2] << 8) | (denomInfo[3]));
                denom.DENOM_USED_LATEST = Convert.ToUInt16((denomInfo[4] << 8) | (denomInfo[5]));
                denom.DENOM_COUNT = GetDenomCount(_LocalList[_nGetIndex].LOCAL_NAME);

                _DenomList.Add(denom);


                _nGetIndex++;
                GetUsedDenomInfo();
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-33] Get Used Denom Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);

                _bGetInfo = false;
                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcGetSelectDenom(byte[] denomInfo)
        {
            if (denomInfo.Length == 6)
            {
                DENOM denom = _DenomList[_nGetIndex];
                denom.DENOM_OLD = Convert.ToUInt16((denomInfo[0] << 8) | (denomInfo[1]));
                denom.DENOM_NEW = Convert.ToUInt16((denomInfo[2] << 8) | (denomInfo[3]));
                denom.DENOM_LATEST = Convert.ToUInt16((denomInfo[4] << 8) | (denomInfo[5]));

                _nGetIndex++;
                GetDenomInfo();
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-34] Get Select Denom Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);

                _bGetInfo = false;
                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcSetSelectDenom(byte result)
        {
            if (result == 1)
            {
                SetDenomInfo();
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-35] Set Select Denom Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);

                _bSetInfo = false;

                progressbarForm.Close();
                progressbarForm = null;

                this.parentForm.m_ProtocolDll.PrtcSelectLocalDenomEnd(false);
            }
        }

        public void RecvPrtcSelectLocalDenomEnd(byte result)
        {
            _bSetInfo = false;
            _bStart = false;

            if (result == 1)
            {
                if (_LocalList.Count > 0)
                    _LocalList.Clear();

                if (_DenomList.Count > 0)
                    _DenomList.Clear();

                if (_SetDenomListIndex.Count > 0)
                    _SetDenomListIndex.Clear();

                if (_bClose == false)
                {
                    this.Invoke(new MethodInvoker(delegate()
                        {
                            if (lv_local.Items.Count > 0)
                                lv_local.Items.Clear();

                            if (lv_denom.Items.Count > 0)
                                lv_denom.Items.Clear();
                        }));
                }
            }
            else
            {
                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                log += "[Protocol:11-36] Select Local/Denom Protocol Failed!";
                this.parentForm.SetLogWriteLine(log);
            }

            if (progressbarForm != null)
            {
                this.Invoke(new MethodInvoker(delegate()
                    {
                        progressbarForm.Close();
                        progressbarForm = null;
                    }));
            }
        }
    }



    // Class Definition
    public class LOCAL
    {
        public int LOCAL_CODE { get; set; }
        public bool LOCAL_ON_OFF { get; set; }
        public string LOCAL_NAME { get; set; }
    }

    public class DENOM
    {
        public int DENOM_COUNT { get; set; }

        public UInt16 DENOM_USED_OLD;
        public UInt16 DENOM_USED_NEW;
        public UInt16 DENOM_USED_LATEST;

        public UInt16 DENOM_OLD;
        public UInt16 DENOM_NEW;
        public UInt16 DENOM_LATEST;
    }
}

﻿using ProtocolDll;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;


namespace ProtocolDemo
{
    public partial class Form_ProtocolDemo : Form
    {
        [Flags]
        public enum CallFlag : byte
        {
            ATM    = 1 << 0,
            FIT    = 1 << 1,
            UNFIT  = 1 << 2,
            VALUE  = 1 << 3,
            MANUAL = 1 << 4,
            REJECT = 1 << 5
        };

        public enum Models { ST350, ST150N, IH110 };

        private bool m_bThreadStop = false;
        private Thread m_threadWmCopyData;
        private Queue<byte[]> m_queWmCopyData = new Queue<byte[]>();

        public Protocol m_ProtocolDll;

        bool _serverStart = false;
        public bool _connected = false;
        
        public string _strMachineSN = string.Empty;
        public Models _model = 0;
        MachineInfo stMachineInfo;

        // CountingFinishNew //
        LocalInfo _localInfo;
        GTotalInfo _gtotalInfo;
        Queue<int> _queCallFlag = new Queue<int>();
        public int _callFlag = 0;
        public int _localCount = 0;
        public int _localIndex = 0;
        public int _gtotalIndex = 0;
        // CountingFinishNew //


        _SNI_HEADER_  _SNIHeader  = new _SNI_HEADER_();
        _SNI_BODY_    _SNIBody    = new _SNI_BODY_();
        _CHEQUE_MICR_ _ChequeMICR = new _CHEQUE_MICR_();
        _CHEQUE_QR_   _ChequeQR   = new _CHEQUE_QR_();

        Form_Upgrade       _upgradeForm;
        Form_SNViewer      _snviewerForm;
        Form_SetLocalDenom _setLocalDenomForm;
        Form_SetUseLocal   _setUseLocalForm;
        Form_SetUser       _setUserForm;

        byte[] _fimgBuf = new byte[432 * 500 * 300];
        int _fimgBufIdx = 0;
        string _strFImgPath = string.Empty;
        private int _imageIndex = 0;

        List<_CHEQUE_QR_> _chequeQRList = new List<_CHEQUE_QR_>();


        public Form_ProtocolDemo()
        {
            InitializeComponent();

            _model = Models.IH110;

            m_ProtocolDll = new Protocol();
            m_ProtocolDll.SNIDataEvent += M_ProtocolDll_SNIDataEvent;
            m_ProtocolDll.ProtocolEvent += M_ProtocolDll_ProtocolEvent;

            _upgradeForm = new Form_Upgrade(this);
            _snviewerForm = new Form_SNViewer();
            _setLocalDenomForm = new Form_SetLocalDenom(this);
            _setUseLocalForm = new Form_SetUseLocal(this);
            _setUserForm = new Form_SetUser(this);

            _localInfo = new LocalInfo();
            _gtotalInfo = new GTotalInfo();
            
            SetPortName();
            SetBaudRate();
            SetType();

            m_bThreadStop = false;
            m_threadWmCopyData = new Thread(ThreadHandlerWmCopyData);
            m_threadWmCopyData.IsBackground = true;
            m_threadWmCopyData.Start();
        }

        private void M_ProtocolDll_ProtocolEvent(byte[] protocolData)
        {
            m_queWmCopyData.Enqueue(protocolData);
        }

        private void M_ProtocolDll_SNIDataEvent(byte[] data)
        {
            //Debug.WriteLine("* M_ProtocolDll_SNIDataEvent()");

            this.ProtocolHandling(data);
        }

        private void ThreadHandlerWmCopyData()
        {
            //this.m_bThreadStop = true;

            while (!this.m_bThreadStop)
            {
                if (this.m_queWmCopyData.Count > 0)
                {
                    byte[] wmCopyData = this.m_queWmCopyData.Dequeue();
                    this.ProtocolHandling(wmCopyData);
                }
                else
                {
                    Thread.Sleep(10);
                }
            }
        }

        private void SetPortName()
        {
            string[] ports = SerialPort.GetPortNames();

            for (int i = 0; i < ports.Length; i++)
            {
                if (ExistPortName(ports[i]) == false)
                    cbb_portName.Items.Add(ports[i]);
            }

            if (cbb_portName.Items.Count > 0)
                cbb_portName.SelectedIndex = 0;
        }

        private bool ExistPortName(string portName)
        {
            bool bExist = false;

            for (int i = 0; i < cbb_portName.Items.Count; i++)
            {
                if (cbb_portName.Items[i].ToString() == portName)
                    bExist = true;
            }

            return bExist;
        }

        private void SetBaudRate()
        {
            cbb_baudRate.Items.Add("115200");
            cbb_baudRate.Items.Add("230400");
            cbb_baudRate.Items.Add("460800");
            cbb_baudRate.Items.Add("921600");
            cbb_baudRate.Items.Add("11520");

            cbb_baudRate.SelectedIndex = 3;
        }

        private void SetType()
        {
            cbb_type.Items.Add("USB");
            cbb_type.Items.Add("SERIAL");

            cbb_type.SelectedIndex = 0;
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            if (_connected == true)
            {
                if (_serverStart == true)
                {
                    MessageBox.Show("The Lan server is already connected.");
                }
                else
                {
                    MessageBox.Show("The COM Port is already connected.");
                }
                return;
            }

            if (cbb_portName.SelectedIndex == -1)
            {
                MessageBox.Show("port name!");
                return;
            }

            if (cbb_baudRate.SelectedIndex == -1)
            {
                MessageBox.Show("baud rate!");
                return;
            }

            if (cbb_type.SelectedIndex == -1)
            {
                MessageBox.Show("Please select type!");
                return;
            }

            if (Protocol.CheckDll())
            {

                int baudRate = Convert.ToInt32(cbb_baudRate.SelectedItem);
                int portType = Convert.ToInt32(cbb_type.SelectedIndex);

                string[] ports = SerialPort.GetPortNames();

                foreach (var port in ports)
                {

                    if (m_ProtocolDll.OpenSerialPort(port, baudRate, portType))
                    {
                      //  m_ProtocolDll.PrtcGetMachineInfoIH();

                        

                        _connected = true;
                        lblComPortState.Text = "State : SerialPort Connected";

                        string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                        result += "SerialPort Connencted";

                        SetLogWriteLine(result);
                    }
                    else
                    {
                        _connected = false;
                    }
                }

               
            }
            else
            {
                MessageBox.Show("Protocol Dll reference is invalid!");
            }
        }

        private void btn_disconnect_Click(object sender, EventArgs e)
        {
            if (_connected == true)
            {
                _connected = false;

                m_ProtocolDll.CloseSerialPort();
                lblComPortState.Text = "";

                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : SerialPort Disconnect";
                SetLogWriteLine(log);
            }
            else
            {
                MessageBox.Show("The COM Port is already disconnected.");
            }
        }

        /*  Protocol Response Print  ////////////////////////////////////////////////// */
        private void PrintReadyToWork(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

            if (recvData == 1)
                result += "[Protocol:12-02] ReadyToWork : TRUE";
            else
                result += "[Protocol:12-02] ReadyToWork : FALSE";

            SetLogWriteLine(result);
        }

        private void PrintGetUserName(byte[] userName)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-10] Get User Name : " + Encoding.ASCII.GetString(userName, 0, userName.Length);

            SetLogWriteLine(result);
        }

        private void PrintGetMachineWorkingState(byte workingState)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-11] Get Machine Working State : ";

            if (workingState == 1)
                result += "Counting";
            else if (workingState == 2)
                result += "Waiting";
            else if (workingState == 3)
                result += "Working";
            else if (workingState == 4)
                result += "Error";
            else
                result += "DT Error!";

            SetLogWriteLine(result);
        }

        private void PrintGetPocketState(byte[] pocketState)
        {
            // Data : 5 byte
            // Data[0] : Pocket 1 (TRUE/FALSE)
            // Data[1] : Pocket 2 (TRUE/FALSE)
            // Data[2] : Pocket 3 (TRUE/FALSE)
            // Data[3] : Reject (TRUE/FALSE)
            // Data[4] : Hopper (TRUE/FALSE)

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-12] Get Pocket State : ";

            if (pocketState.Length == 5)
            {
                result += "\r\n";

                if (_model == (int)Models.ST350)
                {
                    if (pocketState[0] == 1)
                        result += " - Pocket 1 = Exist \r\n";
                    else
                        result += " - Pocket 1 = Empty \r\n";

                    if (pocketState[1] == 1)
                        result += " - Pocket 2 = Exist \r\n";
                    else
                        result += " - Pocket 2 = Empty \r\n";

                    if (pocketState[2] == 1)
                        result += " - Pocket 3 = Exist \r\n";
                    else
                        result += " - Pocket 3 = Empty \r\n";

                    if (pocketState[3] == 1)
                        result += " - Reject = Exist \r\n";
                    else
                        result += " - Reject = Empty \r\n";

                    if (pocketState[4] == 1)
                        result += " - Hopper = Exist";
                    else
                        result += " - Hopper = Empty";
                }
                else // iH-110, ST-150N
                {
                    if (pocketState[0] == 1)
                        result += " - Pocket 1 = Exist \r\n";
                    else
                        result += " - Pocket 1 = Empty \r\n";

                    if (pocketState[3] == 1)
                        result += " - Reject = Exist \r\n";
                    else
                        result += " - Reject = Empty \r\n";

                    if (pocketState[4] == 1)
                        result += " - Hopper = Exist \r\n";
                    else
                        result += " - Hopper = Empty \r\n";
                }
            }
            else
            {
                result += "DTL Error!";
            }

            SetLogWriteLine(result);
        }

        private void PrintGetCountedResult(byte[] countResult)
        {
            // Data : Fitness Type(1Byte) + Denom Count(1Byte) + Count Data(int - 4Byte)
            // Fitness Type - ATM         = 1,  FIT         = 2,  UNFIT         = 3,  VALUE         = 4
            //                ATM OLD     = 11, FIT OLD     = 12, UNFIT OLD     = 13, VALUE OLD     = 14
            //                ATM NEW     = 21, FIT NEW     = 22, UNFIT NEW     = 23, VALUE NEW     = 24
            //                ATM VERYNEW = 31, FIT VERYNEW = 32, UNFIT VERYNEW = 33, VALUE VERYNEW = 34

            string fitnessType = string.Empty;

            if (countResult[0] == 1) fitnessType = "ATM";
            else if (countResult[0] == 2) fitnessType = "FIT";
            else if (countResult[0] == 3) fitnessType = "UNFIT";
            else if (countResult[0] == 4) fitnessType = "VALUE";
            else if (countResult[0] == 11) fitnessType = "ATM OLD";
            else if (countResult[0] == 12) fitnessType = "FIT OLD";
            else if (countResult[0] == 13) fitnessType = "UNFIT OLD";
            else if (countResult[0] == 14) fitnessType = "VALUE OLD";
            else if (countResult[0] == 21) fitnessType = "ATM NEW";
            else if (countResult[0] == 22) fitnessType = "FIT NEW";
            else if (countResult[0] == 23) fitnessType = "UNFIT NEW";
            else if (countResult[0] == 24) fitnessType = "VALUE NEW";
            else if (countResult[0] == 31) fitnessType = "ATM VERYNEW";
            else if (countResult[0] == 32) fitnessType = "FIT VERYNEW";
            else if (countResult[0] == 33) fitnessType = "UNFIT VERYNEW";
            else if (countResult[0] == 34) fitnessType = "VALUE VERYNEW";

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-13] Get Counted Result : \r\n";
            result += " - Fitness : " + fitnessType + "\r\n";


            int index = 2;
            int denomCount = countResult[1];
            byte[] countData = new byte[4];

            for (int i = 0; i < denomCount; i++)
            {
                Array.Copy(countResult, index, countData, 0, 4);
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(countData);

                result += " - [Denom " + (i + 1).ToString() + "] = " + BitConverter.ToInt32(countData, 0).ToString() + "\r\n";

                index += 4;
            }

            SetLogWriteLine(result);
        }

        private void PrintGetLocal(byte[] localData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-16] Get Local : ";

            if (localData.Length == 4)
            {
                result += Encoding.ASCII.GetString(localData, 1, 3);
            }
            else
            {
                result += "DTL Error!";
            }

            SetLogWriteLine(result);
        }

        private void PrintGetDenomInfo(byte[] denomInfo)
        {
            // Data : Use Point(1 byte) + Denom Count(1 byte) + Denom Data(4 byte)
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-17] Get Denom Info : \r\n";

            if (denomInfo[0] == 1)
                result += " - Use Point = TRUE \r\n";
            else
                result += " - Use Point = FALSE \r\n";

            int index = 2;
            int denomCount = denomInfo[1];
            byte[] denomData = new byte[4];

            for (int i = 0; i < denomCount; i++)
            {
                Array.Copy(denomInfo, index, denomData, 0, 4);
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(denomData);

                result += " - [Denom " + (i + 1).ToString() + "] = " + BitConverter.ToInt32(denomData, 0) + "\r\n";

                index += 4;
            }

            SetLogWriteLine(result);
        }

        private void PrintGetCountInformation(byte[] countInfo)
        {
            // [IH-110]/[ST-150N] Data (8 byte) : Fitness(1 byte) + Mode(1 byte) + Ver(1 byte) + Serial(1 byte) + Full Image(1 byte) + Dir(1 byte) + ADD(1 byte) + GT(1 byte)
            //  -Fitness    : 0 = Value, 1 = Fit, 2 = ATM
            //  -Mode       : 0 = Mix, 1 = SP, 2 = SG
            //  -Version    : 0 = Off, 1 = On
            //  -Serial     : 0 = Off, 1 = On
            //  -Full Image : 0 = Off, 1 = On
            //  -Dir        : 0 = Off, 1 = Face, 2 = ORG
            //  -ADD        : 0 = Off, 1 = On
            //  -GT         : 0 = Off, 1 = On

            // [ST-350] Data (5 byte) : ATM(1 byte) + FIT(1 byte) + ADD(1 byte) + GT(1 byte) + Mode(1 byte)
            //  -ATM  : TRUE / FALSE
            //  -FIT  : TRUE / FALSE
            //  -ADD  : TRUE / FALSE
            //  -GT   : TRUE / FALSE
            //  -Mode : 0 = Mix, 1 = Mix Ver, 2 = SP, 3 = SP Ver, 4 = SG, 5 = DIR_MF, 6 = DIR-MO, 7 = DIR-SF, 8 = DIR-SO, 9 = Serial

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

            if (_model == Models.IH110 || _model == Models.ST150N)
            {
                result += "[Protocol:12-18] Get Count Information : ";
                if (countInfo.Length == 8)
                {
                    result += "\r\n";

                    if (countInfo[0] == 0) result += " - Fitness : Value \r\n";
                    else if (countInfo[0] == 1) result += " - Fitness : FIT \r\n";
                    else if (countInfo[0] == 2) result += " - Fitness : ATM \r\n";

                    if (countInfo[1] == 0) result += " - Mode : Mix \r\n";
                    else if (countInfo[1] == 1) result += " - Mode : SP \r\n";
                    else if (countInfo[1] == 2) result += " - Mode : SG \r\n";

                    if (countInfo[2] == 0) result += " - Version : Off \r\n";
                    else if (countInfo[2] == 1) result += " - Version : On \r\n";

                    if (countInfo[3] == 0) result += " - Serial : Off \r\n";
                    else if (countInfo[3] == 1) result += " - Serial : On \r\n";

                    if (countInfo[4] == 0) result += " - Full Image : Off \r\n";
                    else if (countInfo[4] == 1) result += " - Full Image : On \r\n";

                    if (countInfo[5] == 0) result += " - Dir : Off \r\n";
                    else if (countInfo[5] == 1) result += " - Dir : Face \r\n";
                    else if (countInfo[5] == 2) result += " - Dir : ORG \r\n";

                    if (countInfo[6] == 0) result += " - ADD : Off \r\n";
                    else if (countInfo[6] == 1) result += " - ADD : On \r\n";

                    if (countInfo[7] == 0) result += " - GT : Off \r\n";
                    else if (countInfo[7] == 1) result += " - GT : On \r\n";
                }
                else
                {
                    result += "DTL Error! \r\n";
                }
            }
            else if (_model == (int)Models.ST350)
            {
                result += "[Protocol:12-18] Get Count Information : ";
                if (countInfo.Length == 5)
                {
                    result += "\r\n";

                    if (countInfo[0] == 0) result += " - ATM : FALSE \r\n";
                    else if (countInfo[0] == 1) result += " - ATM : TRUE \r\n";

                    if (countInfo[1] == 0) result += " - FIT : FALSE \r\n";
                    else if (countInfo[1] == 1) result += " - FIT : TRUE \r\n";

                    if (countInfo[2] == 0) result += " - ADD : FALSE \r\n";
                    else if (countInfo[2] == 1) result += " - ADD : TRUE \r\n";

                    if (countInfo[3] == 0) result += " - GT : FALSE \r\n";
                    else if (countInfo[3] == 1) result += " - GT : TRUE \r\n";

                    if (countInfo[4] == 0) result += " - Mode : Mix \r\n";
                    else if (countInfo[4] == 1) result += " - Mode : Mix Ver \r\n";
                    else if (countInfo[4] == 2) result += " - Mode : SP \r\n";
                    else if (countInfo[4] == 3) result += " - Mode : SP Ver \r\n";
                    else if (countInfo[4] == 4) result += " - Mode : SG \r\n";
                    else if (countInfo[4] == 5) result += " - Mode : DIR-MF \r\n";
                    else if (countInfo[4] == 6) result += " - Mode : DIR-MO \r\n";
                    else if (countInfo[4] == 7) result += " - Mode : DIR-SF \r\n";
                    else if (countInfo[4] == 8) result += " - Mode : DIR-SO \r\n";
                    else if (countInfo[4] == 9) result += " - Mode : Serial \r\n";
                }
                else
                {
                    result += "DTL Error!";
                }
            }

            SetLogWriteLine(result);
        }

        private void PrintGetMachineSN(byte[] machineSN)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-19] Get Machine Serial Number : " + Encoding.ASCII.GetString(machineSN);

            _strMachineSN = Encoding.ASCII.GetString(machineSN);

            _upgradeForm.SetSNHandle();

            SetLogWriteLine(result);
        }

        private void PrintGetProduct(byte product)
        {
            // [iH-110] Product : 1 = SEETECH, 2 = MAGNER, 3 = HITACHI
            // [ST-150N, ST-350] Product
            //  - 1 = Seetech   2 = Magner   3 = Magner
            //  - 4 = Seetech   5 = RongHe   6 = Seetech
            //  - 7 = Seetech

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-20] Get Product : ";

            if (_model == Models.ST150N || _model == (int)Models.ST350)
            {
                if (product == 1) result += "SEETECH";
                else if (product == 2) result += "MAGNER";
                else if (product == 3) result += "MAGNER";
                else if (product == 4) result += "SEETECH";
                else if (product == 5) result += "RONGHE";
                else if (product == 6) result += "SEETECH";
                else if (product == 7) result += "SEETECH";
                else result += "Product Error!";
            }
            else if (_model == Models.IH110)
            {
                if (product == 1) result += "SEETECH";
                else if (product == 2) result += "MAGNER";
                else if (product == 3) result += "HITACHI";
                else result += "Product Error!";
            }

            SetLogWriteLine(result);
        }

        private void PrintGetSeries(byte series)
        {
            // [ST-150N, ST-350] Series
            // 1 = 350           2 = 300     3 = 350N     4 = 300N       5 = 350
            // 6 = 300          10 = BDM    11 = 150NV   12 = 150NF     13 = 175V
            // 14 = 175FF       15 = 175F   16 = 150F    17 = DualCIS   18 = DualCISF
            // 19 = 150NV       21 = 150    22 = 150F    23 = 175       24 = 175F
            // 25 = iHunter2.0

            // [IH-110] Series
            // 1 = IH-110   2 = IH-110S   3 = IH-110B
            // 4 = IH-110F	5 = IH-110FS  6 = IH-110FB

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-21] Get Series : ";

            
            if (_model == Models.IH110)
            {
                if (series == 1) result += "iH-110";
                else if (series == 2) result += "iH-110S";
                else if (series == 3) result += "iH-110B";
                else if (series == 4) result += "IH-110F";
                else if (series == 5) result += "iH-110FS";
                else if (series == 6) result += "iH-110FB";
            }
            else if (_model == Models.ST150N || _model == (int)Models.ST350)
            {
                if (series == 1) result += "350";
                else if (series == 2) result += "300";
                else if (series == 3) result += "350N";
                else if (series == 4) result += "300N";
                else if (series == 5) result += "350";
                else if (series == 6) result += "300";
                else if (series == 10) result += "BDM";
                else if (series == 11) result += "150NV";
                else if (series == 12) result += "150NF";
                else if (series == 13) result += "175V";
                else if (series == 14) result += "175FF";
                else if (series == 15) result += "175F";
                else if (series == 16) result += "150F";
                else if (series == 17) result += "DualCIS";
                else if (series == 18) result += "DualCISF";
                else if (series == 19) result += "150NV";
                else if (series == 21) result += "150";
                else if (series == 22) result += "150F";
                else if (series == 23) result += "175";
                else if (series == 24) result += "175F";
                else if (series == 25) result += "iHunter2.0";
            }

            SetLogWriteLine(result);
        }

        private void PrintGetAppVersion(byte[] appVersion)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

            result += string.Format("[Protocol:12-22] Get App Version : 20{0}.{1}.{2}, {3}-{4}-{5}.{6}.{7}", appVersion[0], appVersion[1].ToString("D2"), appVersion[2].ToString("D2"), Convert.ToChar(appVersion[3]), Convert.ToChar(appVersion[4]), appVersion[5], appVersion[6], appVersion[7]);

            SetLogWriteLine(result);
        }

        private void PrintSetMode(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

            if (recvData == 1)
                result += "[Protocol:12-33] SetMode : TRUE";
            else
                result += "[Protocol:12-33] SetMode : FALSE";

            SetLogWriteLine(result);
        }

        private void PrintGetMachineState(byte[] MachineState)
        {
            // Data (9 byte) : 
            // Data[0] = Working(1 byte) : 1 = Counting, 2 = Wait, 3 = Working
            // Data[1] = Enable P1(1 byte)
            // Data[2] = Enable P2(1 byte)
            // Data[3] = Enable P3(1 byte)
            // Data[4] = Enable RJ(1 byte)
            // Data[5] = Enable Hopper(1 byte)
            // Data[6] = Show JAM(1 byte)
            // Data[7] = Show Cover Open(1 byte)
            // Data[8] = Show Remove(1 byte)

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-40] Get Machine State : ";

            if (MachineState.Length == 9)
            {
                result += "\r\n";

                if (_model == Models.IH110 || _model == Models.ST150N)
                {
                    // Working
                    if (MachineState[0] == 1) result += " - Working : Counting \r\n";
                    else if (MachineState[0] == 2) result += " - Working : Wait \r\n";
                    else if (MachineState[0] == 3) result += " - Working : Working \r\n";
                    else if (MachineState[0] == 4) result += " - Working : Error \r\n";
                    else result += " - Working : Unknown \r\n";

                    // Enable P1
                    if (MachineState[1] == 1) result += " - Enable P1 : TRUE \r\n";
                    else result += " - Enable P1 : FALSE \r\n";

                    // Enable RJ
                    if (MachineState[4] == 1) result += " - Enable Reject : TRUE \r\n";
                    else result += " - Enable Reject : FALSE \r\n";

                    // Enable Hopper
                    if (MachineState[5] == 1) result += " - Enable Hopper : TRUE \r\n";
                    else result += " - Enable Hopper : FALSE \r\n";

                    // Show JAM
                    if (MachineState[6] == 1) result += " - Show JAM : TRUE \r\n";
                    else result += " - Show JAM : FALSE \r\n";

                    // Show Cover Open
                    if (MachineState[7] == 1) result += " - Show Cover Open : TRUE \r\n";
                    else result += " - Show Cover Open : FALSE \r\n";

                    // Show Remove
                    if (MachineState[8] == 1) result += " - Show Remove : TRUE \r\n";
                    else result += " - Show Remove : FALSE \r\n";
                }
                else if (_model == (int)Models.ST350)
                {
                    // Working
                    if (MachineState[0] == 1) result += " - Working : Counting \r\n";
                    else if (MachineState[0] == 2) result += " - Working : Wait \r\n";
                    else if (MachineState[0] == 3) result += " - Working : Working \r\n";

                    // Enable P1
                    if (MachineState[1] == 1) result += " - Enable P1 : TRUE \r\n";
                    else result += " - Enable P1 : FALSE \r\n";

                    // Enable P2
                    if (MachineState[2] == 1) result += " - Enable P2 : TRUE \r\n";
                    else result += " - Enable P2 : FALSE \r\n";

                    // Enable P3
                    if (MachineState[3] == 1) result += " - Enable P3 : TRUE \r\n";
                    else result += " - Enable P3 : FALSE \r\n";

                    // Enable RJ
                    if (MachineState[4] == 1) result += " - Enable Reject : TRUE \r\n";
                    else result += " - Enable Reject : FALSE \r\n";

                    // Enable Hopper
                    if (MachineState[5] == 1) result += " - Enable Hopper : TRUE \r\n";
                    else result += " - Enable Hopper : FALSE \r\n";

                    // Show JAM
                    if (MachineState[6] == 1) result += " - Show JAM : TRUE \r\n";
                    else result += " - Show JAM : FALSE \r\n";

                    // Show Cover Open
                    if (MachineState[7] == 1) result += " - Show Cover Open : TRUE \r\n";
                    else result += " - Show Cover Open : FALSE \r\n";

                    // Show Remove
                    if (MachineState[8] == 1) result += " - Show Remove : TRUE \r\n";
                    else result += " - Show Remove : FALSE \r\n";
                }
            }
            else
            {
                result += "DTL Error!";
            }

            SetLogWriteLine(result);
        }

        private void PrintGetResultCode(byte[] resultCode)
        {
            // Data : Data Count(1 byte) + Result Code[Hi Code + Low Code]
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-41] Get Result Code : ";

            int dataCount = resultCode[0];
            if (dataCount > 0)
            {
                result += "\r\n";

                int index = 1;
                for (int i = 0; i < dataCount; i++)
                {
                    result += " - [Hi Code] = " + resultCode[index++] + ", [Low Code] = " + resultCode[index++] + "\r\n";
                }
            }
            else
            {
                result += "Data Empty!";
            }

            SetLogWriteLine(result);
        }

        private void PrintInformStartStop(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-50] Inform Start/Stop : ";

            if (recvData == 1)
                result += "TRUE";
            else
                result += "FALSE";

            SetLogWriteLine(result);
        }

        private void PrintGetPocketResult(byte[] pocketResult)
        {
            // Data     : Pocket No(1 byte) + Data Count(1 byte) + Data[Count(2 byte)...Count(2 byte)]
            // PocketNo : 1~100 (P1, P2, P3 ... P100)

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

            if (pocketResult.Length > 2)
            {
                result += "[Protocol:12-60] Get Pocket Result : \r\n";

                // DT[0] = Pocket No
                if (pocketResult[0] <= 100)
                    result += " - Pocket " + pocketResult[0].ToString() + "\r\n";
                else
                    result += " - None \r\n";

                int index = 2;
                int dataCount = pocketResult[1]; // DT[1] = Data Count
                byte[] data = new byte[2];

                for (int i = 0; i < dataCount; i++)
                {
                    Array.Copy(pocketResult, index, data, 0, 2);
                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(data);

                    result += " - [Denom " + i.ToString() + "] = " + BitConverter.ToInt16(data, 0).ToString() + "\r\n";

                    index += 2;
                }
            }
            else
            {
                result += "[Protocol:12-60] Get Pocket Result : DTL Error!";
            }

            SetLogWriteLine(result);
        }

        private void PrintGetBatch(byte[] batchData)
        {
            // Data : Data Count(1Byte) + Data { data_1[PocketNo(1Byte) + Batch(2Byte)], data_2[], data_3[] ... data_DataCount }
            // PocketNo : 1~100 (P1, P2, P3 ... P100) / 101~200 (Reject1, Reject2, Reject3 ... Reject100)

            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-61] Get Batch : ";

            if (batchData.Length > 1)
            {
                result += "\r\n";

                int index = 1;
                int pocketNo = 0;
                byte[] batch = new byte[2];

                // DT[0] : Data Count
                int dataCount = batchData[0];
                for (int i = 0; i < dataCount; i++)
                {
                    pocketNo = batchData[index++];
                    Array.Copy(batchData, index, batch, 0, 2);

                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(batch);

                    if (pocketNo > 100) // Reject
                    {
                        pocketNo = pocketNo % 100;
                        result += " - Reject " + pocketNo.ToString() + " Batch : " + BitConverter.ToInt16(batch, 0).ToString() + "\r\n";
                    }
                    else
                    {
                        result += " - Pocket " + pocketNo.ToString() + " Batch : " + BitConverter.ToInt16(batch, 0).ToString() + "\r\n";
                    }

                    index += 2;
                }
            }
            else
            {
                result += "DTL Error!";
            }

            SetLogWriteLine(result);
        }

        private void PrintSetBatch(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-62] Set Batch : ";

            if (recvData == 1)
                result += "Success";
            else
                result += "Fail";

            SetLogWriteLine(result);
        }

        private void PrintSetBatchPresetMode(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-63] Set Batch Preset Mode : ";

            if (recvData == 1)
                result += "Success";
            else
                result += "Fail";

            SetLogWriteLine(result);
        }

        private void PrintSetCountingMode(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-64] Set Counting Mode : ";

            if (recvData == 1)
                result += "Success";
            else
                result += "Fail";

            SetLogWriteLine(result);
        }

        private void PrintSetAddMode(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-65] Set Add Mode : ";

            if (recvData == 1)
                result += "Success";
            else
                result += "Fail";

            SetLogWriteLine(result);
        }

        private void PrintSetBatchFunction(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-66] Set Batch Function : ";

            if (recvData == 1)
                result += "Success";
            else
                result += "Fail";

            SetLogWriteLine(result);
        }

        private void PrintGetCountingFinishNew(byte[] recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-73] Counting Finish New";
            SetLogWriteLine(result);

            result = "";
            
            if (recvData.Length > 1)
            {
                // 전송 타입
                bool bGTotal = false;
                bool bCoupon = false;
                bool bSNImage = false;
                byte ucType1 = recvData[0];
                byte ucType2 = recvData[1];
                if (ucType2 != 0)
                {
                    byte ucBit = 1;
                    if (Convert.ToBoolean(ucType2 & ucBit))
                    {
                        bSNImage = true;
                        result += " - SN Image counting";
                    }

                    ucBit = Convert.ToByte(ucBit << 1);
                    if (Convert.ToBoolean(ucType2 & ucBit))
                    {
                        result += " - Full Image counting";
                    }

                    ucBit = Convert.ToByte(ucBit << 1);
                    if (Convert.ToBoolean(ucType2 & ucBit))
                    {
                        bCoupon = true;
                        result += " - Coupon counting";
                    }
                }
                else
                {
                    bGTotal = true;
                    result = " - Normal counting";
                }
                SetLogWriteLine(result);


                // Local Count 분리
                _localIndex = 0;
                _localCount = recvData[2];
                result = " - Local Count : " + _localCount.ToString();
                SetLogWriteLine(result);
                result = "";

                // Bank, Branch, Teller 분리
                int nInfoLen = recvData[3];
                byte[] ucInfo = new byte[nInfoLen];
                Array.Copy(recvData, 4, ucInfo, 0, nInfoLen);

                // ASCII TO Unicode
                string strInfo = Encoding.Unicode.GetString(ucInfo, 0, nInfoLen);
                char[] sep = { '|' };

                // Info 분리
                string[] strSplit = strInfo.Split(sep);
                foreach (var item in strSplit)
                {
                    if (item[0] == 'B')
                    {
                        result = " - Bank Name : " + item.Substring(1);
                    }
                    if (item[0] == 'R')
                    {
                        result = " - Branch Name : " + item.Substring(1);
                    }
                    if (item[0] == 'T')
                    {
                        result = " - Teller Name : " + item.Substring(1);
                    }
                    SetLogWriteLine(result);
                }

                // 전달받은 Type에 따라 정보를 요청한다.
                if (bGTotal)
                {
                    GetNewLocalInfo();
                }
                if (bCoupon && !bSNImage)
                {
                    m_ProtocolDll.PrtcGetCouponInfo();
                }
            }
            else
            {
                result += "DTL Error! \r\n";

                SetLogWriteLine(result);
            }
        }

        private void PrintLocalGtotalInfo()
        {
            string result = string.Empty;

            uint DenomTotal = 0;
            uint TotalCount = 0;
            double TotalAmount = 0;
            
            for (int i = 0; i < _gtotalInfo.DenomCount; i++)
            {
                if (_gtotalInfo.UseAtm == 1)
                {
                    DenomTotal += _gtotalInfo.AtmCount[i] + _gtotalInfo.AtmCount[10 + i] + _gtotalInfo.AtmCount[20 + i];
                }
                if (_gtotalInfo.UseFit == 1)
                {
                    DenomTotal += _gtotalInfo.FitCount[i] + _gtotalInfo.FitCount[10 + i] + _gtotalInfo.FitCount[20 + i];
                }
                if (_gtotalInfo.UseUnfit == 1)
                {
                    DenomTotal += _gtotalInfo.UnfitCount[i] + _gtotalInfo.UnfitCount[10 + i] + _gtotalInfo.UnfitCount[20 + i];
                }
                if (_gtotalInfo.UseValue == 1)
                {
                    DenomTotal += _gtotalInfo.ValueCount[i] + _gtotalInfo.ValueCount[10 + i] + _gtotalInfo.ValueCount[20 + i];
                }
                if (_gtotalInfo.UseManual == 1)
                {
                    DenomTotal += _gtotalInfo.ManualCount[i] + _gtotalInfo.ManualCount[10 + i] + _gtotalInfo.ManualCount[20 + i];
                }

                result += " - Denom[" + i.ToString() + " = " + _gtotalInfo.DenomData[i].ToString() + "] : " + DenomTotal.ToString() + "\r\n";

                TotalCount += DenomTotal;
                TotalAmount += DenomTotal * _gtotalInfo.DenomData[i];
                DenomTotal = 0;
            }

            if (_gtotalInfo.UseReject == 1)
            {
                // Reject Count
                TotalCount += _gtotalInfo.RejectCount;
                result += " - Reject Count : " + _gtotalInfo.RejectCount.ToString() + "\r\n";
            }

            // Total Count
            result += " - Total Count : " + TotalCount.ToString() + "\r\n";
            result += " - Total Amount : " + TotalAmount.ToString() + "\r\n";


            SetLogWriteLine(result);             

            // Request Next Local
            _localIndex++;
            GetNewLocalInfo();
        }

        private void PrintGetCouponInfo(byte[] recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : [Protocol:12-82] Get Coupon Info : ";
            SetLogWriteLine(result);

            int nPos = 0;
            int denomCount = recvData[nPos++];

            for (int i = 0; i < denomCount; i++)
            {
                // Denom에서 소수점을 사용하는지 확인한다.
                bool usePoint = Convert.ToBoolean(recvData[nPos++]);

                // Denom 정보를 받는다.
                UInt32 nDenom = 0;
                nDenom = (UInt32)recvData[nPos++] << 24;
                nDenom |= (UInt32)recvData[nPos++] << 16;
                nDenom |= (UInt32)recvData[nPos++] << 8;
                nDenom |= (UInt32)recvData[nPos++];

                // 소수점 사용 여부에 따라 Denom 정보를 다시 저장한다.
                double fDenom = 0;
                if (usePoint == true)
                {
                    fDenom = (double)nDenom / 100;
                }
                else
                {
                    fDenom = (double)nDenom;
                }

                // Denom의 Count 정보를 받는다.
                UInt32 nCount = 0;
                nCount = (UInt32)recvData[nPos++] << 24;
                nCount |= (UInt32)recvData[nPos++] << 16;
                nCount |= (UInt32)recvData[nPos++] << 8;
                nCount |= (UInt32)recvData[nPos++];

                // Value를 계산한다.
                double value = fDenom * nCount;

                // [Denom : 5.5], [Count : 11], [Value : 60.5]
                result = "[Denom : " + fDenom.ToString() + "], [Count : " + nCount.ToString() + "], [Value : " + value.ToString() + "]";
                SetLogWriteLine(result);
            }
        }
        


        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_recvData_ascii.Text = string.Empty;
        }

        private void btnServerStart_Click(object sender, EventArgs e)
        {
            if (_connected == true)
            {
                if (_serverStart == true)
                {
                    MessageBox.Show("The Lan server is already connected.");
                }
                else
                {
                    MessageBox.Show("The COM Port is already connected.");
                }
                return;
            }

            string strServerPort = txtServerPort.Text;
            if (string.IsNullOrEmpty(strServerPort))
            {
                MessageBox.Show("Server port empty!");
                return;
            }

            if (Protocol.CheckDll())
            {
                _serverStart = true;

                //m_ProtocolDll.SetHandle(this.Handle);

                m_ProtocolDll.LanStart(Convert.ToInt32(strServerPort));
                lblServerState.Text = "State : Server Start";

                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : Server Start";
                SetLogWriteLine(log);
            }
            else
            {
                MessageBox.Show("Protocol Dll reference is invalid!");
            }
        }

        private void btnServerStop_Click(object sender, EventArgs e)
        {
            if (_serverStart == true)
            {
                _serverStart = false;
                _connected = false;

                m_ProtocolDll.LanStop();
                lblServerState.Text = "";

                string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : Server Stop";
                SetLogWriteLine(log);
            }
            else
            {
                MessageBox.Show("The Lan server is already stop.");
            }
        }

        private void btn_upgrade_Click(object sender, EventArgs e)
        {
            // 연결된 상태가 아니라면 종료
            if (_connected == false)
                return;

            if (tabProtocol.SelectedIndex == 0) // IH-110
            {
                _model = Models.IH110;
            }
            else if (tabProtocol.SelectedIndex == 1) // ST-150N
            {
                _model = Models.ST150N;
            }
            else if (tabProtocol.SelectedIndex == 2) // ST-350
            {
                _model = Models.ST350;
            }

            _upgradeForm.RefreshCtrl();
            _upgradeForm.ShowDialog();
        }

        public void ClearConnection()
        {
            _connected = false;
            string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            if (_serverStart == true)
            {
                _serverStart = false;

                this.Invoke(new MethodInvoker(delegate ()
                {
                    m_ProtocolDll.LanStop();
                    lblServerState.Text = "";
                }));
                log += "Server Stop";
            }
            else
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    m_ProtocolDll.CloseSerialPort();
                    lblComPortState.Text = "";
                }));
                log += "SerialPort Disconnect";
            }
            SetLogWriteLine(log);
        }

        private void btn_sni_Click(object sender, EventArgs e)
        {
            _snviewerForm.ShowDialog();
        }

        private void btn_setLocalDenom_Click(object sender, EventArgs e)
        {
            _setLocalDenomForm.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_ProtocolDll.CloseDll();

            this.m_bThreadStop = true;
            this.m_queWmCopyData.Clear();
            this.m_threadWmCopyData.Join();
        }

        /*  Protocol  //////////////////////////////////////////////////////  */
        private void btnReadyToWork_Click(object sender, EventArgs e)
        {
            // [12-02] Ready To Work (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcReadyToWork();
        }

        private void btnReadyToWorkST150N_Click(object sender, EventArgs e)
        {
            // [12-02] Ready To Work (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcReadyToWork();
        }

        private void btnReadyToWorkST350_Click(object sender, EventArgs e)
        {
            // [12-02] Ready To Work (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcReadyToWork();
        }

        private void btnGetUserName_Click(object sender, EventArgs e)
        {
            // [12-10] Get User Name (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetUserName();
        }

        private void btnGetUserNameST150N_Click(object sender, EventArgs e)
        {
            // [12-10] Get User Name (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetUserName();
        }

        private void btnGetUserNameST350_Click(object sender, EventArgs e)
        {
            // [12-10] Get User Name (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetUserName();
        }

        private void btnGetMACWorkingState_Click(object sender, EventArgs e)
        {
            // [12-11] Get Machine Working State (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineWorkingState();
        }

        private void btnGetMACWorkingStateST150N_Click(object sender, EventArgs e)
        {
            // [12-11] Get Machine Working State (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineWorkingState();
        }

        private void btnGetMACWorkingStateST350_Click(object sender, EventArgs e)
        {
            // [12-11] Get Machine Working State (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineWorkingState();
        }

        private void btnGetPocketState_Click(object sender, EventArgs e)
        {
            // [12-12] Get Pocket State (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetPocketState();
        }

        private void btnGetPocketStateST150N_Click(object sender, EventArgs e)
        {
            // [12-12] Get Pocket State (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetPocketState();
        }

        private void btnGetPocketStateST350_Click(object sender, EventArgs e)
        {
            // [12-12] Get Pocket State (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetPocketState();
        }

        private void btnGetCountedResult_Click(object sender, EventArgs e)
        {
            // [12-13] Get Counted Result (iH-110) 
            // PARAM -  1 = ATM           2 = FIT           3 = UNFIT           4 = VALUE
            //         11 = ATM OLD      12 = FIT OLD      13 = UNFIT OLD      14 = VALUE OLD
            //         21 = ATM NEW      22 = FIT NEW      23 = UNFIT NEW      24 = VALUE NEW
            //         31 = ATM VERYNEW  32 = FIT VERYNEW  33 = UNFIT VERYNEW  34 = VALUE VERYNEW

            _model = Models.IH110;


            if (txtParam.Text != "1" && txtParam.Text != "2" && txtParam.Text != "3" && txtParam.Text != "4" &&
                txtParam.Text != "11" && txtParam.Text != "12" && txtParam.Text != "13" && txtParam.Text != "14" &&
                txtParam.Text != "21" && txtParam.Text != "22" && txtParam.Text != "23" && txtParam.Text != "24" &&
                txtParam.Text != "31" && txtParam.Text != "32" && txtParam.Text != "33" && txtParam.Text != "34")
            {
                // PARAM Default = VALUE(4)
                txtParam.Text = "4";
            }


            m_ProtocolDll.PrtcGetCountedResult(Convert.ToInt32(txtParam.Text));
        }

        private void btnGetCountedResultST150N_Click(object sender, EventArgs e)
        {
            // [12-13] Get Counted Result (ST-150N)
            // PARAM -  1 = ATM           2 = FIT           3 = UNFIT           4 = VALUE
            //         11 = ATM OLD      12 = FIT OLD      13 = UNFIT OLD      14 = VALUE OLD
            //         21 = ATM NEW      22 = FIT NEW      23 = UNFIT NEW      24 = VALUE NEW
            //         31 = ATM VERYNEW  32 = FIT VERYNEW  33 = UNFIT VERYNEW  34 = VALUE VERYNEW

            _model = Models.ST150N;


            if (txtParamST150N.Text != "1" && txtParamST150N.Text != "2" && txtParamST150N.Text != "3" && txtParamST150N.Text != "4" &&
                txtParamST150N.Text != "11" && txtParamST150N.Text != "12" && txtParamST150N.Text != "13" && txtParamST150N.Text != "14" &&
                txtParamST150N.Text != "21" && txtParamST150N.Text != "22" && txtParamST150N.Text != "23" && txtParamST150N.Text != "24" &&
                txtParamST150N.Text != "31" && txtParamST150N.Text != "32" && txtParamST150N.Text != "33" && txtParamST150N.Text != "34")
            {
                // PARAM Default = VALUE(4)
                txtParamST150N.Text = "4";
            }


            m_ProtocolDll.PrtcGetCountedResult(Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnGetCountedResultST350_Click(object sender, EventArgs e)
        {
            // [12-13] Get Counted Result (ST-350)
            // PARAM -  1 = ATM           2 = FIT           3 = UNFIT           4 = VALUE
            //         11 = ATM OLD      12 = FIT OLD      13 = UNFIT OLD      14 = VALUE OLD
            //         21 = ATM NEW      22 = FIT NEW      23 = UNFIT NEW      24 = VALUE NEW
            //         31 = ATM VERYNEW  32 = FIT VERYNEW  33 = UNFIT VERYNEW  34 = VALUE VERYNEW

            _model = Models.ST350;


            if (txtParamST350.Text != "1" && txtParamST350.Text != "2" && txtParamST350.Text != "3" && txtParamST350.Text != "4" &&
                txtParamST350.Text != "11" && txtParamST350.Text != "12" && txtParamST350.Text != "13" && txtParamST350.Text != "14" &&
                txtParamST350.Text != "21" && txtParamST350.Text != "22" && txtParamST350.Text != "23" && txtParamST350.Text != "24" &&
                txtParamST350.Text != "31" && txtParamST350.Text != "32" && txtParamST350.Text != "33" && txtParamST350.Text != "34")
            {
                // PARAM Default = VALUE(4)
                txtParamST350.Text = "4";
            }


            m_ProtocolDll.PrtcGetCountedResult(Convert.ToInt32(txtParamST350.Text));
        }

        private void btnGetLocal_Click(object sender, EventArgs e)
        {
            // [12-16] Get Local (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetLocal();
        }

        private void btnGetLocalST150N_Click(object sender, EventArgs e)
        {
            // [12-16] Get Local (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetLocal();
        }

        private void btnGetLocalST350_Click(object sender, EventArgs e)
        {
            // [12-16] Get Local (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetLocal();
        }

        private void btnGetDenomInfo_Click(object sender, EventArgs e)
        {
            // [12-17] Get Denom Info (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetDenomInfo();
        }

        private void btnGetDenomInfoST150N_Click(object sender, EventArgs e)
        {
            // [12-17] Get Denom Info (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetDenomInfo();
        }

        private void btnGetDnomInfoST350_Click(object sender, EventArgs e)
        {
            // [12-17] Get Denom Info (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetDenomInfo();
        }

        private void btnGetCountInfo_Click(object sender, EventArgs e)
        {
            // [12-18] Get Count Information (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetCountInformation();
        }

        private void btnGetCountInfoST150N_Click(object sender, EventArgs e)
        {
            // [12-18] Get Count Information (iH-110)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetCountInformation();
        }

        private void btnGetCountInfoST350_Click(object sender, EventArgs e)
        {
            // [12-18] Get Count Information (iH-110)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetCountInformation();
        }

        private void btnGetMachineSN_Click(object sender, EventArgs e)
        {
            // [12-19] Get Machine Serial Number (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineSN();
        }

        private void btnGetMachineSNST150N_Click(object sender, EventArgs e)
        {
            // [12-19] Get Machine Serial Number (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineSN();
        }

        private void btnGetMachineSNST350_Click(object sender, EventArgs e)
        {
            // [12-19] Get Machine Serial Number (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineSN();
        }

        private void btnGetProduct_Click(object sender, EventArgs e)
        {
            // [12-20] Get Product (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetProduct();
        }

        private void btnGetProductST150N_Click(object sender, EventArgs e)
        {
            // [12-20] Get Product (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetProduct();
        }

        private void btnGetProductST350_Click(object sender, EventArgs e)
        {
            // [12-20] Get Product (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetProduct();
        }

        private void btnGetSeries_Click(object sender, EventArgs e)
        {
            // [12-21] Get Series (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetSeries();
        }

        private void btnGetSeriesST150N_Click(object sender, EventArgs e)
        {
            // [12-21] Get Series (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetSeries();
        }

        private void btnGetSeriesST350_Click(object sender, EventArgs e)
        {
            // [12-21] Get Series (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetSeries();
        }

        private void btnSetMode_Click(object sender, EventArgs e)
        {
            // [12-33] Set Mode (iH-110)
            // PARAM - MIX = 0    SP = 1    SG = 2
            _model = Models.IH110;

            // PARAM Default
            if (txtParam.Text == string.Empty)
                txtParam.Text = "0";

            if (txtParam.Text != "0" && txtParam.Text != "1" && txtParam.Text == "2")
            {
                // PARAM Default = MIX(0)
                txtParam.Text = "0";
            }


            m_ProtocolDll.PrtcSetMode(Convert.ToByte(txtParam.Text));
        }

        private void btnGetMachineState_Click(object sender, EventArgs e)
        {
            // [12-40] Get Machine State (ST-150N)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineState();
        }
        
        private void btnGetMachineStateST150N_Click(object sender, EventArgs e)
        {
            // [12-40] Get Machine State (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineState();
        }

        private void btnGetMachineStateST350_Click(object sender, EventArgs e)
        {
            // [12-40] Get Machine State (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineState();
        }

        private void btnGetResultCodeST150N_Click(object sender, EventArgs e)
        {
            // [12-41] Get Result Code (ST-150N)
            // PARAM - 1 = Unfit, 2 = Reject
            _model = Models.ST150N;


            if (txtParamST150N.Text != "1" && txtParamST150N.Text != "2")
            {
                // PARAM Default = Reject(2)
                txtParamST150N.Text = "2";
            }


            m_ProtocolDll.PrtcGetResultCode(Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnGetResultCodeST350_Click(object sender, EventArgs e)
        {
            // [12-41] Get Result Code (ST-350)
            // PARAM - 1 = Unfit, 2 = Reject
            _model = Models.ST350;


            if (txtParamST350.Text != "1" && txtParamST350.Text != "2")
            {
                // PARAM Default = Reject(2)
                txtParamST350.Text = "2";
            }


            m_ProtocolDll.PrtcGetResultCode(Convert.ToInt32(txtParamST350.Text));
        }

        private void btnInformStartStop_Click(object sender, EventArgs e)
        {
            // [12-50] Inform Start / Stop (iH-110)
            // PARAM - 0 = Start, 1 = Stop, 2 = Clear
            _model = Models.IH110;


            if (txtParam.Text != "0" && txtParam.Text != "1" && txtParam.Text != "2")
            {
                // PARAM Default = Start(0)
                txtParam.Text = "0";
            }


            m_ProtocolDll.PrtcInformStartStop(Convert.ToInt32(txtParam.Text));
        }

        private void btnInformStartStopST150N_Click(object sender, EventArgs e)
        {
            // [12-50] Inform Start / Stop (ST-150N)
            // PARAM - 0 = Start, 1 = Stop, 2 = Clear
            _model = Models.ST150N;


            if (txtParamST150N.Text != "0" && txtParamST150N.Text != "1" && txtParamST150N.Text != "2")
            {
                // PARAM Default = Start(0)
                txtParamST150N.Text = "0";
            }


            m_ProtocolDll.PrtcInformStartStop(Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnInformStartStopST350_Click(object sender, EventArgs e)
        {
            // [12-50] Inform Start / Stop (ST-350)
            // PARAM - 0 = Start, 1 = Stop, 2 = Clear
            _model = Models.ST350;


            if (txtParamST350.Text != "0" && txtParamST350.Text != "1" && txtParamST350.Text != "2")
            {
                // PARAM Default = Start(0)
                txtParamST350.Text = "0";
            }


            m_ProtocolDll.PrtcInformStartStop(Convert.ToInt32(txtParamST350.Text));
        }

        private void btnGetPocketResultST150N_Click(object sender, EventArgs e)
        {
            // [12-60] Get Pocket Result (ST-150N)
            // PARAM1 - Pocket No
            // PARAM2 -  1 = ATM,          2 = FIT,          3 = UNFIT,          4 = VALUE
            //          11 = ATM OLD,     12 = FIT OLD,     13 = UNFIT OLD,     14 = VALUE OLD
            //          21 = ATM NEW,     22 = FIT NEW,     23 = UNFIT NEW,     24 = VALUE NEW
            //          31 = ATM VERYNEW, 32 = FIT VERYNEW, 33 = UNFIT VERYNEW, 34 = VALUE VERYNEW
            _model = Models.ST150N;


            if (txtParamST150N.Text != "1" && txtParamST150N.Text != "2" && txtParamST150N.Text != "3" && txtParamST150N.Text != "4" ||
                txtParamST150N.Text != "11" && txtParamST150N.Text != "12" && txtParamST150N.Text != "13" && txtParamST150N.Text != "14" ||
                txtParamST150N.Text != "21" && txtParamST150N.Text != "22" && txtParamST150N.Text != "23" && txtParamST150N.Text != "24" ||
                txtParamST150N.Text != "31" && txtParamST150N.Text != "32" && txtParamST150N.Text != "33" && txtParamST150N.Text != "34")
            {
                // PARAM2 Default = VALUE(4)
                txtParamST150N.Text = "4";
            }


            // PARAM1 : Pocket1
            m_ProtocolDll.PrtcGetPocketResult(1, Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnGetPocketResultST350_Click(object sender, EventArgs e)
        {
            // [12-60] Get Pocket Result (ST-150N)
            // PARAM1 - Pocket No
            // PARAM2 -  1 = ATM,          2 = FIT,          3 = UNFIT,          4 = VALUE
            //          11 = ATM OLD,     12 = FIT OLD,     13 = UNFIT OLD,     14 = VALUE OLD
            //          21 = ATM NEW,     22 = FIT NEW,     23 = UNFIT NEW,     24 = VALUE NEW
            //          31 = ATM VERYNEW, 32 = FIT VERYNEW, 33 = UNFIT VERYNEW, 34 = VALUE VERYNEW
            _model = Models.ST350;


            if (txtParamST350.Text != "1" && txtParamST350.Text != "2" && txtParamST350.Text != "3" && txtParamST350.Text != "4" ||
                txtParamST350.Text != "11" && txtParamST350.Text != "12" && txtParamST350.Text != "13" && txtParamST350.Text != "14" ||
                txtParamST350.Text != "21" && txtParamST350.Text != "22" && txtParamST350.Text != "23" && txtParamST350.Text != "24" ||
                txtParamST350.Text != "31" && txtParamST350.Text != "32" && txtParamST350.Text != "33" && txtParamST350.Text != "34")
            {
                // PARAM2 Default = VALUE(4)
                txtParamST350.Text = "4";
            }


            // PARAM1 : Pocket1
            m_ProtocolDll.PrtcGetPocketResult(1, Convert.ToInt32(txtParamST350.Text));
        }

        private void btnGetBatch_Click(object sender, EventArgs e)
        {
            // [12-61] Get Batch (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetBatch();
        }

        private void btnGetBatchST150N_Click(object sender, EventArgs e)
        {
            // [12-61] Get Batch (ST-150N)
            _model = Models.ST150N;
            txtParamST150N.Text = string.Empty;

            m_ProtocolDll.PrtcGetBatch();
        }

        private void btnGetBatchST350_Click(object sender, EventArgs e)
        {
            // [12-61] Get Batch (ST-350)
            _model = Models.ST350;
            txtParamST350.Text = string.Empty;

            m_ProtocolDll.PrtcGetBatch();
        }

        private void btnSetBatch_Click(object sender, EventArgs e)
        {
            // [12-62] Set Batch (iH-110)
            // PARAM1 - Batch Data Length
            // PARAM2 - Batch Data
            _model = Models.IH110;

            // PARAM2 Default = Batch 100
            if (txtParam.Text == string.Empty)
                txtParam.Text = "100";

            // P1 = 100, Reject1 = 50
            int batch = Convert.ToInt32(txtParam.Text);
            byte[] batchData = new byte[7];
            batchData[0] = 2; // Data Count
            batchData[1] = 1; // Pocket Index : Pocket1
            batchData[2] = Convert.ToByte((batch >> 8) & 0xFF); // Batch : 100
            batchData[3] = Convert.ToByte(batch & 0xFF);

            batch = 50;
            batchData[4] = 101; // Pocket Index : Reject1
            batchData[5] = Convert.ToByte((batch >> 8) & 0xFF); // Batch : 50
            batchData[6] = Convert.ToByte(batch & 0xFF);


            m_ProtocolDll.PrtcSetBatch(7, batchData);
        }

        private void btnSetBatchST150N_Click(object sender, EventArgs e)
        {
            // [12-62] Set Batch (ST-150N)
            // PARAM1 - Batch Data Length
            // PARAM2 - Batch Data
            _model = Models.ST150N;

            // PARAM2 Default = Batch 100
            if (txtParamST150N.Text == string.Empty)
                txtParamST150N.Text = "100";

            // P1 = 100, Reject1 = 50
            int batch = Convert.ToInt32(txtParamST150N.Text);
            byte[] batchData = new byte[7];
            batchData[0] = 2; // Data Count
            batchData[1] = 1; // Pocket Index : Pocket1
            batchData[2] = Convert.ToByte((batch >> 8) & 0xFF); // Batch : 100
            batchData[3] = Convert.ToByte(batch & 0xFF);

            batch = 50;
            batchData[4] = 101; // Pocket Index : Reject1
            batchData[5] = Convert.ToByte((batch >> 8) & 0xFF); // Batch : 50
            batchData[6] = Convert.ToByte(batch & 0xFF);


            m_ProtocolDll.PrtcSetBatch(7, batchData);
        }

        private void btnSetBatchST350_Click(object sender, EventArgs e)
        {
            // [12-62] Set Batch (ST-350)
            // PARAM1 - Batch Data Length
            // PARAM2 - Batch Data : Pocket No + Batch
            _model = Models.ST350;

            // PARAM2 Default = Batch 100
            if (txtParamST350.Text == string.Empty)
                txtParamST350.Text = "100";

            // P1 = 100, Reject1 = 50
            int batch = Convert.ToInt32(txtParamST350.Text);
            byte[] batchData = new byte[7];
            batchData[0] = 2; // Data Count
            batchData[1] = 1; // Pocket Index : Pocket1
            batchData[2] = Convert.ToByte((batch >> 8) & 0xFF); // Batch : 100
            batchData[3] = Convert.ToByte(batch & 0xFF);

            batch = 50;
            batchData[4] = 101; // Pocket Index : Reject1
            batchData[5] = Convert.ToByte((batch >> 8) & 0xFF); // Batch : 50
            batchData[6] = Convert.ToByte(batch & 0xFF);


            m_ProtocolDll.PrtcSetBatch(7, batchData);
        }

        private void btnSetBatchPresetModeST150N_Click(object sender, EventArgs e)
        {
            // [12-63] Set Batch Preset Mode (ST-150N)
            // PARAM - Preset Batch1(2 byte) + Preset Batch2(2 byte) + Preset Batch3(2 byte) + Preset Batch4(2 byte) + Preset Batch5(2 byte)
            //       + Mix Mode Batch(2 byte) + SP Mode Batch(2 byte) + SG Mode Batch(2 byte) + SC Mode Batch(2 byte)
            _model = Models.ST150N;

            // PARAM Default = Batch 100
            if (txtParamST150N.Text == string.Empty)
                txtParamST150N.Text = "100";

            int batch = Convert.ToInt32(txtParamST150N.Text);
            byte[] batchData = new byte[18];

            // Preset Batch1
            batchData[0] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[1] = Convert.ToByte(batch & 0xFF);

            // Preset Batch2
            batchData[2] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[3] = Convert.ToByte(batch & 0xFF);

            // Preset Batch3
            batchData[4] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[5] = Convert.ToByte(batch & 0xFF);

            // Preset Batch4
            batchData[6] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[7] = Convert.ToByte(batch & 0xFF);

            // Preset Batch5
            batchData[8] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[9] = Convert.ToByte(batch & 0xFF);

            // Mix Mode Batch
            batchData[10] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[11] = Convert.ToByte(batch & 0xFF);

            // SP Mode Batch
            batchData[12] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[13] = Convert.ToByte(batch & 0xFF);

            // SG Mode Batch
            batchData[14] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[15] = Convert.ToByte(batch & 0xFF);

            // SC Mode Batch
            batchData[16] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[17] = Convert.ToByte(batch & 0xFF);

            m_ProtocolDll.PrtcSetBatchPresetMode(batchData.Length, batchData);
        }

        private void btnSetBatchPresetModeST350_Click(object sender, EventArgs e)
        {
            // [12-63] Set Batch Preset Mode (ST-350)
            // PARAM - Mix Mode Batch(2 byte) + SP Mode Batch(2 byte) + SG Mode Batch(2 byte) + Dir Mode Batch(2 byte) + Serial Mode Batch(2 byte)
            _model = Models.ST350;

            // PARAM Default = Batch 100
            if (txtParamST350.Text == string.Empty)
                txtParamST350.Text = "100";

            int batch = Convert.ToInt32(txtParamST350.Text);
            byte[] batchData = new byte[10];

            // Mix Mode Batch
            batchData[0] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[1] = Convert.ToByte(batch & 0xFF);

            // SP Mode Batch
            batchData[2] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[3] = Convert.ToByte(batch & 0xFF);

            // SG Mode Batch
            batchData[4] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[5] = Convert.ToByte(batch & 0xFF);

            // Dir Mode Batch
            batchData[6] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[7] = Convert.ToByte(batch & 0xFF);

            // Serial Mode Batch
            batchData[8] = Convert.ToByte((batch >> 8) & 0xFF);
            batchData[9] = Convert.ToByte(batch & 0xFF);

            m_ProtocolDll.PrtcSetBatchPresetMode(batchData.Length, batchData);
        }

        private void btnSetCountingModeST150N_Click(object sender, EventArgs e)
        {
            // [12-64] Set Counting Mode (ST-150N)
            // PARAM - Automatic Counting = 0, Manual Counting = 1
            _model = Models.ST150N;

            // PARAM Default = Automatic Counting(0)
            if (txtParamST150N.Text == string.Empty)
                txtParamST150N.Text = "0";

            m_ProtocolDll.PrtcSetCountingMode(Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnSetAddModeST150N_Click(object sender, EventArgs e)
        {
            // [12-65] Set Add Mode (ST-150N)
            // PARAM - Add Off = 0, Add On = 1
            _model = Models.ST150N;

            // PARAM Default = Add On(1)
            if (txtParamST150N.Text == string.Empty)
                txtParamST150N.Text = "1";

            m_ProtocolDll.PrtcSetAddMode(Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnSetBatchModeST150N_Click(object sender, EventArgs e)
        {
            // [12-66] Set Batch Function (ST-150N)
            // PARAM - Continue = 0, Clear = 1, Validate Continue = 2, Validate Clear = 3
            _model = Models.ST150N;

            // PARAM Default = Continue(0)
            if (txtParamST150N.Text == string.Empty)
                txtParamST150N.Text = "0";

            m_ProtocolDll.PrtcSetBatchFunction(Convert.ToInt32(txtParamST150N.Text));
        }

        private void btnGetAllLocal_Click(object sender, EventArgs e)
        {
            _model = Models.IH110;
            _setUseLocalForm.ShowDialog();
        }

        private void btnGetAllUser_Click(object sender, EventArgs e)
        {
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            _setUserForm.ShowDialog();
        }

        private void btnSetUserSetting_Click(object sender, EventArgs e)
        {
            // [12-90] Set User Setting Reset (iH-110)
            if (MessageBox.Show("CAUTION!! When this protocol is transmitted, the user settings on the connected device are reset to default values!!", "ProtocolDemo", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _model = Models.IH110;
                txtParam.Text = string.Empty;

                m_ProtocolDll.PrtcSetUserSettingReset();
            }
        }


        private void ProtocolHandling(byte[] protocolData)
        {
//            Debug.WriteLine("* ProtocolHandling() - Menu : " + protocolData[0].ToString() + " - " + protocolData[1].ToString());

            if (protocolData[0] == 0x01) // Connection Result
            {
                if (protocolData[1] == 0x01) // Lan Connection
                {
                    _connected = true;

                    this.Invoke(new MethodInvoker(delegate ()
                        {
                            lblServerState.Text = "State : Lan Connected";
                        }));

                    PrintLanConnection(protocolData[2]);
                }
                else if (protocolData[1] == 0x02) // Error Message
                {
                    string errorMessage = Encoding.Default.GetString(protocolData, 2, protocolData.Length - 2);
                    string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : " + errorMessage;

                    SetLogWriteLine(log);
                }
                else if (protocolData[1] == 0x03) // Serial Port Abort
                {
                    MessageBox.Show("Serial Port is abort. Try reconnecting!");

                    if (_connected == true)
                    {
                        _connected = false;

                        m_ProtocolDll.CloseSerialPort();
                        this.Invoke(new Action(delegate ()
                        {
                            lblComPortState.Text = "";
                        }));

                        string log = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : SerialPort Disconnect";
                        SetLogWriteLine(log);
                    }
                }
            }
            else if (protocolData[0] == 0x0C) // Common Protocol
            {
                switch (protocolData[1])
                {
                    case 0x02: // [12-02] ReadyToWork
                        {
                            PrintReadyToWork(protocolData[2]);
                        }
                        break;
                    case 0x0A: // [12-10] Get User Name
                        {
                            byte[] userName = new byte[protocolData.Length - 2];
                            Array.Clear(userName, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, userName, 0, protocolData.Length - 2);

                            PrintGetUserName(userName);
                        }
                        break;
                    case 0x0B: // [12-11] Get Machine Working State
                        {
                            PrintGetMachineWorkingState(protocolData[2]);
                        }
                        break;
                    case 0x0C: // [12-12] Get Pocket State
                        {
                            byte[] pocketState = new byte[protocolData.Length - 2];
                            Array.Clear(pocketState, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, pocketState, 0, protocolData.Length - 2);

                            PrintGetPocketState(pocketState);
                        }
                        break;
                    case 0x0D: // [12-13] Get Counted Result
                        {
                            byte[] countResult = new byte[protocolData.Length - 2];
                            Array.Clear(countResult, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, countResult, 0, protocolData.Length - 2);

                            PrintGetCountedResult(countResult);
                        }
                        break;
                    case 0x10: // [12-16] Get Local
                        {
                            byte[] lcoalData = new byte[protocolData.Length - 2];
                            Array.Clear(lcoalData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, lcoalData, 0, protocolData.Length - 2);

                            PrintGetLocal(lcoalData);
                        }
                        break;
                    case 0x11: // [12-17] Get Denom Info
                        {
                            byte[] denomInfo = new byte[protocolData.Length - 2];
                            Array.Clear(denomInfo, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, denomInfo, 0, protocolData.Length - 2);

                            PrintGetDenomInfo(denomInfo);
                        }
                        break;
                    case 0x12: // [12-18] Get Count Information
                        {
                            byte[] countInfo = new byte[protocolData.Length - 2];
                            Array.Clear(countInfo, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, countInfo, 0, protocolData.Length - 2);

                            PrintGetCountInformation(countInfo);
                        }
                        break;
                    case 0x13: // [12-19] Get Machine Serial Number
                        {
                            byte[] machineSN = new byte[protocolData.Length - 2];
                            Array.Clear(machineSN, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, machineSN, 0, protocolData.Length - 2);

                            PrintGetMachineSN(machineSN);
                        }
                        break;
                    case 0x14: // [12-20] Get Product
                        {
                            PrintGetProduct(protocolData[2]);
                        }
                        break;
                    case 0x15: // [12-21] Get Series
                        {
                            PrintGetSeries(protocolData[2]);
                        }
                        break;
                    case 0x16: // [12-22] Get App Version
                        {
                            byte[] appVersion = new byte[protocolData.Length - 2];
                            Array.Clear(appVersion, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, appVersion, 0, protocolData.Length - 2);

                            PrintGetAppVersion(appVersion);
                        }
                        break;
                    case 0x21: // [12-33] Set Mode
                        {
                            PrintSetMode(protocolData[2]);
                        }
                        break;
                    case 0x28: // [12-40] Get Machine State
                        {
                            byte[] machineState = new byte[protocolData.Length - 2];
                            Array.Clear(machineState, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, machineState, 0, protocolData.Length - 2);

                            PrintGetMachineState(machineState);
                        }
                        break;
                    case 0x29: // [12-41] Get Result Code
                        {
                            byte[] resultCode = new byte[protocolData.Length - 2];
                            Array.Clear(resultCode, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, resultCode, 0, protocolData.Length - 2);

                            PrintGetResultCode(resultCode);
                        }
                        break;
                    case 0x32: // [12-50] Inform Start/Stop
                        {
                            PrintInformStartStop(protocolData[2]);
                        }
                        break;
                    case 0x3C: // [12-60] Get Pocket Result
                        {
                            byte[] pocketResult = new byte[protocolData.Length - 2];
                            Array.Clear(pocketResult, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, pocketResult, 0, protocolData.Length - 2);

                            PrintGetPocketResult(pocketResult);
                        }
                        break;
                    case 0x3D: // [12-61] Get Batch
                        {
                            byte[] batchData = new byte[protocolData.Length - 2];
                            Array.Clear(batchData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, batchData, 0, protocolData.Length - 2);

                            PrintGetBatch(batchData);
                        }
                        break;
                    case 0x3E: // [12-62] Set Batch
                        {
                            PrintSetBatch(protocolData[2]);
                        }
                        break;
                    case 0x3F: // [12-63] Set Batch Preset Mode
                        {
                            PrintSetBatchPresetMode(protocolData[2]);
                        }
                        break;
                    case 0x40: // [12-64] Set Counting Mode
                        {
                            PrintSetCountingMode(protocolData[2]);
                        }
                        break;
                    case 0x41: // [12-65] Set Add Mode
                        {
                            PrintSetAddMode(protocolData[2]);
                        }
                        break;
                    case 0x42: // [12-66] Set Batch Function
                        {
                            PrintSetBatchFunction(protocolData[2]);
                        }
                        break;
                    case 0x46: // [12-70] Get All Local
                        {
                            byte[] localData = new byte[protocolData.Length - 2];
                            Array.Clear(localData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, localData, 0, protocolData.Length - 2);

                            if (_setUseLocalForm.Visible)
                            {
                                this.Invoke(new Action(delegate()
                                    {
                                        _setUseLocalForm.RecvGetAllLocal(localData);
                                    }));
                            }
                        }
                        break;
                    case 0x47: // [12-71] Get Use Local
                        {
                            byte[] localData = new byte[protocolData.Length - 2];
                            Array.Clear(localData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, localData, 0, protocolData.Length - 2);

                            if (_setUseLocalForm.Visible)
                            {
                                this.Invoke(new Action(delegate()
                                    {
                                        _setUseLocalForm.RecvGetUseLocal(localData);
                                    }));
                            }
                        }
                        break;
                    case 0x48: // [12-72] Set Use Local
                        {
                            if (_setUseLocalForm.Visible)
                            {
                                this.Invoke(new Action(delegate()
                                    {
                                        _setUseLocalForm.RecvSetUseLocal(protocolData[2]);
                                    }));
                            }
                        }
                        break;
                    case 0x49: // [12-73] Get Counting Finish New
                        {
                            if (_chequeQRList.Count > 0)
                            {
                                if (_snviewerForm.Visible)
                                {
                                    _snviewerForm.ClearList();
                                    _snviewerForm.ChangeColumn(false);

                                    for (int i = 0; i < _chequeQRList.Count; i++)
                                    {
                                        _CHEQUE_QR_ chequeQR = _chequeQRList[i];
                                        _snviewerForm.ProcessChequeQR(ref chequeQR);
                                    }
                                }

                                _imageIndex = 0;
                                _strFImgPath = string.Empty;
                                _chequeQRList.Clear();
                            }

                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Clear(recvData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);

                            PrintGetCountingFinishNew(recvData);
                        }
                        break;
                    case 0x4A: // [12-74] Get Local Info
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:12-74] Get Local Info";
                            SetLogWriteLine(result);

                            _localInfo.UsePoint = protocolData[2];
                            _localInfo.CallFlag = protocolData[3];
                            Array.Copy(protocolData, 4, _localInfo.Local, 0, 4);

                            result = " - Local Name : " + Encoding.ASCII.GetString(_localInfo.Local, 0, _localInfo.Local.Length).Trim('\0');
                            SetLogWriteLine(result);

                            SetLogWriteLine(" - CallFlag = " + Convert.ToString(_localInfo.CallFlag));

                            for (int i = 0; i < 10; i++)
                            {
                                _localInfo.Denom[i] = (UInt32)protocolData[8 + (i * 4) + 0];
                                _localInfo.Denom[i] |= (UInt32)protocolData[8 + (i * 4) + 1] << 8;
                                _localInfo.Denom[i] |= (UInt32)protocolData[8 + (i * 4) + 2] << 16;
                                _localInfo.Denom[i] |= (UInt32)protocolData[8 + (i * 4) + 3] << 24;

                                if (_localInfo.Denom[i] == 0)
                                {
                                    _gtotalInfo.DenomCount = i;
                                    break;
                                }
                            }

                            // Denom Info not exsit
                            if (protocolData.Length - 2 == 1 && protocolData[2] == 0)
                            {
                                // Next Index Local
                                _localIndex++;
                                GetNewLocalInfo();
                            }
                            else
                            {
                                SettingLocalInfo(_localInfo);
                            }
                        }
                        break;
                    case 0x4B: // [12-75] Get GTotal Info
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:12-75] Get GTotal Info";
                            SetLogWriteLine(result);

                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Clear(recvData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);

                            SettingGTotalInfo(recvData);
                        }
                        break;
                    case 0x50: // [12-80] Get All User
                        {
                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Clear(recvData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);

                            _setUserForm.DataBindUserInfo(recvData);
                        }
                        break;
                    case 0x51: // [12-81] Set User
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

                            if (protocolData[2] == 1)
                                result += "[Protocol:12-81] Set User : Success";
                            else
                                result += "[Protocol:12-81] Set User : Failed";

                            SetLogWriteLine(result);

                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                _setUserForm.InitSetUserData();
                            }));
                        }
                        break;
                    case 0x52: // [12-82] Get Coupon Info
                        {
                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Clear(recvData, 0, protocolData.Length - 2);
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);

                            PrintGetCouponInfo(recvData);
                        }
                        break;
                    case 0x55:  // [12-85] ModifyUserName
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

                            if (protocolData[2] == 1)
                            {
                                result += "[Protocol:12-85] Modify User Name : Success";

                                this.Invoke(new MethodInvoker(delegate ()
                                {
                                    _setUserForm.txt_SelectedUser.Text = _setUserForm.txt_NewUserName.Text;
                                    _setUserForm.lv_User.SelectedItems[0].SubItems[1].Text = _setUserForm.txt_NewUserName.Text;
                                    _setUserForm.InitSetUserData();
                                }));
                            }
                            else
                            {
                                result += "[Protocol:12-85] Modify User Name : Failed";
                            }

                            this.Invoke(new MethodInvoker(delegate ()
                            {
                                _setUserForm.txt_NewUserName.Text = string.Empty;
                            }));

                            SetLogWriteLine(result);
                        }
                        break;
                    case 0x5A: // [12-90] Set Factory Setting
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

                            if (protocolData[2] == 1)
                                result += "[Protocol:12-90] Set Factory Setting : Success";
                            else
                                result += "[Protocol:12-90] Set Factory Setting : Failed";

                            SetLogWriteLine(result);
                        }
                        break;
                    case 0x73: // [12-115] FULL IMAGE + CHEQUE
                        {
                            // MENU [2byte] + TOP FULL IMAGE LENGTH [4 byte] + TOP FULL IMAGE + BOT FULL IMAGE LENGTH [4 byte] + BOT FULL IMAGE

                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:12-115] Full Image + Cheque Data";


                            // Full Image 저장 경로
                            if (string.IsNullOrEmpty(_strFImgPath))
                            {
                                _strFImgPath = string.Format("{0}\\Data\\{1}", System.Environment.CurrentDirectory, DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_FullImage");

                                DirectoryInfo di = new DirectoryInfo(_strFImgPath);
                                if (di.Exists == false)
                                    di.Create();
                            }

                            

                            string strFile = string.Format("//{0}_TOP.jpg", _imageIndex++);


                            // Full Image : TOP
                            int topImageLength = protocolData[2] << 24;
                            topImageLength    |= protocolData[3] << 16;
                            topImageLength    |= protocolData[4] << 8;
                            topImageLength    |= protocolData[5];

                            byte[] topImageBuff = new byte[topImageLength];
                            Array.Copy(protocolData, 6, topImageBuff, 0, topImageLength);

                            SaveFullImageResize(_strFImgPath + strFile, topImageBuff, 2, false);



                            // Full Image : BOT
                            strFile = strFile.Replace("TOP", "BOT");

                            int botImageLength = protocolData[6 + topImageLength    ] << 24;
                            botImageLength    |= protocolData[6 + topImageLength + 1] << 16;
                            botImageLength    |= protocolData[6 + topImageLength + 2] << 8;
                            botImageLength    |= protocolData[6 + topImageLength + 3];

                            byte[] botImageBuff = new byte[botImageLength];
                            Array.Copy(protocolData, (6 + topImageLength + 4), botImageBuff, 0, botImageLength);

                            SaveFullImageResize(_strFImgPath + strFile, botImageBuff, 2, true);



                            // Cheque
                            _CHEQUE_QR_ chequeQR = new _CHEQUE_QR_();

                            int chequeLength = Marshal.SizeOf(chequeQR);
                            byte[] chequeBuff = new byte[chequeLength];
                            Array.Copy(protocolData, (10 + topImageLength + botImageLength), chequeBuff, 0, chequeLength);

                            GCHandle handle = GCHandle.Alloc(chequeBuff, GCHandleType.Pinned);
                            try
                            {
                                chequeQR = (_CHEQUE_QR_)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(_CHEQUE_QR_));
                            }
                            catch
                            {
                                handle.Free();
                            }


                            result += " : " + Encoding.Default.GetString(chequeQR.MICRCode);
                            SetLogWriteLine(result);

                            _chequeQRList.Add(chequeQR);
                        }
                        break;
                }
            }
            else if (protocolData[0] == 0x0A) // SNI Protocol & Upgrade Protocol
            {
                switch (protocolData[1])
                {
                    case 0x14: // [10-20] Real Time SNI Send Start
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:10-20] Real Time SNI Send Start";
                            SetLogWriteLine(result);

                            if (_snviewerForm.Visible)
                            {
                                _snviewerForm.ClearList();
                                _snviewerForm.ChangeColumn(true);
                            }
                        }
                        break;
                    case 0x15: // [10-21] Real Time SNI Send Data
                        {
                            // SNI BODY
                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);
                            GCHandle handle = GCHandle.Alloc(recvData, GCHandleType.Pinned);
                            try
                            {
                                _SNIBody = (_SNI_BODY_)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(_SNI_BODY_));
                            }
                            catch
                            {
                                handle.Free();
                            }

                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += $"[Protocol:10-21] Real Time SNI Send Data : {_SNIBody.SerialNumber} {_SNIBody.Local} {_SNIBody.Denomination}" ;
                            SetLogWriteLine(result);

                            if (_snviewerForm.Visible)
                                _snviewerForm.ProcessSNIBody(ref _SNIBody);
                        }
                        break;
                    case 0x16: // [10-22] Real Time SNI Send End
                        {
                            // SNI Header
                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);
                            GCHandle handle = GCHandle.Alloc(recvData, GCHandleType.Pinned);
                            try
                            {
                                _SNIHeader = (_SNI_HEADER_)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(_SNI_HEADER_));
                            }
                            catch
                            {
                                handle.Free();
                            }

                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:10-22] Real Time SNI Send End : DataCount(" + _SNIHeader.DataCount.ToString() + ")";
                            SetLogWriteLine(result);
                        }
                        break;
                    case 0x17: // [10-23] Cheque Send Start
                        {
                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:10-23] Cheque Send Start";
                            SetLogWriteLine(result);

                            if (_snviewerForm.Visible)
                            {
                                _snviewerForm.ClearList();
                                _snviewerForm.ChangeColumn(false);
                            }
                        }
                        break;
                    case 0x18: // [10-24] Cheque Send Data
                        {
                            // CHEQUE QR
                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);
                            GCHandle handle = GCHandle.Alloc(recvData, GCHandleType.Pinned);
                            try
                            {
                                _ChequeQR = (_CHEQUE_QR_)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(_CHEQUE_QR_));
                            }
                            catch
                            {
                                handle.Free();
                            }

                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:10-24] Cheque Send Data :" + Encoding.Default.GetString(_ChequeQR.MICRCode);

                            
                            //System.Diagnostics.Debug.WriteLine(result);

                            SetLogWriteLine(result);

                            if (_snviewerForm.Visible)
                                _snviewerForm.ProcessChequeQR(ref _ChequeQR);
                        }
                        break;
                    case 0x19: // [10-25] Cheque Send End
                        {
                            // SNI Header
                            byte[] recvData = new byte[protocolData.Length - 2];
                            Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);
                            GCHandle handle = GCHandle.Alloc(recvData, GCHandleType.Pinned);
                            try
                            {
                                _SNIHeader = (_SNI_HEADER_)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(_SNI_HEADER_));
                            }
                            catch
                            {
                                handle.Free();
                            }

                            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                            result += "[Protocol:10-25] Cheque Send End : DataCount(" + _SNIHeader.DataCount.ToString() + ")";
                            SetLogWriteLine(result);
                        }
                        break;
                    case 0x01: // [10-01] CMD Trans File
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.CMD_TRANS_FILE);
                        }
                        break;
                    case 0x02: // [10-02] CMD Trans File Path
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.CMD_TRANS_FILE_PATH);
                        }
                        break;
                    case 0x03: // [10-03] Data Trans File
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.DAT_TRANS_FILE);
                        }
                        break;
                    case 0x04: // [10-04] EOD Trans File
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.EOD_TRANS_FILE);
                        }
                        break;
                    case 0x08: // [10-08] Data Trans File - iH110
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.DAT_TRANS_FILE);
                        }
                        break;
                    case 0x1E: // [10-30] Upgrade Ready
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.Ready);
                        }
                        break;
                    case 0x1F: // [10-31] Upgrade Start
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.Start);
                        }
                        break;
                    case 0x20: // [10-32] Upgrade End
                        {
                            _upgradeForm.SetWaitEventHandle(Form_Upgrade.UpgradeStep.End);
                        }
                        break;
                    case 0x23: // [10-35] License Certification
                        {
                            if (protocolData[2] == 1)
                            {
                                _upgradeForm.StartUpgradeThread();
                            }
                            else
                            {
                                string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                                result += "[Protocol:10-35] : Machine License Error \r\n";

                                SetLogWriteLine(result);
                            }
                        }
                        break;
                }
            }
            else if (protocolData[0] == 0x0B) // Select Local/Denom Protocol
            {
                if (protocolData[1] == 0x1E) // [11-30] Select Local/Denom Start
                {
                    _setLocalDenomForm.RecvPrtcSelectLocalDenomStart(protocolData[2]);
                }
                else if (protocolData[1] == 0x1F) // [11-31] Get Select Local
                {
                    byte[] localInfo = new byte[protocolData.Length-2];
                    Array.Clear(localInfo, 0, protocolData.Length - 2);
                    Array.Copy(protocolData, 2, localInfo, 0, protocolData.Length - 2);

                    _setLocalDenomForm.RecvPrtcGetSelectLocal(localInfo);
                }
                else if (protocolData[1] == 0x20) // [11-32] Set Select Local
                {
                    _setLocalDenomForm.RecvPrtcSetSelectLocal(protocolData[2]);

                }
                else if (protocolData[1] == 0x21) // [11-33] Get Used Denom
                {
                    byte[] denomInfo = new byte[protocolData.Length - 2];
                    Array.Clear(denomInfo, 0, protocolData.Length - 2);
                    Array.Copy(protocolData, 2, denomInfo, 0, protocolData.Length - 2);

                    _setLocalDenomForm.RecvPrtcGetUsedDenom(denomInfo);
                }
                else if (protocolData[1] == 0x22) // [11-34] Get Select Denom
                {
                    byte[] denomInfo = new byte[protocolData.Length - 2];
                    Array.Clear(denomInfo, 0, protocolData.Length - 2);
                    Array.Copy(protocolData, 2, denomInfo, 0, protocolData.Length - 2);

                    _setLocalDenomForm.RecvPrtcGetSelectDenom(denomInfo);
                }
                else if (protocolData[1] == 0x23) // [11-35] Set Select Denom
                {
                    _setLocalDenomForm.RecvPrtcSetSelectDenom(protocolData[2]);
                }
                else if (protocolData[1] == 0x24) // [11-36] Select Local/Denom End
                {
                    _setLocalDenomForm.RecvPrtcSelectLocalDenomEnd(protocolData[2]);
                }
            }
            else if (protocolData[0] == 0x0D)
            {
                if (protocolData[1] == 0x01)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:13-01] : Full Image Start";
                    SetLogWriteLine(result);
                    
                    // Full Image 전송인 경우
                    if (Convert.ToBoolean(protocolData[2] & 0x2))
                    {
                        // Full Image 관련 변수 초기화
                        _fimgBufIdx = 0;
                        Array.Clear(_fimgBuf, 0, 432 * 500 * 300);

                        // Full Image 저장 폴더 경로를 설정
                        string strFolderName = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_Full_Image";
                        _strFImgPath = string.Format("{0}\\Data\\{1}", System.Environment.CurrentDirectory, strFolderName);

                        // Full Image 저장 폴더 경로를 생성
                        DirectoryInfo di = new DirectoryInfo(_strFImgPath);
                        if (di.Exists == false)
                            di.Create();
                    }

                    _model = Models.ST150N;
                    m_ProtocolDll.PrtcFullImageStart();
                }
                else if (protocolData[1] == 0x02)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:13-02] : Full Image Data";
                    SetLogWriteLine(result);

                    Array.Copy(protocolData, 2, _fimgBuf, _fimgBufIdx, protocolData.Length - 2);
                    _fimgBufIdx += protocolData.Length - 2;
                }
                else if (protocolData[1] == 0x03)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:13-03] : Full Image End";
                    SetLogWriteLine(result);

                    int rawWidth = 432;
                    int rawHeight = 500;
                    int rawSize = rawWidth * rawHeight;
                    byte[] rawSplit = new byte[rawSize];

                    int rawImgCount = _fimgBufIdx / rawSize;

                    for (int i = 0; i < rawImgCount; i++)
                    {
                        // Image Data를 분리한다.
                        Array.Clear(rawSplit, 0, rawSize);
                        Array.Copy(_fimgBuf, i * rawSize, rawSplit, 0, rawSize);

                        // 8Bit Bitmap을 생성한다.
                        Bitmap bmp = new Bitmap(rawWidth, rawHeight, PixelFormat.Format8bppIndexed);

                        // Bitmap Data에 Image Data를 복사한다.
                        BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, bmp.PixelFormat);
                        Marshal.Copy(rawSplit, 0, data.Scan0, rawSize);
                        bmp.UnlockBits(data);

                        // Image Palette를 생성한다.
                        ColorPalette palette = bmp.Palette;
                        for (int q = 0; q < 256; q++)
                        {
                            palette.Entries[q] = System.Drawing.Color.FromArgb(q, q, q);
                        }
                        bmp.Palette = palette;

                        // Image를 2배로 확장한다.
                        Bitmap dest = new Bitmap(rawWidth * 2, rawHeight * 2);

                        // Image의 가로, 세로 해상도를 300DPI로 설정한다.
                        dest.SetResolution(300, 300);

                        using (Graphics g = Graphics.FromImage(dest))
                        {
                            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                            g.DrawImage(bmp, new RectangleF(0, 0, rawWidth * 2, rawHeight * 2), new RectangleF(new PointF(0, 0), bmp.Size), GraphicsUnit.Pixel);
                        }

                        // Image를 jpeg 포맷으로 저장한다.
                        string strFileName = _strFImgPath + "\\" + i.ToString() + ".jpg";
                        dest.Save(strFileName, ImageFormat.Jpeg);
                    }
                }
            }
            else if (protocolData[0] == 0x32)
            {
                if (protocolData[1] == 0x01)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : [Protocol:50-01] : Get Machine Info";
                    SetLogWriteLine(result);



                    stMachineInfo = new MachineInfo();
                    byte[] recvData = new byte[protocolData.Length - 2];
                    Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);
                    GCHandle handle = GCHandle.Alloc(recvData, GCHandleType.Pinned);
                    try
                    {
                        stMachineInfo = (MachineInfo)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(MachineInfo));
                    }
                    catch
                    {
                        handle.Free();
                    }

                    result = "  - MachineSN : " + Encoding.Default.GetString(stMachineInfo.MachineSN).Trim('\0') + " \r\n";
                    result += "  - Model : " + Encoding.Default.GetString(stMachineInfo.Model).Trim('\0') + " \r\n";
                    result += "  - SW Version : " + Encoding.Default.GetString(stMachineInfo.SwVersion).Trim('\0') + " (" + Encoding.Default.GetString(stMachineInfo.SwDate).Trim('\0') + ") \r\n";
                    result += "  - User : " + Encoding.Default.GetString(stMachineInfo.User).Trim('\0') + " \r\n";

                    SetLogWriteLine(result);
                }
            }
            else if (protocolData[0] == 0x28) // IH Full Image
            {
                if (protocolData[1] == 0x1A)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-26] : Full Image Start";
                    SetLogWriteLine(result);

                    // Full Image 저장 폴더 경로를 설정
                    string strFolderName = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_Full_Image";
                    _strFImgPath = string.Format("{0}\\Data\\{1}", System.Environment.CurrentDirectory, strFolderName);

                    // Full Image 저장 폴더 경로를 생성
                    DirectoryInfo di = new DirectoryInfo(_strFImgPath);
                    if (di.Exists == false)
                        di.Create();
                }
                else if (protocolData[1] == 0x07)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-7] : Full Image Data";
                    SetLogWriteLine(result);

                    // Note Count
                    int noteCount = 0;
                    noteCount |= protocolData[2] << 24;
                    noteCount |= protocolData[3] << 16;
                    noteCount |= protocolData[4] << 8;
                    noteCount |= protocolData[5];
                    int imgID = protocolData[6];   // Image ID
                    int imgBit = protocolData[8];   // Image Bit
                    int imgWidth = protocolData[10] << 8 | protocolData[9];   // Image Width
                    int imgHeight = protocolData[12] << 8 | protocolData[11]; // Image Height
                    int imgSize = (imgBit / 8) * imgWidth * imgHeight;        // Image Size

                    byte[] imgBuf = new byte[imgSize];
                    Array.Copy(protocolData, 15, imgBuf, 0, imgSize);         // Image Data

                    // Image Path
                    string strPath = string.Empty;

                    // Image Data
                    if (imgBit == 32) // 32 BIT IMAGE
                    {
                        int fimgByteIdx = 0;
                        if (imgID == 4)  // 32 BIT IMAGE - TQIR, TIRR, BQG, BIRR
                        {
                            int fimgTQIRIdx = 0, fimgTIRRIdx = 0, fimgBQGIdx = 0, fimgBIRRIdx = 0;
                            byte[] fimgTQIR = new byte[imgWidth * imgHeight];
                            byte[] fimgTIRR = new byte[imgWidth * imgHeight];
                            byte[] fimgBQG = new byte[imgWidth * imgHeight];
                            byte[] fimgBIRR = new byte[imgWidth * imgHeight];

                            // Image Data를 각 버퍼에 나눠서 저장한다.
                            for (int i = 0; i < imgSize; i++)
                            {
                                if (fimgByteIdx == 0) fimgTQIR[fimgTQIRIdx++] = imgBuf[i];
                                else if (fimgByteIdx == 1) fimgTIRR[fimgTIRRIdx++] = imgBuf[i];
                                else if (fimgByteIdx == 2) fimgBQG[fimgBQGIdx++] = imgBuf[i];
                                else if (fimgByteIdx == 3) fimgBIRR[fimgBIRRIdx++] = imgBuf[i];

                                if (++fimgByteIdx == 4)
                                    fimgByteIdx = 0;
                            }

                            // Image Data를 각 버퍼별로 저장한다.
                            SaveFullImage(fimgTQIR, _strFImgPath + "\\" + noteCount.ToString() + "_TOP_QIR.jpg", imgWidth, imgHeight, 8);
                            SaveFullImage(fimgTIRR, _strFImgPath + "\\" + noteCount.ToString() + "_TOP_IRR.jpg", imgWidth, imgHeight, 8);
                            SaveFullImage(fimgBQG, _strFImgPath + "\\" + noteCount.ToString() + "_BOT_QG.jpg", imgWidth, imgHeight, 8);
                            SaveFullImage(fimgBIRR, _strFImgPath + "\\" + noteCount.ToString() + "_BOT_IRR.jpg", imgWidth, imgHeight, 8);
                        }
                        else  // 32 BIT IMAGE - RGB, WHITE
                        {
                            int fimgRGBIdx = 0, fimgWHITEIdx = 0;
                            byte[] fimgRGB = new byte[2500000];
                            byte[] fimgWHITE = new byte[720000];

                            for (int i = 0; i < imgSize; i++)
                            {
                                if (fimgByteIdx == 0) fimgRGB[fimgRGBIdx++] = imgBuf[i];
                                else if (fimgByteIdx == 1) fimgRGB[fimgRGBIdx++] = imgBuf[i];
                                else if (fimgByteIdx == 2) fimgRGB[fimgRGBIdx++] = imgBuf[i];
                                else if (fimgByteIdx == 3) fimgWHITE[fimgWHITEIdx++] = imgBuf[i];

                                if (++fimgByteIdx == 4)
                                    fimgByteIdx = 0;
                            }

                            if (imgID == 0)
                            {
                                strPath = _strFImgPath + "\\" + noteCount.ToString() + "_TOP_RGB.jpg";
                                SaveFullImage(fimgRGB, strPath, imgWidth, imgHeight, 24);
                            }
                            else
                            {
                                strPath = _strFImgPath + "\\" + noteCount.ToString() + "_BOT_RGB.jpg";
                                SaveFullImageSymmetry(fimgRGB, strPath, imgWidth, imgHeight, 24);
                            }

                            if (imgID == 0)
                            {
                                strPath = _strFImgPath + "\\" + noteCount.ToString() + "_TOP_WHITE.jpg";
                                SaveFullImage(fimgWHITE, strPath, imgWidth, imgHeight, 8);
                            }
                            else
                            {
                                strPath = _strFImgPath + "\\" + noteCount.ToString() + "_BOT_WHITE.jpg";
                                SaveFullImageSymmetry(fimgWHITE, strPath, imgWidth, imgHeight, 8);
                            }
                        }
                    }
                    else if (imgBit == 24) // 24BIT IMAGE - RGB
                    {
                        byte[] fimgRGB = new byte[2500000];
                        Array.Clear(fimgRGB, 0, 2500000);
                        Array.Copy(imgBuf, 0, fimgRGB, 0, imgSize);

                        if (imgID == 0)
                        {
                            strPath = _strFImgPath + "\\" + noteCount.ToString() + "_TOP_RGB.jpg";
                            SaveFullImage(fimgRGB, strPath, imgWidth, imgHeight, imgBit);
                        }
                        else
                        {
                            strPath = _strFImgPath + "\\" + noteCount.ToString() + "_BOT_RGB.jpg";
                            SaveFullImageSymmetry(fimgRGB, strPath, imgWidth, imgHeight, imgBit);
                        }
                    }
                    else if (imgBit == 8) // 8BIT IMAGE - WHITE
                    {
                        byte[] fimgWHITE = new byte[720000];
                        Array.Clear(fimgWHITE, 0, 720000);
                        Array.Copy(imgBuf, 0, fimgWHITE, 0, imgSize);

                        if (imgID == 0)
                        {
                            strPath = _strFImgPath + "\\" + noteCount.ToString() + "_TOP_WHITE.jpg";
                            SaveFullImage(fimgWHITE, strPath, imgWidth, imgHeight, imgBit);
                        }
                        else
                        {
                            strPath = _strFImgPath + "\\" + noteCount.ToString() + "_BOT_WHITE.jpg";
                            SaveFullImageSymmetry(fimgWHITE, strPath, imgWidth, imgHeight, imgBit);
                        }
                    }
                }
                else if (protocolData[1] == 0x1B)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-27] : Full Image End";

                    SetLogWriteLine(result);
                }
                // MICR Data //////////////////////////////////////////////////////////////////////////
                else if (protocolData[1] == 0x18)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-24] : MICR Image Start";
                    SetLogWriteLine(result);

                    if (_snviewerForm.Visible)
                    {
                        _snviewerForm.ClearList();
                        _snviewerForm.ChangeColumn(true);
                    }
                }
                else if (protocolData[1] == 0x17)
                {
                    // NOTE MICR
                    byte[] recvData = new byte[protocolData.Length - 2];
                    Array.Copy(protocolData, 2, recvData, 0, protocolData.Length - 2);
                    GCHandle handle = GCHandle.Alloc(recvData, GCHandleType.Pinned);
                    try
                    {
                        _ChequeMICR = (_CHEQUE_MICR_)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(_CHEQUE_MICR_));
                    }
                    catch
                    {
                        handle.Free();
                    }

                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-23] : MICR Image Data";
                    SetLogWriteLine(result);

                    if (_snviewerForm.Visible)
                        _snviewerForm.ProcessChequeMICR(ref _ChequeMICR);
                }
                else if (protocolData[1] == 0x19)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-25] : MICR Image End";
                    SetLogWriteLine(result);
                }


                // JPEG
                else if (protocolData[1] == 0x70)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-112] : JPEG Image Start";
                    SetLogWriteLine(result);

                    // Full Image 저장 폴더 경로를 설정
                    string strFolderName = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_Full_Image";
                    _strFImgPath = string.Format("{0}\\Data\\{1}", System.Environment.CurrentDirectory, strFolderName);

                    // Full Image 저장 폴더 경로를 생성
                    DirectoryInfo di = new DirectoryInfo(_strFImgPath);
                    if (di.Exists == false)
                        di.Create();
                }
                else if (protocolData[1] == 0x71)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-113] : JPEG Image Data";
                    SetLogWriteLine(result);

                    int noteCount = 0;
                    noteCount |= protocolData[2] << 24;
                    noteCount |= protocolData[3] << 16;
                    noteCount |= protocolData[4] << 8;
                    noteCount |= protocolData[5];
                    int imgID = protocolData[6];
                    int imgSize = protocolData.Length - 7;

                    byte[] imgBuf = new byte[imgSize];
                    Array.Copy(protocolData, 7, imgBuf, 0, imgSize);

                    // Image Path
                    string strPath = string.Empty;

                    if (imgID == 0)
                    {
                        // TOP JPEG
                        strPath = $"{_strFImgPath}\\{noteCount}_TOP_RGB.jpeg";
                        BinaryWriter bw = new BinaryWriter(new FileStream(strPath, FileMode.CreateNew));
                        bw.Write(imgBuf);
                        bw.Close();
                    }
                    else
                    {
                        // BOT JPEG
                        strPath = $"{_strFImgPath}\\{noteCount}_BOT_RGB.jpeg";
                        BinaryWriter bw = new BinaryWriter(new FileStream(strPath, FileMode.CreateNew));
                        bw.Write(imgBuf);
                        bw.Close();

                        // Mirror
                        Bitmap image = new Bitmap(strPath);
                        image.RotateFlip(RotateFlipType.RotateNoneFlipX);
                        image.Save(strPath);
                    }
                }
                else if (protocolData[1] == 0x72)
                {
                    string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
                    result += "[Protocol:40-114] : JPEG Image End";
                    SetLogWriteLine(result);
                }
            }
        }

        private void SaveFullImageResize(string strFilePath, byte[] imageData, int nResize, bool bMirror)
        {
            ImageConverter imageConverter = new ImageConverter();
            Image image = (Image)imageConverter.ConvertFrom(imageData);

            int nNewWidth  = image.Width * nResize;
            int nNewHeight = image.Height * nResize;

            Bitmap dest = new Bitmap(nNewWidth, nNewHeight);
            dest.SetResolution(300, 300);

            using (Graphics g = Graphics.FromImage(dest))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawImage(image, new RectangleF(0, 0, nNewWidth, nNewHeight), new RectangleF(new PointF(0, 0), image.Size), GraphicsUnit.Pixel);
            }


            // Mirror
            if (bMirror)
            {
                dest.RotateFlip(RotateFlipType.RotateNoneFlipX);
            }


            dest.Save(strFilePath, ImageFormat.Jpeg);
        }

        private void SaveFullImageSymmetry(byte[] imgData, string strPath, int nWidth, int nHeight, int nBit)
        {
            // Image Bit
            int imgBit = nBit / 8;

            // Image Padding을 구한다.
            int imgPadding = (4 - (nWidth * imgBit) % 4) % 4;

            // Padding이 포함된 Image Size로 Image Data를 재구성한다.
            byte[] imgSave = new byte[(nWidth + imgPadding) * imgBit * nHeight];
            Array.Clear(imgSave, 0, (nWidth + imgPadding) * imgBit * nHeight);

            for (int i = 0; i < nHeight; i++)
            {
                for (int j = 0; j < nWidth; j++)
                {
                    for (int b = 0; b < imgBit; b++)
                    {
                        imgSave[((nWidth * imgBit) + imgPadding) * i + (j * imgBit) + b] = imgData[(nWidth * imgBit * i) + ((nWidth - 1) * imgBit) - (j * imgBit) + b];
                    }
                }
            }

            // Image Bit에 따라 Bitmap Format을 설정한다.
            PixelFormat formatBit = 0;
            if (nBit == 8) formatBit = PixelFormat.Format8bppIndexed;
            else formatBit = PixelFormat.Format24bppRgb;

            // 설정한 Format으로 Bitmap을 생성한다.
            Bitmap bmp = new Bitmap(nWidth, nHeight, formatBit);

            // IH 모델의 FullImage 데이터는 해상도를 300dpi로 설정하여 저장한다.
            bmp.SetResolution(300, 300);

            // Bitmap Data에 Image Data를 복사한다.
            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, bmp.PixelFormat);
            Marshal.Copy(imgSave, 0, data.Scan0, nWidth * imgBit * nHeight);
            bmp.UnlockBits(data);
            
            // 8Bit Image는 Palette를 생성한다.
            if (nBit == 8)
            {
                ColorPalette palette = bmp.Palette;
                for (int q = 0; q < 256; q++)
                {
                    palette.Entries[q] = System.Drawing.Color.FromArgb(q, q, q);
                }
                bmp.Palette = palette;
            }

            // Image를 2배로 확장한다.
            Bitmap dest = new Bitmap(nWidth * 2, nHeight * 2);

            // Image의 가로, 세로 해상도를 300DPI로 설정한다.
            dest.SetResolution(300, 300);

            using (Graphics g = Graphics.FromImage(dest))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawImage(bmp, new RectangleF(0, 0, nWidth * 2, nHeight * 2), new RectangleF(new PointF(0, 0), bmp.Size), GraphicsUnit.Pixel);
            }

            // Image를 jpeg 포맷으로 저장한다.
            dest.Save(strPath, ImageFormat.Jpeg);
        }

        private void SaveFullImage(byte[] imgData, string strPath, int nWidth, int nHeight, int nBit)
        {
            // Image Bit
            int imgBit = nBit / 8;

            // Image Padding을 구한다.
            int imgPadding = (4 - (nWidth * imgBit) % 4) % 4;

            // Padding이 포함된 Image Size로 Image Data를 재구성한다.
            byte[] imgSave = new byte[(nWidth + imgPadding) * imgBit * nHeight];
            Array.Clear(imgSave, 0, (nWidth + imgPadding) * imgBit * nHeight);
            for (int i = 0; i < nHeight; i++)
            {
                int desCopyPos = (nWidth * i) * imgBit + (i * imgPadding);
                int srcCopyPos = (nWidth * i) * imgBit;
                int copySize = nWidth * imgBit;

                Array.Copy(imgData, srcCopyPos, imgSave, desCopyPos, copySize);
            }

            // Image Bit에 따라 Bitmap Format을 설정한다.
            PixelFormat formatBit = 0;
            if (nBit == 8) formatBit = PixelFormat.Format8bppIndexed;
            else formatBit = PixelFormat.Format24bppRgb;

            // 설정한 Format으로 Bitmap을 생성한다.
            Bitmap bmp = new Bitmap(nWidth, nHeight, formatBit);

            // IH 모델의 FullImage 데이터는 해상도를 300dpi로 설정하여 저장한다.
            bmp.SetResolution(300, 300);

            // Bitmap Data에 Image Data를 복사한다.
            BitmapData data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.WriteOnly, bmp.PixelFormat);
            Marshal.Copy(imgSave, 0, data.Scan0, nWidth * imgBit * nHeight);
            bmp.UnlockBits(data);

            // 8Bit Image는 Palette를 생성한다.
            if (nBit == 8)
            {
                ColorPalette palette = bmp.Palette;
                for (int q = 0; q < 256; q++)
                {
                    palette.Entries[q] = System.Drawing.Color.FromArgb(q, q, q);
                }
                bmp.Palette = palette;
            }

            // Image를 2배로 확장한다.
            Bitmap dest = new Bitmap(nWidth * 2, nHeight * 2);

            // Image의 가로, 세로 해상도를 300DPI로 설정한다.
            dest.SetResolution(300, 300);

            using (Graphics g = Graphics.FromImage(dest))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawImage(bmp, new RectangleF(0, 0, nWidth * 2, nHeight * 2), new RectangleF(new PointF(0, 0), bmp.Size), GraphicsUnit.Pixel);
            }

            // Image를 jpeg 포맷으로 저장한다.
            dest.Save(strPath, ImageFormat.Jpeg);
        }

        private void PrintLanConnection(byte recvData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";

            if (recvData == 1)
            {
                result += "Lan Connection : Success";

                // IH-110 Series의 경우 Full Image를 받기 위함
                //_model = Models.IH110;
                txtParam.Text = string.Empty;

                m_ProtocolDll.PrtcGetMachineInfoIH();
            }
            else
            {
                result += "Lan Connection : Fail";
            }
            
            SetLogWriteLine(result);
        }

        private void PrintGetBatchOld(byte[] batchData)
        {
            string result = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] : ";
            result += "[Protocol:12-15] Get Batch : ";

            if (batchData.Length != 4)
            {
                result += "DTL Error!";
                SetLogWriteLine(result);

                return;
            }

            result += "\r\n";

            if (_model == Models.IH110 || _model == Models.ST150N)
            {
                // Pocket1 Batch
                result += " - Pocket1 Batch : " + batchData[0].ToString();

                // Reject Batch
                result += " - Reject Batch : " + batchData[3].ToString();
            }
            else if (_model == (int)Models.ST350)
            {
                // Pocket1 Batch
                result += " - Pocket1 Batch : " + batchData[0].ToString();

                // Pocket2 Batch
                result += " - Pocket2 Batch : " + batchData[1].ToString();

                // Pocket3 Batch
                result += " - Pocket3 Batch : " + batchData[2].ToString();

                // Reject Batch
                result += " - Reject Batch : " + batchData[3].ToString();
            }
            else
            {
                result += "model error!";
            }

            SetLogWriteLine(result);
        }

        private void tabProtocol_Selected(object sender, TabControlEventArgs e)
        {
            if (e.TabPageIndex == 0) // iH-110
            {
                _model = Models.IH110;
            }
            else if (e.TabPageIndex == 1) // ST-150N
            {
                _model = Models.ST150N;
            }
            else if (e.TabPageIndex == 2) // ST-350
            {
                _model = Models.ST350;
            }
        }


        private void SettingLocalInfo(LocalInfo localInfo)
        {
            // Invalid LocalInfo
            if (localInfo.CallFlag == 0)
            {
                _localIndex++;
                GetNewLocalInfo();
                return;
            }

            CallFlag callFlag = (CallFlag)localInfo.CallFlag;
            if (callFlag.HasFlag(CallFlag.ATM))
            {
                _gtotalInfo.UseAtm = 1;
                _queCallFlag.Enqueue(1);
            }

            if (callFlag.HasFlag(CallFlag.FIT))
            {
                _gtotalInfo.UseFit = 1;
                _queCallFlag.Enqueue(2);
            }

            if (callFlag.HasFlag(CallFlag.UNFIT))
            {
                _gtotalInfo.UseUnfit = 1;
                _queCallFlag.Enqueue(3);
            }

            if (callFlag.HasFlag(CallFlag.VALUE))
            {
                _gtotalInfo.UseValue = 1;
                _queCallFlag.Enqueue(4);
            }

            if (callFlag.HasFlag(CallFlag.MANUAL))
            {
                _gtotalInfo.UseManual = 1;
                _queCallFlag.Enqueue(5);
            }

            if (callFlag.HasFlag(CallFlag.REJECT))
            {
                _gtotalInfo.UseReject = 1;
                _queCallFlag.Enqueue(6);
            }

            // Denomination setting
            for (int i = 0; i < _gtotalInfo.DenomCount; i++)
            {
                if (_localInfo.UsePoint == 1)
                {
                    _gtotalInfo.DenomData[i] = (double)localInfo.Denom[i] / 100;
                }
                else
                {
                    _gtotalInfo.DenomData[i] = (double)localInfo.Denom[i];
                }
            }

            // Request GTotal Info By CallFlag
            GetNewGtotalInfo();
        }

        private void SettingGTotalInfo(byte[] recvData)
        {
            if (_callFlag == 1) // ATM
            {
                Buffer.BlockCopy(recvData, 0, _gtotalInfo.AtmCount, 0, 120);
            }
            else if (_callFlag == 2) // FIT
            {
                Buffer.BlockCopy(recvData, 0, _gtotalInfo.FitCount, 0, 120);
            }
            else if (_callFlag == 3) // UNFIT
            {
                Buffer.BlockCopy(recvData, 0, _gtotalInfo.UnfitCount, 0, 120);
            }
            else if (_callFlag == 4) // VALUE
            {
                Buffer.BlockCopy(recvData, 0, _gtotalInfo.ValueCount, 0, 120);
            }
            else if (_callFlag == 5) // MANUAL
            {
                Buffer.BlockCopy(recvData, 0, _gtotalInfo.ManualCount, 0, 120);
            }
            else if (_callFlag == 6) // REJECT
            {
                uint[] RejectCountCopy = new uint[30];
                Buffer.BlockCopy(recvData, 0, RejectCountCopy, 0, 120);

                _gtotalInfo.RejectCount = 0;
                for (int i = 0; i < 30; i++)
                {
                    if (RejectCountCopy[i] > 0)
                    {
                        _gtotalInfo.RejectCount += RejectCountCopy[i];
                    }
                }
            }
            GetNewGtotalInfo();
        }

        public void GetNewLocalInfo()
        {
            if (_localIndex < _localCount)
            {
                m_ProtocolDll.PrtcGetLocalInfo(_localIndex);
            }
            else
            {
                _callFlag    = 0;
                _localIndex  = 0;
                _localCount  = 0;
                _gtotalIndex = 0;
                _gtotalInfo.Clear();
            }
        }

        public void GetNewGtotalInfo()
        {
            if (_queCallFlag.Count() == 0)
            {
                PrintLocalGtotalInfo();
            }
            else
            {
                _callFlag = _queCallFlag.Dequeue();
                m_ProtocolDll.PrtcGetGTotalInfo(_localIndex, _callFlag);
            }
        }

        private void SetLogWrite(string log)
        {
            this.Invoke(new MethodInvoker(delegate()
            {
                txt_recvData_ascii.AppendText(log);
            }));
        }

        public void SetLogWriteLine(string log)
        {
            //log += " \r\n";

            this.Invoke(new MethodInvoker(delegate()
            {
                txt_recvData_ascii.AppendText(log);
                txt_recvData_ascii.AppendText("\r\n");
            }));
        }

        private void btnSetAddMode_Click(object sender, EventArgs e)
        {
            // [12-65] Set Add Mode (IH-110)
            // PARAM - Add Off = 0, Add On = 1
            _model = Models.IH110;

            if (txtParam.Text != "0" && txtParam.Text != "1")
            {
                // PARAM Default = Add On(1)
                txtParam.Text = "1";
            }

            m_ProtocolDll.PrtcSetAddMode(Convert.ToInt32(txtParam.Text));
        }

        private void btnSetBatchFunction_Click(object sender, EventArgs e)
        {
            // [12-66] Set Batch Function (IH-110)
            // PARAM - Continue = 0, Clear = 1, Validate Continue = 2, Validate Clear = 3
            _model = Models.IH110;

            if (txtParam.Text != "0" && txtParam.Text != "1" && txtParam.Text != "2" && txtParam.Text != "3")
            {
                // PARAM Default = Continue(0)
                txtParam.Text = "0";
            }

            m_ProtocolDll.PrtcSetBatchFunction(Convert.ToInt32(txtParam.Text));
        }

        private void cbb_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            // TYPE = SERIAL 일경우 Baud Rate = 115200
            if (cbb_type.SelectedIndex == 1)
            {
                cbb_baudRate.SelectedIndex = 0;
            }
        }

        private void cbb_portName_DropDown(object sender, EventArgs e)
        {
            for (int i = cbb_portName.Items.Count - 1; i >= 0; i--)
            {
                cbb_portName.Items.RemoveAt(i);
            }

            SetPortName();
        }

        private void btnGetMachineInfo_Click(object sender, EventArgs e)
        {
            // [50-01] Get Machine Info (IH-110)
            _model = Models.ST150N;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetMachineInfoIH();
        }

        private void btnGetAppVersionST150N_Click(object sender, EventArgs e)
        {
            // [12-22] Get App Version (ST-150N)
            _model = Models.ST150N;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetAppVersion();
        }

        private void btnGetAppVersionST350_Click(object sender, EventArgs e)
        {
            // [12-22] Get App Version (ST-350)
            _model = Models.ST350;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetAppVersion();
        }

        private void btnGetSNIData_Click(object sender, EventArgs e)
        {
            // [12-92] Get SNI Data (iH-110)
            _model = Models.IH110;
            txtParam.Text = string.Empty;

            m_ProtocolDll.PrtcGetSNIData();
        }

        private void cbb_portName_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form_ProtocolDemo_Load(object sender, EventArgs e)
        {

        }
    }

    public class RecvData
    {
        public int MN;
        public int DATA_LEN;
        public byte[] DATA = new byte[5400];
    }

    public class Packet
    {
        public byte PS1;
        public byte PS2;
        public int LN;
        public byte SM;
        public byte BI;
        public int MND;
        public byte[] MN = new byte[2];
        public int DTL;
        public byte[] DT = new byte[65536];
        public byte PE;
        public byte CS;
    }

    // SNI Header
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Unicode)]
    public struct _SNI_HEADER_
    {
        public byte FileVersion; // SNI Version : 7

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 21)]
        public String Product;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 31)]
        public String Series;

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 12)]
        public String MachineSN;

        public UInt32 DataCount;
    };

    // SNI Body
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct _SNI_BODY_
    {
        public byte Used; // Start Flag
        public byte Type; // Serial Number = 1
        public UInt32 Index; // Note Count Index
        public byte Count; // SN Count
        public byte SizeX1; // SN X Size1
        public byte SizeX2; // SN X Size2
        public byte SizeY; // SN Y Size
        public byte OutputPocket; // Out Pocket

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 10)]
        public String Denomination; // Denomination

        public byte CurrencyIndex; // Denomination Index
        public byte NoteState; // Note State : ATM, FIT, UNFIT, COMMON, REJECT
        public byte HiCode; // Error Hi Code
        public byte LowCode; // Error Low Code
        public byte NoteVersion; // Note Version : old, new, veryNew

        public UInt16 CountDate; // Count Date
        public UInt16 CountTime; // Count Time

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 4)]
        public String Local; // Local

        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
        public String SerialNumber; // Serial Number

        public UInt16 DataSize; // Serial Image Size
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5280)]
        public byte[] Data; // Serial Image Data
    };

    // MICR Struct
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct _CHEQUE_MICR_
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] NoteLocal;

        public int NoteCount;
        public int NoteState;
        public byte NoteVer;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public char[] NoteValue;

        public ushort CountDate;
        public ushort CountTime;

        public int MICRCount;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 60)]
        public byte[] MICRText;

        public int MICR_X;
        public int MICR_Y;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24000)]
        public byte[] MICR_GRY;
    }

    // CHEQUE Struct - IH-110 (Halk Bank)
    [StructLayout(LayoutKind.Sequential, Pack = 1, CharSet = CharSet.Ansi)]
    public struct _CHEQUE_QR_
    {
        public UInt16 CountDate;
        public UInt16 CountTime;

        public UInt32 NoteIndex;
        public byte NoteState;     // 0 = Reject, 1 = Stacker
        public byte NoteDirection; // 0 = FF, 1 = FR, 2 = BF, 3 = BR

        public byte NoteErrorCodeHi;
        public byte NoteErrorCodeLow;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
        public byte[] MachineSN;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
        public byte[] Teller;

        public UInt32 BankCode;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
        public byte[] BankName;

        public UInt32 BranchCode;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
        public byte[] BranchName;

        public int MICRXSize;
        public int MICRYSize;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 24000)]
        public byte[] MICRImage;

        public byte MICRCodeCount;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 60)]
        public byte[] MICRCode;

        public byte QRCodeCount;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 100)]
        public byte[] QRCode;

        public UInt16 FullImageWidth;
        public UInt16 FullImageHeight;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct COPYDATASTRUCT
    {
        public IntPtr dwData;
        public int cbData;
        public IntPtr lpData;
    };





    public class LocalInfo
    {
        public byte UsePoint;
        public byte CallFlag;
        public byte[] Local = new byte[4];
        public UInt32[] Denom = new UInt32[10];

        public LocalInfo() { }
    }

    public class GTotalInfo
    {
        public int DenomCount;
        public double[] DenomData = new double[10];

        public byte UseAtm;
        public uint[] AtmCount = new uint[30];
        public double[] AtmAmount = new double[30];

        public byte UseFit;
        public uint[] FitCount = new uint[30];
        public double[] FitAmount = new double[30];

        public byte UseUnfit;
        public uint[] UnfitCount = new uint[30];
        public double[] UnfitAmount = new double[30];

        public byte UseValue;
        public uint[] ValueCount = new uint[30];
        public double[] ValueAmount = new double[30];

        public byte UseManual;
        public uint[] ManualCount = new uint[30];
        public double[] ManualAmount = new double[30];

        public byte UseReject;
        public uint RejectCount;

        public GTotalInfo() { }

        public void Clear()
        {
            DenomCount  = 0;
            UseAtm      = 0;
            UseFit      = 0;
            UseUnfit    = 0;
            UseValue    = 0;
            UseManual   = 0;
            UseReject   = 0;
            RejectCount = 0;

            Array.Clear(DenomData,    0, DenomData.Length);
            Array.Clear(AtmCount,     0, AtmCount.Length);
            Array.Clear(AtmAmount,    0, AtmAmount.Length);
            Array.Clear(FitCount,     0, FitCount.Length);
            Array.Clear(FitAmount,    0, FitAmount.Length);
            Array.Clear(UnfitCount,   0, UnfitCount.Length);
            Array.Clear(UnfitAmount,  0, UnfitAmount.Length);
            Array.Clear(ValueCount,   0, ValueCount.Length);
            Array.Clear(ValueAmount,  0, ValueAmount.Length);
            Array.Clear(ManualCount,  0, ManualCount.Length);
            Array.Clear(ManualAmount, 0, ManualAmount.Length);
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public class MachineInfo
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] Model;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 15)]
        public byte[] MachineSN;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        public byte[] SwVersion;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] SwDate;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 21)]
        public byte[] User;
    }
}

﻿namespace ProtocolDemo
{
    partial class Form_SetUseLocal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lv_local = new System.Windows.Forms.ListView();
            this.col_index = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_code = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_setUseLocal = new System.Windows.Forms.Button();
            this.edit_currIdx = new System.Windows.Forms.TextBox();
            this.edit_currCode = new System.Windows.Forms.TextBox();
            this.edit_currName = new System.Windows.Forms.TextBox();
            this.edit_setIndex = new System.Windows.Forms.TextBox();
            this.edit_setCode = new System.Windows.Forms.TextBox();
            this.edit_setName = new System.Windows.Forms.TextBox();
            this.btn_getUseLocal = new System.Windows.Forms.Button();
            this.btn_getAllLocal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lv_local
            // 
            this.lv_local.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_index,
            this.col_code,
            this.col_name});
            this.lv_local.FullRowSelect = true;
            this.lv_local.GridLines = true;
            this.lv_local.Location = new System.Drawing.Point(12, 152);
            this.lv_local.Name = "lv_local";
            this.lv_local.Size = new System.Drawing.Size(264, 262);
            this.lv_local.TabIndex = 0;
            this.lv_local.UseCompatibleStateImageBehavior = false;
            this.lv_local.View = System.Windows.Forms.View.Details;
            this.lv_local.DoubleClick += new System.EventHandler(this.lv_local_DBClick);
            // 
            // col_index
            // 
            this.col_index.Text = "Index";
            this.col_index.Width = 76;
            // 
            // col_code
            // 
            this.col_code.Text = "Code";
            this.col_code.Width = 77;
            // 
            // col_name
            // 
            this.col_name.Text = "Name";
            this.col_name.Width = 90;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(121, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Index";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(175, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 2;
            this.label2.Text = "Code";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(229, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 12);
            this.label3.TabIndex = 3;
            this.label3.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "Curr Use Local :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 97);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 12);
            this.label5.TabIndex = 5;
            this.label5.Text = "Set Use Local :";
            // 
            // btn_setUseLocal
            // 
            this.btn_setUseLocal.Location = new System.Drawing.Point(136, 116);
            this.btn_setUseLocal.Name = "btn_setUseLocal";
            this.btn_setUseLocal.Size = new System.Drawing.Size(140, 27);
            this.btn_setUseLocal.TabIndex = 6;
            this.btn_setUseLocal.Text = "[12-72] Set Use Local";
            this.btn_setUseLocal.UseVisualStyleBackColor = true;
            this.btn_setUseLocal.Click += new System.EventHandler(this.btn_setUseLocal_Click);
            // 
            // edit_currIdx
            // 
            this.edit_currIdx.Location = new System.Drawing.Point(116, 32);
            this.edit_currIdx.Name = "edit_currIdx";
            this.edit_currIdx.ReadOnly = true;
            this.edit_currIdx.Size = new System.Drawing.Size(47, 21);
            this.edit_currIdx.TabIndex = 7;
            // 
            // edit_currCode
            // 
            this.edit_currCode.Location = new System.Drawing.Point(169, 32);
            this.edit_currCode.Name = "edit_currCode";
            this.edit_currCode.ReadOnly = true;
            this.edit_currCode.Size = new System.Drawing.Size(46, 21);
            this.edit_currCode.TabIndex = 8;
            // 
            // edit_currName
            // 
            this.edit_currName.Location = new System.Drawing.Point(221, 32);
            this.edit_currName.Name = "edit_currName";
            this.edit_currName.ReadOnly = true;
            this.edit_currName.Size = new System.Drawing.Size(55, 21);
            this.edit_currName.TabIndex = 9;
            // 
            // edit_setIndex
            // 
            this.edit_setIndex.Location = new System.Drawing.Point(116, 92);
            this.edit_setIndex.Name = "edit_setIndex";
            this.edit_setIndex.ReadOnly = true;
            this.edit_setIndex.Size = new System.Drawing.Size(47, 21);
            this.edit_setIndex.TabIndex = 10;
            // 
            // edit_setCode
            // 
            this.edit_setCode.Location = new System.Drawing.Point(168, 92);
            this.edit_setCode.Name = "edit_setCode";
            this.edit_setCode.ReadOnly = true;
            this.edit_setCode.Size = new System.Drawing.Size(47, 21);
            this.edit_setCode.TabIndex = 11;
            // 
            // edit_setName
            // 
            this.edit_setName.Location = new System.Drawing.Point(221, 92);
            this.edit_setName.Name = "edit_setName";
            this.edit_setName.ReadOnly = true;
            this.edit_setName.Size = new System.Drawing.Size(55, 21);
            this.edit_setName.TabIndex = 12;
            // 
            // btn_getUseLocal
            // 
            this.btn_getUseLocal.Location = new System.Drawing.Point(136, 56);
            this.btn_getUseLocal.Name = "btn_getUseLocal";
            this.btn_getUseLocal.Size = new System.Drawing.Size(140, 27);
            this.btn_getUseLocal.TabIndex = 6;
            this.btn_getUseLocal.Text = "[12-71] Get Use Local";
            this.btn_getUseLocal.UseVisualStyleBackColor = true;
            this.btn_getUseLocal.Click += new System.EventHandler(this.btn_getUseLocal_Click);
            // 
            // btn_getAllLocal
            // 
            this.btn_getAllLocal.Location = new System.Drawing.Point(136, 420);
            this.btn_getAllLocal.Name = "btn_getAllLocal";
            this.btn_getAllLocal.Size = new System.Drawing.Size(140, 27);
            this.btn_getAllLocal.TabIndex = 6;
            this.btn_getAllLocal.Text = "[12-70] Get All Local";
            this.btn_getAllLocal.UseVisualStyleBackColor = true;
            this.btn_getAllLocal.Click += new System.EventHandler(this.btn_getAllLocal_Click);
            // 
            // Form_SetUseLocal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 453);
            this.Controls.Add(this.edit_setName);
            this.Controls.Add(this.edit_currName);
            this.Controls.Add(this.edit_setCode);
            this.Controls.Add(this.edit_currCode);
            this.Controls.Add(this.edit_setIndex);
            this.Controls.Add(this.edit_currIdx);
            this.Controls.Add(this.btn_getUseLocal);
            this.Controls.Add(this.btn_getAllLocal);
            this.Controls.Add(this.btn_setUseLocal);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lv_local);
            this.Name = "Form_SetUseLocal";
            this.Text = "Form_SetUseLocal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lv_local;
        private System.Windows.Forms.ColumnHeader col_index;
        private System.Windows.Forms.ColumnHeader col_code;
        private System.Windows.Forms.ColumnHeader col_name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_setUseLocal;
        private System.Windows.Forms.TextBox edit_currIdx;
        private System.Windows.Forms.TextBox edit_currCode;
        private System.Windows.Forms.TextBox edit_currName;
        private System.Windows.Forms.TextBox edit_setIndex;
        private System.Windows.Forms.TextBox edit_setCode;
        private System.Windows.Forms.TextBox edit_setName;
        private System.Windows.Forms.Button btn_getUseLocal;
        private System.Windows.Forms.Button btn_getAllLocal;
    }
}